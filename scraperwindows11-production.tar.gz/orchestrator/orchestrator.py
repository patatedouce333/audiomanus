#!/usr/bin/env python3
"""
Orchestrateur Cloud Run pour déclencher des scrapes via Pub/Sub.
Reçoit des requêtes HTTP pour des scrapes standards et visuels.
"""

import json
import logging
import os

from flask import Flask, request, jsonify
from google.cloud import pubsub_v1

# Configuration
PROJECT_ID = os.getenv("PROJECT_ID", "project-91ffa63d-6bed-405c-bc3")
TOPIC = os.getenv("PUBSUB_TOPIC", "scraper-topic")

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Flask app
app = Flask(__name__)

# Pub/Sub publisher
publisher = pubsub_v1.PublisherClient()
topic_path = publisher.topic_path(PROJECT_ID, TOPIC)


@app.route("/", methods=["GET"])
def health():
    return jsonify({"status": "healthy", "service": "scraper-orchestrator"})


@app.route("/dispatch", methods=["POST"])
def dispatch():
    """Endpoint pour dispatcher des scrapes standards (crawl4ai)."""
    # ... (code inchangé) ...
    try:
        data = request.get_json()
        urls = data.get("urls", [])
        if not urls:
            return jsonify({"error": "'urls' list is empty"}), 400
        
        message_ids = []
        for url in urls:
            message_data = {"url": url, "task_type": "standard"} # On précise le type
            message_bytes = json.dumps(message_data).encode("utf-8")
            future = publisher.publish(topic_path, message_bytes)
            message_ids.append(future.result())

        logger.info(f"Published {len(message_ids)} standard scrape tasks.")
        return jsonify({"status": "success", "dispatched": len(message_ids), "message_ids": message_ids}), 200
    except Exception as e:
        logger.error(f"Error in dispatch: {e}", exc_info=True)
        return jsonify({"error": str(e)}), 500


# --- NOUVEL ENDPOINT (TÂCHE 3.2) ---
@app.route("/scrape/visual", methods=["POST"])
def scrape_visual():
    """
    Endpoint pour dispatcher une seule tâche de scraping visuel.
    Le body doit contenir: {
        "url": "https://...",
        "task_type": "visual_extraction" | "visual_location",
        "prompt": "(si extraction) Extraire le titre.",
        "element_description": "(si location) Le bouton de connexion."
    }
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "Invalid JSON"}), 400

        url = data.get("url")
        task_type = data.get("task_type")

        if not url or not task_type:
            return jsonify({"error": "Les champs 'url' et 'task_type' sont requis."}), 400
        
        message_data = {"url": url, "task_type": task_type}

        if task_type == "visual_extraction":
            prompt = data.get("prompt")
            if not prompt:
                return jsonify({"error": "Le champ 'prompt' est requis pour 'visual_extraction'"}), 400
            message_data["prompt"] = prompt
        
        elif task_type == "visual_location":
            element_description = data.get("element_description")
            if not element_description:
                return jsonify({"error": "Le champ 'element_description' est requis pour 'visual_location'"}), 400
            message_data["element_description"] = element_description
        else:
            return jsonify({"error": f"Type de tâche invalide: '{task_type}'"}), 400

        # Publication du message sur Pub/Sub
        message_bytes = json.dumps(message_data).encode("utf-8")
        future = publisher.publish(topic_path, message_bytes)
        message_id = future.result()
        
        logger.info(f"Tâche de scraping visuel publiée pour {url} (ID: {message_id})")
        
        return jsonify({
            "status": "success",
            "dispatched_task": message_data,
            "message_id": message_id
        }), 200

    except Exception as e:
        logger.error(f"Erreur dans /scrape/visual: {e}", exc_info=True)
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    port = int(os.getenv("PORT", 8080))
    app.run(host="0.0.0.0", port=port, debug=False)
