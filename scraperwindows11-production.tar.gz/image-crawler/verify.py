#!/usr/bin/env python3
"""
Quick verification script to test the image crawler without full infrastructure.
Tests parsers and basic functionality without requiring GCP or Redis.
"""
import asyncio
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

print("🔍 Image Crawler - Quick Verification Test\n")

# Test 1: Import all modules
print("✓ Test 1: Importing modules...")
try:
    from config import settings
    from models import ImageCandidate, CrawlRequest
    from parsers.standard_parser import StandardParser
    from routing.heuristic import ParserRouter
    print("  ✅ All modules imported successfully\n")
except Exception as e:
    print(f"  ❌ Import failed: {e}\n")
    sys.exit(1)

# Test 2: Test standard parser with sample HTML
print("✓ Test 2: Testing Standard Parser...")
async def test_standard_parser():
    parser = StandardParser()
    
    sample_html = """
    <!DOCTYPE html>
    <html>
    <body>
        <img src="https://via.placeholder.com/800x600.jpg" alt="Test image 1" width="800" height="600">
        <img src="/relative/image.png" alt="Test image 2">
        <img data-src="https://via.placeholder.com/400x300.jpg" alt="Lazy loaded">
        <picture>
            <source srcset="https://via.placeholder.com/1200x800.webp">
            <img src="https://via.placeholder.com/600x400.jpg">
        </picture>
    </body>
    </html>
    """
    
    try:
        candidates = await parser.extract_images(sample_html, "https://example.com/page")
        print(f"  ✅ Extracted {len(candidates)} images")
        for i, candidate in enumerate(candidates[:3], 1):
            print(f"     {i}. {candidate.url} (alt: {candidate.alt})")
        if len(candidates) > 3:
            print(f"     ... and {len(candidates) - 3} more")
        print()
        return True
    except Exception as e:
        print(f"  ❌ Parser failed: {e}\n")
        return False

if not asyncio.run(test_standard_parser()):
    sys.exit(1)

# Test 3: Test routing heuristic
print("✓ Test 3: Testing Router Heuristic...")
try:
    router = ParserRouter()
    
    test_cases = [
        ("https://example.com/simple.html", "Expected: AI or standard"),
        ("https://react-app.com/gallery", "Expected: navigation (SPA detected)"),
        ("https://site.com/page", "Expected: AI with fallback"),
    ]
    
    for url, expected in test_cases:
        mode = router.choose_parser(url, force_mode="auto")
        print(f"  ✅ {url[:40]}... → {mode}")
    print()
except Exception as e:
    print(f"  ❌ Router failed: {e}\n")
    sys.exit(1)

# Test 4: Test Pydantic models validation
print("✓ Test 4: Testing Pydantic Models...")
try:
    # Valid candidate
    candidate = ImageCandidate(
        url="https://example.com/image.jpg",
        alt="Test image",
        width=1920,
        height=1080,
        source_page="https://example.com",
        extractor="standard"
    )
    print(f"  ✅ Valid ImageCandidate created: {candidate.url}")
    
    # Valid crawl request
    request = CrawlRequest(
        urls=["https://example.com", "https://test.com"],
        job_name="test-crawl",
        max_depth=2
    )
    print(f"  ✅ Valid CrawlRequest created: {request.job_name}")
    print()
except Exception as e:
    print(f"  ❌ Model validation failed: {e}\n")
    sys.exit(1)

# Test 5: Check dependencies
print("✓ Test 5: Checking key dependencies...")
dependencies = {
    "scrapy": "Scrapy web crawling framework",
    "playwright": "Browser automation",
    "pydantic": "Data validation",
    "beautifulsoup4": "HTML parsing",
    "redis": "Queue management",
    "google.cloud.storage": "GCS client",
}

missing = []
for module, description in dependencies.items():
    try:
        __import__(module.replace("-", "_"))
        print(f"  ✅ {module}: {description}")
    except ImportError:
        print(f"  ⚠️  {module}: {description} (not installed)")
        missing.append(module)

if missing:
    print(f"\n⚠️  Missing dependencies: {', '.join(missing)}")
    print("  Run: poetry install")
else:
    print()

# Test 6: Check Playwright installation
print("✓ Test 6: Checking Playwright browsers...")
try:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        print(f"  ✅ Playwright installed")
        print(f"     Available browsers: chromium, firefox, webkit")
    print()
except Exception as e:
    print(f"  ⚠️  Playwright not fully installed: {e}")
    print("     Run: poetry run playwright install chromium --with-deps\n")

# Summary
print("=" * 60)
print("🎉 Basic verification complete!")
print("=" * 60)
print("\n📋 Next steps:")
print("  1. Configure .env file with your API keys")
print("  2. Run unit tests: poetry run pytest tests/ -v")
print("  3. Test with real URL: poetry run python examples/simple_crawl.py")
print("  4. Start full system: docker-compose up")
print()
