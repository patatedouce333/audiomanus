"""Pipeline module."""
