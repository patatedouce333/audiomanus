"""
Custom Scrapy pipeline for image processing and storage.
Handles downloading, hashing, deduplication, and GCS upload.
"""
import hashlib
import logging
from typing import Any

import httpx
from scrapy import Spider
from scrapy.http import Response

from models import ImageCandidate, ImageMetadata
from storage.db_client import db_client
from storage.gcs_client import gcs_client

logger = logging.getLogger(__name__)


class ImagePipeline:
    """Pipeline to process image items: download, hash, deduplicate, and store."""

    def __init__(self) -> None:
        """Initialize pipeline."""
        self.http_client = httpx.AsyncClient(timeout=30.0, follow_redirects=True)
        logger.info("ImagePipeline initialized")

    async def process_item(self, item: dict[str, Any], spider: Spider) -> dict[str, Any]:
        """
        Process each image item through the pipeline.

        Args:
            item: Image item dict (from ImageCandidate)
            spider: Scrapy spider instance

        Returns:
            Processed item dict
        """
        try:
            # Convert dict to ImageCandidate
            candidate = ImageCandidate(**item)

            # Download image
            image_data, content_type = await self._download_image(str(candidate.url))

            # Compute SHA-256 hash
            sha256_hash = hashlib.sha256(image_data).digest()

            # Check for duplicates
            exists = await db_client.check_image_exists(sha256_hash)

            if exists:
                logger.info(f"Image already exists (hash collision): {candidate.url}")
                item["status"] = "duplicate"
                return item

            # Upload to GCS
            gcs_uri, sha256_hash, file_size = await gcs_client.upload_image(
                image_data,
                sha256_hash=sha256_hash,
                content_type=content_type,
                metadata={
                    "source_page": str(candidate.source_page),
                    "extractor": candidate.extractor,
                    "alt": candidate.alt or "",
                },
            )

            # Create metadata
            metadata = ImageMetadata(
                url=str(candidate.url),
                alt=candidate.alt,
                width=candidate.width,
                height=candidate.height,
                sha256=sha256_hash,
                gcs_uri=gcs_uri,
                source_page=str(candidate.source_page),
                extractor=candidate.extractor,
                status=1,  # Successfully stored
                file_size=file_size,
                mime_type=content_type,
            )

            # Insert into database
            image_id = await db_client.insert_image(metadata)

            logger.info(f"Successfully processed image: {image_id}")

            item["status"] = "stored"
            item["image_id"] = str(image_id)
            item["gcs_uri"] = gcs_uri
            item["file_size"] = file_size

            return item

        except Exception as e:
            logger.error(f"Failed to process item: {e}")
            item["status"] = "error"
            item["error"] = str(e)
            return item

    async def _download_image(self, url: str) -> tuple[bytes, str]:
        """
        Download image from URL.

        Args:
            url: Image URL

        Returns:
            Tuple of (image data, content type)
        """
        try:
            response = await self.http_client.get(url)
            response.raise_for_status()

            content_type = response.headers.get("content-type", "image/jpeg")
            return response.content, content_type

        except Exception as e:
            logger.error(f"Failed to download image {url}: {e}")
            raise

    async def close_spider(self, spider: Spider) -> None:
        """Clean up resources when spider closes."""
        await self.http_client.aclose()
        db_client.close()
        logger.info("ImagePipeline closed")
