#!/bin/bash
# 🚀 LANCEMENT RAPIDE DANS CODESPACES (CLOUD)
# Pas besoin de Docker local, tout est dans le cloud!

set -e

echo "🚀 Image Crawler - Lancement dans Codespaces"
echo "=============================================="
echo ""

cd "$(dirname "$0")"

# 1. Installer les dépendances Python
echo "📦 Installation des dépendances..."
python3 -m pip install -q pydantic pydantic-settings beautifulsoup4 lxml httpx 2>&1 | grep -v "already satisfied" || true
echo "✅ Dépendances installées"
echo ""

# 2. Test de vérification rapide
echo "🔍 Test 1: Vérification des modules..."
python3 verify.py 2>&1 | grep -E "✅|❌|🎉" || true
echo ""

# 3. Test avec parseur
echo "🧪 Test 2: Démonstration du parseur..."
python3 -c "
import asyncio
import sys
sys.path.insert(0, '.')

async def demo():
    from parsers.standard_parser import StandardParser
    parser = StandardParser()
    
    html = '''
    <img src=\"https://via.placeholder.com/800x600.jpg\" alt=\"Test 1\" width=\"800\">
    <img src=\"/relative.png\" alt=\"Test 2\">
    <img data-src=\"https://via.placeholder.com/400x300.jpg\" alt=\"Lazy\">
    '''
    
    imgs = await parser.extract_images(html, 'https://example.com')
    print(f'✅ Parser testé: {len(imgs)} images extraites')
    for i, img in enumerate(imgs, 1):
        print(f'   {i}. {img.url} ({img.alt})')

asyncio.run(demo())
"
echo ""

# 4. Menu interactif
echo "🎯 Lancement du menu interactif..."
echo "=============================================="
echo ""
python3 test_menu.py
