"""
Google Cloud Storage client for uploading images.
"""
import hashlib
import logging
from datetime import datetime
from io import BytesIO

from google.cloud import storage
from google.auth.exceptions import DefaultCredentialsError

from config import settings

logger = logging.getLogger(__name__)


class GCSClient:
    """Google Cloud Storage client for image uploads."""

    def __init__(
        self,
        project_id: str | None = None,
        bucket_name: str | None = None,
    ) -> None:
        """
        Initialize GCS client.

        Args:
            project_id: GCP project ID (defaults to settings)
            bucket_name: GCS bucket name (defaults to settings)
        """
        self.project_id = project_id or settings.gcp_project_id
        self.bucket_name = bucket_name or settings.gcs_bucket_name

        try:
            self.client = storage.Client(project=self.project_id)
            self.bucket = self.client.bucket(self.bucket_name)
            logger.info(f"GCS client initialized for bucket: {self.bucket_name}")
        except DefaultCredentialsError:
            logger.error(
                "GCP credentials not found. Set GOOGLE_APPLICATION_CREDENTIALS or use gcloud auth"
            )
            raise

    async def upload_image(
        self,
        image_data: bytes,
        sha256_hash: bytes | None = None,
        content_type: str = "image/jpeg",
        metadata: dict[str, str] | None = None,
    ) -> tuple[str, bytes, int]:
        """
        Upload image to GCS.

        Args:
            image_data: Image binary data
            sha256_hash: Pre-computed SHA-256 hash (will compute if not provided)
            content_type: MIME type
            metadata: Additional metadata

        Returns:
            Tuple of (GCS URI, SHA-256 hash, file size)
        """
        # Compute hash if not provided
        if sha256_hash is None:
            sha256_hash = hashlib.sha256(image_data).digest()

        # Generate GCS path: images/YYYY/MM/DD/hash_prefix/full_hash.ext
        hash_hex = sha256_hash.hex()
        now = datetime.utcnow()
        extension = self._get_extension_from_mime(content_type)

        blob_name = (
            f"images/{now.year}/{now.month:02d}/{now.day:02d}/"
            f"{hash_hex[:2]}/{hash_hex}{extension}"
        )

        blob = self.bucket.blob(blob_name)

        # Check if already exists (by name)
        if blob.exists():
            logger.info(f"Image already exists in GCS: {blob_name}")
            gcs_uri = f"gs://{self.bucket_name}/{blob_name}"
            return gcs_uri, sha256_hash, len(image_data)

        # Set metadata
        if metadata:
            blob.metadata = metadata

        # Upload
        try:
            blob.upload_from_file(
                BytesIO(image_data),
                content_type=content_type,
                timeout=60,
            )

            gcs_uri = f"gs://{self.bucket_name}/{blob_name}"
            file_size = len(image_data)

            logger.info(f"Uploaded image to GCS: {gcs_uri} ({file_size} bytes)")
            return gcs_uri, sha256_hash, file_size

        except Exception as e:
            logger.error(f"Failed to upload to GCS: {e}")
            raise

    def _get_extension_from_mime(self, mime_type: str) -> str:
        """Get file extension from MIME type."""
        mime_map = {
            "image/jpeg": ".jpg",
            "image/png": ".png",
            "image/gif": ".gif",
            "image/webp": ".webp",
            "image/svg+xml": ".svg",
            "image/bmp": ".bmp",
            "image/x-icon": ".ico",
            "image/avif": ".avif",
        }
        return mime_map.get(mime_type, ".bin")

    def delete_image(self, gcs_uri: str) -> bool:
        """
        Delete image from GCS.

        Args:
            gcs_uri: GCS URI (gs://bucket/path)

        Returns:
            True if deleted, False otherwise
        """
        try:
            # Extract blob name from URI
            blob_name = gcs_uri.replace(f"gs://{self.bucket_name}/", "")
            blob = self.bucket.blob(blob_name)
            blob.delete()
            logger.info(f"Deleted image from GCS: {gcs_uri}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete from GCS: {e}")
            return False


# Singleton instance
gcs_client = GCSClient()
