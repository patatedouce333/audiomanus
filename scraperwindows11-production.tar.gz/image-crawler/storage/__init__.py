"""Storage module."""
