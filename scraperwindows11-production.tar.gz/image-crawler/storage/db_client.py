"""
Cloud SQL (PostgreSQL) database client.
"""
import logging
from typing import Any
from uuid import UUID

import pg8000
from google.cloud.sql.connector import Connector
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from config import settings
from models import ImageMetadata

logger = logging.getLogger(__name__)


class DatabaseClient:
    """PostgreSQL database client using Cloud SQL connector."""

    def __init__(self) -> None:
        """Initialize database connection."""
        self.connector = Connector()
        self.engine: Engine | None = None
        logger.info("DatabaseClient initialized")

    def connect(self) -> Engine:
        """
        Create SQLAlchemy engine with Cloud SQL connector.

        Returns:
            SQLAlchemy Engine
        """
        if self.engine:
            return self.engine

        def getconn() -> pg8000.Connection:
            """Create connection to Cloud SQL."""
            conn: pg8000.Connection = self.connector.connect(
                settings.cloud_sql_connection_name,
                "pg8000",
                user=settings.cloud_sql_user,
                password=settings.cloud_sql_password,
                db=settings.cloud_sql_database,
            )
            return conn

        self.engine = create_engine(
            "postgresql+pg8000://",
            creator=getconn,
            pool_size=5,
            max_overflow=10,
            pool_timeout=30,
            pool_recycle=1800,
        )

        logger.info("Database engine created")
        return self.engine

    async def check_image_exists(self, sha256_hash: bytes) -> bool:
        """
        Check if image with given hash already exists.

        Args:
            sha256_hash: SHA-256 hash of the image

        Returns:
            True if exists, False otherwise
        """
        engine = self.connect()

        with engine.connect() as conn:
            result = conn.execute(
                text("SELECT 1 FROM images WHERE sha256 = :hash LIMIT 1"),
                {"hash": sha256_hash},
            )
            exists = result.fetchone() is not None

        return exists

    async def insert_image(self, metadata: ImageMetadata) -> UUID:
        """
        Insert image metadata into database.

        Args:
            metadata: ImageMetadata object

        Returns:
            UUID of inserted image
        """
        engine = self.connect()

        with engine.connect() as conn:
            result = conn.execute(
                text("""
                    INSERT INTO images (
                        id, url, alt, width, height, sha256, gcs_uri,
                        fetched_at, source_page, extractor, status,
                        file_size, mime_type, metadata
                    )
                    VALUES (
                        :id, :url, :alt, :width, :height, :sha256, :gcs_uri,
                        :fetched_at, :source_page, :extractor, :status,
                        :file_size, :mime_type, :metadata::jsonb
                    )
                    RETURNING id
                """),
                {
                    "id": str(metadata.id),
                    "url": metadata.url,
                    "alt": metadata.alt,
                    "width": metadata.width,
                    "height": metadata.height,
                    "sha256": metadata.sha256,
                    "gcs_uri": metadata.gcs_uri,
                    "fetched_at": metadata.fetched_at,
                    "source_page": metadata.source_page,
                    "extractor": metadata.extractor,
                    "status": metadata.status,
                    "file_size": metadata.file_size,
                    "mime_type": metadata.mime_type,
                    "metadata": metadata.metadata or {},
                },
            )
            conn.commit()

            row = result.fetchone()
            if row:
                image_id = UUID(row[0])
                logger.info(f"Inserted image: {image_id}")
                return image_id

            raise ValueError("Failed to insert image")

    async def get_stats(self) -> dict[str, Any]:
        """
        Get database statistics.

        Returns:
            Dict with statistics
        """
        engine = self.connect()

        with engine.connect() as conn:
            result = conn.execute(text("SELECT * FROM images_stats"))
            stats = [dict(row._mapping) for row in result]

        return {"stats_by_extractor": stats}

    def close(self) -> None:
        """Close database connections."""
        if self.engine:
            self.engine.dispose()
        self.connector.close()
        logger.info("Database connections closed")


# Singleton instance
db_client = DatabaseClient()
