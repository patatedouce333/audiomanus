#!/usr/bin/env python3
"""
Menu interactif pour tester facilement l'image crawler.
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

def print_menu():
    """Affiche le menu principal."""
    print("\n" + "="*60)
    print("🖼️  IMAGE CRAWLER - MENU DE TEST")
    print("="*60)
    print("\n✅ Tests rapides (sans infrastructure):")
    print("  1. Vérifier tous les modules")
    print("  2. Tester parseur avec HTML de démonstration")
    print("  3. Crawler une URL simple (vous choisissez)")
    print("  4. Tester avec des URLs prédéfinies")
    print("\n⚙️  Tests avancés (nécessitent installation):")
    print("  5. Test complet avec Playwright")
    print("  6. Lancer les tests unitaires")
    print("  7. Test connexion Redis")
    print("\n📊 Démos:")
    print("  8. Démonstration complète du parseur")
    print("\n  0. Quitter")
    print("\n" + "="*60)


async def test_verification():
    """Test 1: Vérification."""
    print("\n🔍 Lancement de la vérification...\n")
    import subprocess
    result = subprocess.run([sys.executable, "verify.py"], cwd=Path(__file__).parent)
    return result.returncode == 0


async def test_parser_demo():
    """Test 2: Démonstration du parseur."""
    from parsers.standard_parser import StandardParser
    
    print("\n🧪 Test du parseur standard avec HTML de démonstration\n")
    
    parser = StandardParser()
    
    # HTML avec plusieurs types d'images
    test_html = """
    <!DOCTYPE html>
    <html>
    <head><title>Test Page</title></head>
    <body>
        <h1>Page de test avec images</h1>
        
        <!-- Image classique -->
        <img src="https://via.placeholder.com/1920x1080.jpg" 
             alt="Grande image placeholder" 
             width="1920" 
             height="1080">
        
        <!-- Image avec URL relative -->
        <img src="/images/logo.png" alt="Logo du site">
        
        <!-- Image lazy loading -->
        <img data-src="https://via.placeholder.com/800x600.webp" 
             alt="Image lazy" 
             class="lazy">
        
        <!-- Picture avec source -->
        <picture>
            <source srcset="https://via.placeholder.com/1200x800.webp 1x,
                           https://via.placeholder.com/2400x1600.webp 2x">
            <img src="https://via.placeholder.com/600x400.jpg" alt="Responsive image">
        </picture>
        
        <!-- Image en background CSS -->
        <div style="background-image: url('https://via.placeholder.com/1600x900.jpg');"></div>
    </body>
    </html>
    """
    
    candidates = await parser.extract_images(test_html, "https://example.com/test")
    
    print(f"✅ {len(candidates)} images extraites:\n")
    
    for i, img in enumerate(candidates, 1):
        print(f"{i}. URL: {img.url}")
        if img.alt:
            print(f"   Alt: {img.alt}")
        if img.width and img.height:
            print(f"   Dimensions: {img.width}x{img.height}")
        print(f"   Extracteur: {img.extractor}")
        print()
    
    return True


async def test_custom_url():
    """Test 3: URL personnalisée."""
    url = input("\n🌐 Entrez l'URL à crawler: ").strip()
    
    if not url:
        print("❌ URL vide, abandon.")
        return False
    
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    
    print(f"\n🔍 Crawling de {url}...\n")
    
    try:
        import httpx
        from parsers.standard_parser import standard_parser
        
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
            response = await client.get(url)
            html = response.text
        
        candidates = await standard_parser.extract_images(html, url)
        
        print(f"\n✅ Trouvé {len(candidates)} images:\n")
        
        for i, img in enumerate(candidates[:20], 1):
            print(f"{i}. {img.url}")
            if img.alt:
                print(f"   Alt: {img.alt[:60]}")
        
        if len(candidates) > 20:
            print(f"\n... et {len(candidates) - 20} autres images")
        
        if len(candidates) == 0:
            print("⚠️  Aucune image trouvée. La page pourrait:")
            print("   - Ne pas avoir d'images")
            print("   - Charger les images en JavaScript (essayez option 5)")
            print("   - Bloquer les crawlers")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Erreur: {e}")
        return False


async def test_predefined_urls():
    """Test 4: URLs prédéfinies."""
    print("\n📋 Test avec URLs prédéfinies\n")
    
    test_urls = [
        "https://httpbin.org/html",
        "https://placeholder.com",
        "https://example.com",
    ]
    
    import httpx
    from parsers.standard_parser import standard_parser
    
    results = []
    
    for url in test_urls:
        print(f"🔍 Crawling {url}...")
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(url)
                html = response.text
            
            candidates = await standard_parser.extract_images(html, url)
            print(f"   ✅ {len(candidates)} images trouvées")
            results.append((url, len(candidates)))
            
        except Exception as e:
            print(f"   ❌ Erreur: {e}")
            results.append((url, 0))
    
    print("\n📊 Résumé:")
    for url, count in results:
        print(f"  {url}: {count} images")
    
    return True


async def test_playwright():
    """Test 5: Playwright."""
    print("\n🎭 Test avec Playwright (navigation headless)\n")
    
    try:
        from navigation.playwright_navigator import navigator
        from parsers.standard_parser import standard_parser
        
        url = input("URL à crawler avec Playwright (défaut: https://unsplash.com): ").strip()
        if not url:
            url = "https://unsplash.com"
        
        print(f"\n⏳ Chargement de {url} avec Playwright...")
        print("   (scroll automatique, lazy loading, etc.)\n")
        
        html, intercepted = await navigator.fetch_page_with_scroll(url, max_scrolls=3)
        candidates = await standard_parser.extract_images(html, url)
        
        all_images = set(str(c.url) for c in candidates) | set(intercepted)
        
        print(f"✅ Résultats:")
        print(f"   - HTML téléchargé: {len(html)} bytes")
        print(f"   - Images parsées: {len(candidates)}")
        print(f"   - Images interceptées: {len(intercepted)}")
        print(f"   - Total unique: {len(all_images)}")
        
        return True
        
    except ImportError:
        print("❌ Playwright non installé.")
        print("\nInstallez avec:")
        print("  pip install playwright")
        print("  playwright install chromium --with-deps")
        return False
    except Exception as e:
        print(f"❌ Erreur: {e}")
        return False


async def test_unit_tests():
    """Test 6: Tests unitaires."""
    print("\n🧪 Lancement des tests unitaires...\n")
    
    try:
        import subprocess
        result = subprocess.run(
            [sys.executable, "-m", "pytest", "tests/", "-v"],
            cwd=Path(__file__).parent
        )
        return result.returncode == 0
    except Exception as e:
        print(f"❌ pytest non installé: {e}")
        print("\nInstallez avec: pip install pytest pytest-asyncio")
        return False


async def test_redis():
    """Test 7: Redis."""
    print("\n🗄️  Test connexion Redis\n")
    
    try:
        from task_queue.redis_queue import CrawlQueue
        
        print("Tentative de connexion à Redis...")
        queue = CrawlQueue()
        
        await queue.enqueue("https://test.com", depth=0)
        size = await queue.size()
        
        print(f"✅ Redis connecté! Queue size: {size}")
        
        await queue.clear()
        await queue.close()
        
        return True
        
    except ImportError:
        print("❌ redis non installé.")
        print("\nInstallez avec: pip install redis")
        return False
    except Exception as e:
        print(f"❌ Erreur de connexion: {e}")
        print("\nDémarrez Redis avec: docker-compose up redis -d")
        return False


async def demo_complet():
    """Test 8: Démonstration complète."""
    print("\n🎬 DÉMONSTRATION COMPLÈTE\n")
    print("=" * 60)
    
    from parsers.standard_parser import StandardParser
    from routing.heuristic import ParserRouter
    from models import ImageCandidate, CrawlRequest
    
    # 1. Parser
    print("\n1️⃣  Test du parseur standard")
    parser = StandardParser()
    html = '<img src="https://example.com/test.jpg" alt="Test" width="800">'
    imgs = await parser.extract_images(html, "https://example.com")
    print(f"   ✅ Parseur: {len(imgs)} image extraite")
    
    # 2. Router
    print("\n2️⃣  Test du router heuristique")
    router = ParserRouter()
    mode = router.choose_parser("https://react-app.com")
    print(f"   ✅ Router: mode '{mode}' choisi pour SPA")
    
    # 3. Modèles
    print("\n3️⃣  Test des modèles Pydantic")
    candidate = ImageCandidate(
        url="https://example.com/image.jpg",
        alt="Demo",
        width=1920,
        height=1080,
        source_page="https://example.com",
        extractor="standard"
    )
    print(f"   ✅ ImageCandidate créé: {candidate.url}")
    
    request = CrawlRequest(
        urls=["https://example.com"],
        job_name="demo",
        max_depth=1
    )
    print(f"   ✅ CrawlRequest créé: {request.job_name}")
    
    print("\n" + "=" * 60)
    print("✅ Démonstration complète réussie!")
    print("\nTous les composants principaux fonctionnent correctement.")
    
    return True


async def main():
    """Menu principal."""
    while True:
        print_menu()
        
        choice = input("\n👉 Votre choix: ").strip()
        
        if choice == "0":
            print("\n👋 Au revoir!\n")
            break
        
        elif choice == "1":
            await test_verification()
        
        elif choice == "2":
            await test_parser_demo()
        
        elif choice == "3":
            await test_custom_url()
        
        elif choice == "4":
            await test_predefined_urls()
        
        elif choice == "5":
            await test_playwright()
        
        elif choice == "6":
            await test_unit_tests()
        
        elif choice == "7":
            await test_redis()
        
        elif choice == "8":
            await demo_complet()
        
        else:
            print("\n❌ Choix invalide. Essayez encore.")
        
        input("\n⏎ Appuyez sur Entrée pour continuer...")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n👋 Interrupted. Bye!\n")
