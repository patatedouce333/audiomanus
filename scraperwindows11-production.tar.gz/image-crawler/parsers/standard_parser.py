"""
Standard HTML parser using BeautifulSoup.
Fallback parser when AI parser is not available or fails.
"""
import logging
import re
from typing import Any
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup
from pydantic import HttpUrl, ValidationError

from models import ImageCandidate

logger = logging.getLogger(__name__)


class StandardParser:
    """Parse HTML using BeautifulSoup to extract images."""

    def __init__(self) -> None:
        """Initialize parser."""
        logger.info("StandardParser initialized")

    async def extract_images(self, html: str, base_url: str) -> list[ImageCandidate]:
        """
        Extract images from HTML content.

        Args:
            html: HTML content as string
            base_url: Base URL for resolving relative URLs

        Returns:
            List of ImageCandidate objects
        """
        logger.info(f"Extracting images from HTML using standard parser (base: {base_url})")

        try:
            soup = BeautifulSoup(html, "lxml")
            candidates = []
            seen_urls = set()

            # Extract from <img> tags
            for img in soup.find_all("img"):
                candidate = self._extract_from_img_tag(img, base_url, seen_urls)
                if candidate:
                    candidates.append(candidate)

            # Extract from <picture><source> tags
            for picture in soup.find_all("picture"):
                for source in picture.find_all("source"):
                    candidate = self._extract_from_source_tag(source, base_url, seen_urls)
                    if candidate:
                        candidates.append(candidate)

            # Extract from CSS background-image (inline styles)
            for element in soup.find_all(style=True):
                candidate = self._extract_from_style(element, base_url, seen_urls)
                if candidate:
                    candidates.append(candidate)

            logger.info(f"Standard parser extracted {len(candidates)} images")
            return candidates

        except Exception as e:
            logger.error(f"Standard parser failed: {e}")
            raise

    def _extract_from_img_tag(
        self, img: Any, base_url: str, seen_urls: set[str]
    ) -> ImageCandidate | None:
        """Extract image from <img> tag."""
        # Try different attributes for image URL
        url = img.get("src") or img.get("data-src") or img.get("data-lazy-src")

        if not url:
            return None

        # Handle srcset (take first/largest image)
        srcset = img.get("srcset")
        if srcset:
            url = self._parse_srcset(srcset)

        # Normalize URL
        absolute_url = self._normalize_url(url, base_url)
        if not absolute_url or absolute_url in seen_urls:
            return None

        seen_urls.add(absolute_url)

        # Extract metadata
        alt = img.get("alt", "").strip() or None
        width = self._parse_dimension(img.get("width"))
        height = self._parse_dimension(img.get("height"))

        try:
            return ImageCandidate(
                url=HttpUrl(absolute_url),
                alt=alt,
                width=width,
                height=height,
                source_page=HttpUrl(base_url),
                extractor="standard",
            )
        except (ValidationError, ValueError) as e:
            logger.debug(f"Invalid image candidate: {e}")
            return None

    def _extract_from_source_tag(
        self, source: Any, base_url: str, seen_urls: set[str]
    ) -> ImageCandidate | None:
        """Extract image from <source> tag inside <picture>."""
        srcset = source.get("srcset")
        if not srcset:
            return None

        url = self._parse_srcset(srcset)
        absolute_url = self._normalize_url(url, base_url)

        if not absolute_url or absolute_url in seen_urls:
            return None

        seen_urls.add(absolute_url)

        try:
            return ImageCandidate(
                url=HttpUrl(absolute_url),
                alt=None,
                width=None,
                height=None,
                source_page=HttpUrl(base_url),
                extractor="standard",
            )
        except (ValidationError, ValueError):
            return None

    def _extract_from_style(
        self, element: Any, base_url: str, seen_urls: set[str]
    ) -> ImageCandidate | None:
        """Extract background-image from inline style."""
        style = element.get("style", "")
        match = re.search(r'background-image:\s*url\(["\']?([^"\'()]+)["\']?\)', style)

        if not match:
            return None

        url = match.group(1)
        absolute_url = self._normalize_url(url, base_url)

        if not absolute_url or absolute_url in seen_urls:
            return None

        seen_urls.add(absolute_url)

        try:
            return ImageCandidate(
                url=HttpUrl(absolute_url),
                alt=None,
                width=None,
                height=None,
                source_page=HttpUrl(base_url),
                extractor="standard",
            )
        except (ValidationError, ValueError):
            return None

    def _parse_srcset(self, srcset: str) -> str:
        """Parse srcset attribute and return the first/best URL."""
        # srcset format: "url1 1x, url2 2x" or "url1 100w, url2 200w"
        parts = srcset.split(",")
        if parts:
            # Take the first URL (could be improved to take largest)
            first_part = parts[0].strip().split()[0]
            return first_part
        return srcset

    def _normalize_url(self, url: str, base_url: str) -> str | None:
        """Convert relative URL to absolute and clean it."""
        if not url:
            return None

        # Remove tracking parameters (optional)
        url = self._remove_tracking_params(url)

        # Convert to absolute URL
        absolute_url = urljoin(base_url, url)

        # Validate scheme
        parsed = urlparse(absolute_url)
        if parsed.scheme not in ("http", "https"):
            return None

        return absolute_url

    def _remove_tracking_params(self, url: str) -> str:
        """Remove common tracking parameters from URL."""
        # Simple implementation - can be expanded
        tracking_params = ["utm_source", "utm_medium", "utm_campaign", "fbclid", "gclid"]
        parsed = urlparse(url)

        if not parsed.query:
            return url

        # Filter out tracking params
        query_parts = [
            part for part in parsed.query.split("&") if not any(part.startswith(f"{p}=") for p in tracking_params)
        ]

        new_query = "&".join(query_parts)
        return parsed._replace(query=new_query).geturl()

    def _parse_dimension(self, value: str | None) -> int | None:
        """Parse width/height attribute to integer."""
        if not value:
            return None

        # Remove 'px' suffix if present
        value_str = str(value).replace("px", "").strip()

        try:
            return int(value_str)
        except ValueError:
            return None


# Singleton instance
standard_parser = StandardParser()
