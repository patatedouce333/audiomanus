"""
AI-powered image parser using Firecrawl SDK.
"""
import logging
from typing import Any

from firecrawl import FirecrawlApp
from pydantic import HttpUrl, ValidationError

from config import settings
from models import ImageCandidate

logger = logging.getLogger(__name__)


class AIParser:
    """Parse web pages using Firecrawl AI extraction."""

    def __init__(self, api_key: str | None = None) -> None:
        """Initialize Firecrawl client."""
        self.api_key = api_key or settings.firecrawl_api_key
        self.client = FirecrawlApp(api_key=self.api_key)
        logger.info("AIParser initialized with Firecrawl")

    async def extract_images(
        self, url: str, schema: dict[str, Any] | None = None
    ) -> list[ImageCandidate]:
        """
        Extract images from a URL using Firecrawl AI.

        Args:
            url: URL to extract images from
            schema: Optional JSON schema for structured extraction

        Returns:
            List of ImageCandidate objects
        """
        logger.info(f"Extracting images from {url} using AI parser")

        try:
            # Default schema for image extraction
            if schema is None:
                schema = self._build_image_schema()

            # Call Firecrawl API with schema
            result = self.client.scrape_url(url, params={"formats": ["extract"], "extract": schema})

            # Parse result and validate
            candidates = []
            if result and "extract" in result:
                images_data = result["extract"].get("images", [])

                for img_data in images_data:
                    try:
                        candidate = ImageCandidate(
                            url=HttpUrl(img_data["url"]),
                            alt=img_data.get("alt"),
                            width=img_data.get("width"),
                            height=img_data.get("height"),
                            source_page=HttpUrl(url),
                            extractor="ai",
                        )
                        candidates.append(candidate)
                    except (ValidationError, ValueError) as e:
                        logger.warning(f"Failed to validate image data: {e}")
                        continue

            logger.info(f"AI parser extracted {len(candidates)} images from {url}")
            return candidates

        except Exception as e:
            logger.error(f"AI parser failed for {url}: {e}")
            raise

    def _build_image_schema(self) -> dict[str, Any]:
        """
        Build JSON schema for image extraction.

        Returns:
            JSON schema dict for Firecrawl
        """
        return {
            "type": "object",
            "properties": {
                "images": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "url": {
                                "type": "string",
                                "description": "Absolute URL of the image",
                            },
                            "alt": {
                                "type": "string",
                                "description": "Alt text or description",
                            },
                            "width": {
                                "type": "integer",
                                "description": "Width in pixels",
                            },
                            "height": {
                                "type": "integer",
                                "description": "Height in pixels",
                            },
                        },
                        "required": ["url"],
                    },
                    "description": "All images found on the page, including <img> tags and CSS background images",
                }
            },
            "required": ["images"],
        }


# Singleton instance
ai_parser = AIParser()
