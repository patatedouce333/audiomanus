-- Image Crawler Database Schema
-- PostgreSQL 15+

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Main images table
CREATE TABLE IF NOT EXISTS images (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    url TEXT NOT NULL,
    alt TEXT,
    width INTEGER,
    height INTEGER,
    sha256 BYTEA NOT NULL,
    gcs_uri TEXT NOT NULL,
    fetched_at TIMESTAMPTZ DEFAULT NOW(),
    source_page TEXT NOT NULL,
    extractor TEXT NOT NULL CHECK (extractor IN ('ai', 'standard', 'navigation')),
    status SMALLINT DEFAULT 0,
    file_size BIGINT,
    mime_type TEXT,
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Unique constraint on SHA256 hash (deduplication)
CREATE UNIQUE INDEX IF NOT EXISTS idx_images_sha256 ON images USING HASH (sha256);

-- Index on source page for query performance
CREATE INDEX IF NOT EXISTS idx_images_source_page ON images (source_page);

-- Index on fetched_at for time-based queries
CREATE INDEX IF NOT EXISTS idx_images_fetched_at ON images (fetched_at DESC);

-- Index on extractor for analytics
CREATE INDEX IF NOT EXISTS idx_images_extractor ON images (extractor);

-- Index on status for filtering
CREATE INDEX IF NOT EXISTS idx_images_status ON images (status);

-- GIN index on JSONB metadata
CREATE INDEX IF NOT EXISTS idx_images_metadata ON images USING GIN (metadata);

-- Crawl jobs tracking table
CREATE TABLE IF NOT EXISTS crawl_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_name TEXT NOT NULL,
    seed_urls TEXT[] NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('pending', 'running', 'completed', 'failed')),
    images_extracted INTEGER DEFAULT 0,
    images_stored INTEGER DEFAULT 0,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    error_message TEXT,
    config JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index on job status
CREATE INDEX IF NOT EXISTS idx_crawl_jobs_status ON crawl_jobs (status);

-- Crawl errors tracking
CREATE TABLE IF NOT EXISTS crawl_errors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id UUID REFERENCES crawl_jobs(id) ON DELETE CASCADE,
    url TEXT NOT NULL,
    error_type TEXT NOT NULL,
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    occurred_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index on job_id for errors
CREATE INDEX IF NOT EXISTS idx_crawl_errors_job_id ON crawl_errors (job_id);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-update updated_at
CREATE TRIGGER update_images_updated_at
    BEFORE UPDATE ON images
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- View for statistics
CREATE OR REPLACE VIEW images_stats AS
SELECT
    extractor,
    COUNT(*) as total_images,
    COUNT(DISTINCT sha256) as unique_images,
    SUM(file_size) as total_size_bytes,
    AVG(file_size) as avg_size_bytes,
    MIN(fetched_at) as first_fetched,
    MAX(fetched_at) as last_fetched
FROM images
GROUP BY extractor;

-- View for recent activity
CREATE OR REPLACE VIEW recent_crawls AS
SELECT
    cj.id,
    cj.job_name,
    cj.status,
    cj.images_extracted,
    cj.images_stored,
    cj.started_at,
    cj.completed_at,
    EXTRACT(EPOCH FROM (COALESCE(cj.completed_at, NOW()) - cj.started_at)) as duration_seconds,
    COUNT(ce.id) as error_count
FROM crawl_jobs cj
LEFT JOIN crawl_errors ce ON ce.job_id = cj.id
GROUP BY cj.id
ORDER BY cj.created_at DESC
LIMIT 50;

-- Grant permissions (adjust as needed)
-- GRANT SELECT, INSERT, UPDATE ON images TO your_app_user;
-- GRANT SELECT, INSERT, UPDATE ON crawl_jobs TO your_app_user;
-- GRANT SELECT, INSERT ON crawl_errors TO your_app_user;
