# 🚀 Guide de lancement rapide - Image Crawler

## Option 1️⃣ : Vérification ultra-rapide (30 secondes)

**Sans infrastructure, juste pour vérifier que tout compile et fonctionne :**

```bash
cd image-crawler

# Installer les dépendances de base
poetry install --no-root

# Lancer le script de vérification
poetry run python verify.py
```

✅ **Ce que ça teste :**
- Imports de tous les modules
- Parseur standard avec HTML de test
- Router heuristique
- Validation Pydantic
- Dépendances installées

❌ **Ce que ça ne teste PAS :** API Firecrawl, GCP, Redis, Playwright complet

---

## Option 2️⃣ : Test simple d'un crawl (2 minutes)

**Crawl d'une vraie URL sans infrastructure lourde :**

```bash
cd image-crawler

# Installer httpx si besoin
poetry add httpx

# Crawler une page simple
poetry run python examples/simple_crawl.py https://example.com

# Ou une page plus riche
poetry run python examples/simple_crawl.py https://httpbin.org/html
```

✅ **Ce que ça fait :**
- Télécharge une vraie page web
- Extrait toutes les images avec le parseur standard
- Affiche les résultats

❌ **Limitations :** Pas de JavaScript/SPA, pas de stockage, pas d'IA

---

## Option 3️⃣ : Test avec Playwright (5 minutes)

**Pour tester le crawling de SPA avec scroll infini :**

```bash
cd image-crawler

# Installer Playwright et ses navigateurs
poetry install
poetry run playwright install chromium --with-deps

# Test avec navigation headless
poetry run python examples/playwright_crawl.py https://unsplash.com

# Ou votre propre URL
poetry run python examples/playwright_crawl.py https://your-spa-site.com
```

✅ **Ce que ça fait :**
- Lance un navigateur headless Chromium
- Scroll automatique pour charger lazy images
- Intercepte les requêtes réseau
- Parse le HTML final

⚠️ **Note :** Peut être lent la première fois (téléchargement de Chromium)

---

## Option 4️⃣ : Tests unitaires (3 minutes)

**Pour valider que tout le code fonctionne correctement :**

```bash
cd image-crawler

# Installer les dépendances de test
poetry install --with dev

# Lancer tous les tests
poetry run pytest tests/ -v

# Ou juste les tests des parseurs
poetry run pytest tests/test_standard_parser.py -v
poetry run pytest tests/test_ai_parser.py -v

# Avec couverture de code
poetry run pytest --cov=. --cov-report=html
```

✅ **Ce que ça teste :**
- Parseur standard (extraction, URL relatives, déduplication)
- Parseur IA (mocks)
- Validation des modèles

---

## Option 5️⃣ : Docker Compose minimal (5 minutes)

**Tester avec Redis mais sans GCP (en local) :**

```bash
cd image-crawler

# Créer un .env minimal
cat > .env << EOF
FIRECRAWL_API_KEY=test_key_not_used
GCP_PROJECT_ID=local-test
GCS_BUCKET_NAME=local-bucket
CLOUD_SQL_CONNECTION_NAME=local:local:local
CLOUD_SQL_DATABASE=images_db
CLOUD_SQL_USER=postgres
CLOUD_SQL_PASSWORD=test
REDIS_HOST=redis
REDIS_PORT=6379
PLAYWRIGHT_HEADLESS=true
USE_AI_PARSER=false
USE_STANDARD_PARSER=true
EOF

# Lancer uniquement Redis
docker-compose up redis -d

# Tester la connexion Redis
poetry run python -c "
import asyncio
from queue.redis_queue import CrawlQueue
async def test():
    q = CrawlQueue()
    await q.enqueue('https://example.com', depth=0)
    size = await q.size()
    print(f'✅ Redis OK: {size} items in queue')
    await q.close()
asyncio.run(test())
"
```

✅ **Ce que ça teste :**
- Redis queue fonctionnelle
- Enqueue/dequeue de tâches

---

## Option 6️⃣ : Système complet avec Docker (10 minutes)

**Nécessite :** Credentials GCP valides

```bash
cd image-crawler

# 1. Configurer GCP (si pas déjà fait)
./scripts/setup-gcp.sh

# 2. Créer le fichier .env complet
cp .env.example .env
# Éditer avec vos vraies credentials

# 3. Initialiser la base de données
gcloud sql connect images-db --user=postgres --database=images_db < schema.sql

# 4. Lancer tout le système
docker-compose up

# 5. Dans un autre terminal, enqueue des URLs
poetry run python orchestrator.py
```

✅ **Ce que ça lance :**
- Redis (queue)
- Cloud SQL Proxy (connexion à PostgreSQL)
- Orchestrator (enqueue des URLs)
- Workers (processent la queue)

---

## 🎯 Résumé - Quelle option choisir ?

| Option | Temps | Prérequis | Usage |
|--------|-------|-----------|-------|
| **Option 1** | 30s | Python, Poetry | Vérifier que tout compile |
| **Option 2** | 2min | Python, Poetry, httpx | Test crawl simple |
| **Option 3** | 5min | + Playwright | Test SPA/lazy loading |
| **Option 4** | 3min | + pytest | Valider le code |
| **Option 5** | 5min | + Docker | Test avec queue Redis |
| **Option 6** | 10min | + GCP account | Système complet |

---

## 🐛 Dépannage rapide

### Erreur d'import de modules
```bash
cd image-crawler
poetry install --no-root
export PYTHONPATH="${PYTHONPATH}:$(pwd)"
```

### Playwright ne trouve pas chromium
```bash
poetry run playwright install chromium --with-deps
```

### Redis connection refused
```bash
docker-compose up redis -d
```

### Module 'firecrawl' not found
```bash
# C'est normal si vous n'avez pas la clé API
# Désactivez le parseur IA dans .env :
echo "USE_AI_PARSER=false" >> .env
```

---

## 🎉 Test de succès rapide

**Commande tout-en-un pour vérifier que tout marche :**

```bash
cd image-crawler && \
poetry install --no-root && \
poetry run python verify.py && \
poetry run python examples/simple_crawl.py https://example.com
```

Si vous voyez des ✅ partout, c'est bon ! 🚀
