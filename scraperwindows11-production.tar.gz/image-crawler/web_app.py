#!/usr/bin/env python3
"""
API Web pour l'image crawler - Interface accessible par navigateur
"""
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, HttpUrl
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from parsers.standard_parser import standard_parser
from routing.heuristic import router

app = FastAPI(title="Image Crawler API", version="1.0")


class CrawlRequest(BaseModel):
    url: str


@app.get("/", response_class=HTMLResponse)
async def home():
    """Page d'accueil avec interface."""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>🖼️ Image Crawler</title>
        <meta charset="utf-8">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
            }
            .container {
                max-width: 900px;
                margin: 0 auto;
                background: white;
                border-radius: 20px;
                padding: 40px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            }
            h1 {
                color: #667eea;
                text-align: center;
                margin-bottom: 10px;
                font-size: 2.5em;
            }
            .subtitle {
                text-align: center;
                color: #666;
                margin-bottom: 30px;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 8px;
                font-weight: bold;
                color: #333;
            }
            input[type="text"] {
                width: 100%;
                padding: 15px;
                border: 2px solid #ddd;
                border-radius: 10px;
                font-size: 16px;
                transition: border-color 0.3s;
            }
            input[type="text"]:focus {
                outline: none;
                border-color: #667eea;
            }
            button {
                width: 100%;
                padding: 15px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                border-radius: 10px;
                font-size: 18px;
                font-weight: bold;
                cursor: pointer;
                transition: transform 0.2s;
            }
            button:hover {
                transform: translateY(-2px);
            }
            button:disabled {
                opacity: 0.6;
                cursor: not-allowed;
            }
            #results {
                margin-top: 30px;
            }
            .result-card {
                background: #f8f9fa;
                padding: 15px;
                border-radius: 10px;
                margin-bottom: 15px;
                border-left: 4px solid #667eea;
            }
            .result-card img {
                max-width: 200px;
                max-height: 150px;
                border-radius: 5px;
                margin-top: 10px;
            }
            .loading {
                text-align: center;
                padding: 20px;
                color: #667eea;
                font-size: 18px;
            }
            .error {
                background: #ffebee;
                color: #c62828;
                padding: 15px;
                border-radius: 10px;
                border-left: 4px solid #c62828;
            }
            .success {
                background: #e8f5e9;
                color: #2e7d32;
                padding: 15px;
                border-radius: 10px;
                border-left: 4px solid #2e7d32;
                text-align: center;
                font-size: 18px;
                font-weight: bold;
            }
            .stats {
                display: flex;
                justify-content: space-around;
                margin: 20px 0;
                padding: 20px;
                background: #f8f9fa;
                border-radius: 10px;
            }
            .stat-item {
                text-align: center;
            }
            .stat-number {
                font-size: 36px;
                font-weight: bold;
                color: #667eea;
            }
            .stat-label {
                color: #666;
                margin-top: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🖼️ Image Crawler</h1>
            <p class="subtitle">Extraire toutes les images d'une page web</p>
            
            <form id="crawlForm">
                <div class="form-group">
                    <label for="url">URL de la page à crawler:</label>
                    <input 
                        type="text" 
                        id="url" 
                        name="url" 
                        placeholder="https://www.example.com"
                        value="https://www.pexels.com"
                        required
                    >
                </div>
                <button type="submit" id="submitBtn">🚀 Lancer le crawl</button>
            </form>
            
            <div id="results"></div>
        </div>

        <script>
            const form = document.getElementById('crawlForm');
            const resultsDiv = document.getElementById('results');
            const submitBtn = document.getElementById('submitBtn');

            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const url = document.getElementById('url').value;
                submitBtn.disabled = true;
                submitBtn.textContent = '⏳ Crawling en cours...';
                
                resultsDiv.innerHTML = '<div class="loading">🔍 Analyse de la page en cours...</div>';
                
                try {
                    const response = await fetch('/crawl', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ url: url })
                    });
                    
                    const data = await response.json();
                    
                    if (response.ok) {
                        displayResults(data);
                    } else {
                        resultsDiv.innerHTML = `<div class="error">❌ Erreur: ${data.detail}</div>`;
                    }
                } catch (error) {
                    resultsDiv.innerHTML = `<div class="error">❌ Erreur: ${error.message}</div>`;
                } finally {
                    submitBtn.disabled = false;
                    submitBtn.textContent = '🚀 Lancer le crawl';
                }
            });

            function displayResults(data) {
                let html = `
                    <div class="success">✅ Crawl terminé avec succès!</div>
                    
                    <div class="stats">
                        <div class="stat-item">
                            <div class="stat-number">${data.total_images}</div>
                            <div class="stat-label">Images trouvées</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">${Math.round(data.page_size / 1024)}</div>
                            <div class="stat-label">KB téléchargés</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number">${data.duration}s</div>
                            <div class="stat-label">Temps</div>
                        </div>
                    </div>
                `;
                
                if (data.images.length > 0) {
                    html += '<h3 style="margin-top: 20px; color: #333;">📸 Images extraites:</h3>';
                    
                    data.images.forEach((img, index) => {
                        html += `
                            <div class="result-card">
                                <strong>${index + 1}. ${img.url}</strong>
                                ${img.alt ? `<br><em>Alt: ${img.alt}</em>` : ''}
                                ${img.width && img.height ? `<br>📐 ${img.width}x${img.height}px` : ''}
                                <br><small>Extracteur: ${img.extractor}</small>
                                <br><a href="${img.url}" target="_blank">
                                    <img src="${img.url}" alt="${img.alt || 'Image'}" onerror="this.style.display='none'">
                                </a>
                            </div>
                        `;
                    });
                } else {
                    html += '<div class="error">⚠️ Aucune image trouvée sur cette page</div>';
                }
                
                resultsDiv.innerHTML = html;
            }
        </script>
    </body>
    </html>
    """


@app.post("/crawl")
async def crawl_page(request: CrawlRequest):
    """Crawl une URL et retourne les images."""
    import httpx
    import time
    
    start = time.time()
    
    try:
        # Valider l'URL
        url = request.url
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        
        # Télécharger la page
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
            response = await client.get(url)
            html = response.text
        
        # Parser les images
        candidates = await standard_parser.extract_images(html, url)
        
        duration = round(time.time() - start, 2)
        
        return {
            "success": True,
            "url": url,
            "total_images": len(candidates),
            "page_size": len(html),
            "duration": duration,
            "images": [
                {
                    "url": str(img.url),
                    "alt": img.alt,
                    "width": img.width,
                    "height": img.height,
                    "extractor": img.extractor,
                }
                for img in candidates[:50]  # Limiter à 50 pour l'affichage
            ]
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health")
async def health():
    """Health check."""
    return {"status": "ok", "message": "Image Crawler is running!"}


@app.get("/stats")
async def stats():
    """Stats de l'application."""
    try:
        from task_queue.redis_queue import CrawlQueue
        queue = CrawlQueue()
        queue_size = await queue.size()
        await queue.close()
        redis_status = "connected"
    except:
        queue_size = 0
        redis_status = "disconnected"
    
    return {
        "redis": redis_status,
        "queue_size": queue_size,
    }


if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*70)
    print("🚀 IMAGE CRAWLER - INTERFACE WEB")
    print("="*70)
    print("\n✅ Serveur démarré!")
    print("\n🌐 Accédez à l'interface web:")
    print("   👉 http://localhost:8000")
    print("\n📡 API disponible:")
    print("   - GET  /         → Interface web")
    print("   - POST /crawl    → API pour crawler")
    print("   - GET  /health   → Health check")
    print("   - GET  /stats    → Statistiques")
    print("\n" + "="*70)
    print()
    
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
