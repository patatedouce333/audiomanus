"""
Heuristic routing to choose the best parser (AI, Standard, or Navigation).
"""
import logging
from typing import Literal

logger = logging.getLogger(__name__)


class ParserRouter:
    """Route requests to the most appropriate parser based on heuristics."""

    def __init__(self) -> None:
        """Initialize router with default rules."""
        self.spa_indicators = [
            "react",
            "vue",
            "angular",
            "next.js",
            "nuxt",
            "gatsby",
            "svelte",
        ]
        self.heavy_js_indicators = [
            "data-react",
            "data-vue",
            "ng-",
            "_next/",
            "__nuxt",
        ]
        logger.info("ParserRouter initialized")

    def choose_parser(
        self,
        url: str,
        html_preview: str | None = None,
        force_mode: Literal["ai", "standard", "navigation", "auto"] = "auto",
    ) -> Literal["ai", "standard", "navigation"]:
        """
        Choose the best parser based on URL and content analysis.

        Args:
            url: Target URL
            html_preview: Optional HTML preview for analysis
            force_mode: Force a specific mode or use auto routing

        Returns:
            Parser type to use
        """
        if force_mode != "auto":
            logger.info(f"Forced parser mode: {force_mode}")
            return force_mode  # type: ignore

        # Analyze URL
        url_lower = url.lower()

        # Check for known SPA frameworks in URL
        if any(indicator in url_lower for indicator in self.spa_indicators):
            logger.info(f"Detected SPA framework in URL: {url}, choosing navigation")
            return "navigation"

        # Analyze HTML if available
        if html_preview:
            html_lower = html_preview.lower()

            # Check for heavy JavaScript frameworks
            if any(indicator in html_lower for indicator in self.heavy_js_indicators):
                logger.info(f"Detected heavy JS framework in HTML: {url}, choosing navigation")
                return "navigation"

            # Check for lazy loading indicators
            if "data-src" in html_lower or "lazy" in html_lower:
                logger.info(f"Detected lazy loading: {url}, choosing navigation")
                return "navigation"

            # Check page size (large pages benefit from AI)
            if len(html_preview) > 500_000:  # > 500KB
                logger.info(f"Large page detected: {url}, choosing AI parser")
                return "ai"

        # Default: try AI first, with standard as fallback
        logger.info(f"Using AI parser with standard fallback for: {url}")
        return "ai"

    def should_retry_with_fallback(
        self, current_parser: Literal["ai", "standard", "navigation"], error: Exception
    ) -> Literal["standard", "navigation"] | None:
        """
        Determine if we should retry with a fallback parser.

        Args:
            current_parser: The parser that failed
            error: The error that occurred

        Returns:
            Fallback parser to use, or None if no fallback
        """
        if current_parser == "ai":
            logger.info("AI parser failed, falling back to standard parser")
            return "standard"
        elif current_parser == "standard":
            logger.info("Standard parser failed, falling back to navigation")
            return "navigation"
        else:
            logger.warning("Navigation parser failed, no fallback available")
            return None


# Singleton instance
router = ParserRouter()
