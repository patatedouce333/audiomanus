"""
Worker process to consume URLs from Redis queue and process them.
"""
import asyncio
import logging
import sys

from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings

from task_queue.redis_queue import crawl_queue
from spiders.image_spider import ImageSpider

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)

logger = logging.getLogger(__name__)


async def worker_loop() -> None:
    """Main worker loop to process queue items."""
    logger.info("Worker started, waiting for URLs...")

    while True:
        try:
            # Dequeue URL (blocking with 5s timeout)
            message = await crawl_queue.dequeue(timeout=5)

            if message is None:
                # Timeout, check again
                continue

            url = message["url"]
            depth = message.get("depth", 0)
            mode_hint = message.get("mode_hint", "auto")

            logger.info(f"Processing: {url} (depth={depth}, mode={mode_hint})")

            # Create and run spider for this URL
            process = CrawlerProcess(get_project_settings())
            process.crawl(ImageSpider, urls=[url])
            process.start()

            logger.info(f"Completed: {url}")

        except KeyboardInterrupt:
            logger.info("Worker interrupted, shutting down...")
            break
        except Exception as e:
            logger.error(f"Worker error: {e}")
            await asyncio.sleep(1)


def main() -> None:
    """Main entry point for worker."""
    try:
        asyncio.run(worker_loop())
    except KeyboardInterrupt:
        logger.info("Worker stopped")
    finally:
        asyncio.run(crawl_queue.close())


if __name__ == "__main__":
    main()
