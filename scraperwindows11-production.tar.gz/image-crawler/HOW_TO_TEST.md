# 🎯 COMMENT TESTER MAINTENANT

## ⚡ Option la plus simple : Menu interactif

**Une seule commande :**

```bash
./test.sh
```

ou

```bash
python3 test_menu.py
```

Cela ouvre un **menu avec 8 options** :

```
🖼️  IMAGE CRAWLER - MENU DE TEST
============================================================

✅ Tests rapides (sans infrastructure):
  1. Vérifier tous les modules
  2. Tester parseur avec HTML de démonstration  ⭐ RECOMMANDÉ
  3. Crawler une URL simple (vous choisissez)
  4. Tester avec des URLs prédéfinies

⚙️  Tests avancés (nécessitent installation):
  5. Test complet avec Playwright
  6. Lancer les tests unitaires
  7. Test connexion Redis

📊 Démos:
  8. Démonstration complète du parseur           ⭐ RECOMMANDÉ

  0. Quitter
```

---

## 🎬 Ce que chaque option fait

### **Option 2** (⭐ Commencez par celle-ci)
- Teste le parseur avec du HTML pré-fait
- Vous montre exactement comment il trouve les images
- **Pas besoin d'internet ou d'infrastructure**

### **Option 8** (⭐ Ou celle-ci pour une démo complète)
- Teste tous les composants principaux
- Parser + Router + Modèles Pydantic
- **Super rapide (2 secondes)**

### **Option 3**
- Vous demande une URL
- Crawl le site en temps réel
- Affiche toutes les images trouvées

### **Option 1**
- Vérifie que tout est bien installé
- Teste les imports de modules
- Lance une batterie de tests automatiques

---

## 🚀 Lancement ultra-rapide

**Copiez-collez ceci dans votre terminal :**

```bash
cd /workspaces/codespaces-blank/image-crawler
python3 test_menu.py
```

Puis appuyez sur **`2`** puis **Entrée** pour voir le parseur en action !

---

## 🔘 Encore plus simple ?

Si vous voulez juste voir si ça marche **MAINTENANT** :

```bash
cd /workspaces/codespaces-blank/image-crawler
python3 -c "
import asyncio
import sys
sys.path.insert(0, '.')

async def quick_test():
    from parsers.standard_parser import StandardParser
    parser = StandardParser()
    html = '<img src=\"https://example.com/test.jpg\" alt=\"Test\" width=\"800\">'
    imgs = await parser.extract_images(html, 'https://example.com')
    print(f'✅ SUCCESS! Parser found {len(imgs)} image(s)')
    print(f'   URL: {imgs[0].url}')
    print(f'   Alt: {imgs[0].alt}')
    print(f'   Width: {imgs[0].width}')
    
asyncio.run(quick_test())
"
```

---

## 📋 Résumé des commandes

| Commande | Temps | Ce qu'elle fait |
|----------|-------|-----------------|
| `./test.sh` | 1s | Lance le menu interactif |
| `python3 test_menu.py` | 1s | Idem |
| `python3 verify.py` | 5s | Vérifie tout le système |
| `python3 examples/simple_crawl.py URL` | 3s | Crawl une URL |

---

## 🎯 RÉPONSE DIRECTE À VOTRE QUESTION

**Q: "Je fais quoi maintenant?"**

**R:** Tapez `./test.sh` puis choisissez option `2` ou `8` ! 

C'est tout ! Vous verrez immédiatement si ça marche. 🎉
