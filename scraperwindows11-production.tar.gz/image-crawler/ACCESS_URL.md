# 🌐 VOTRE APPLICATION EST EN LIGNE !

## ✅ Le serveur web tourne sur le port 8000

Dans **GitHub Codespaces**, le port est automatiquement forwardé.

## 🔗 Pour accéder à l'interface web :

### Option 1 : Via l'onglet "PORTS" de VS Code
1. Regardez en bas de VS Code, onglet **"PORTS"**
2. Vous verrez le port **8000** 
3. Cliquez sur l'icône **🌐 globe** ou le lien dans la colonne "Forwarded Address"
4. **Ça ouvre votre app dans le navigateur !**

### Option 2 : URL directe (si vous la voyez)
L'URL ressemble à :
```
https://[votre-codespace-name]-8000.app.github.dev
```

### Option 3 : Commande pour ouvrir le navigateur
Dans le terminal VS Code, tapez :
```bash
echo "Ouvrez cette URL : $(gp url 8000 2>/dev/null || echo 'Vérifiez l\'onglet PORTS')"
```

## 🎯 Que faire une fois dans l'interface :

1. Vous verrez un formulaire avec un champ URL
2. Entrez n'importe quelle URL (ex: `https://www.pexels.com`)
3. Cliquez sur **"🚀 Lancer le crawl"**
4. **BOOM !** Vous voyez toutes les images extraites !

## 🛠️ Commandes utiles :

### Voir les logs du serveur
```bash
tail -f /workspaces/codespaces-blank/image-crawler/web_app.log
```

### Arrêter le serveur
```bash
pkill -f web_app.py
```

### Relancer le serveur
```bash
cd /workspaces/codespaces-blank/image-crawler
python3 web_app.py
```

### Vérifier que le serveur tourne
```bash
curl http://localhost:8000/health
```

## 📊 API Endpoints disponibles :

- **GET /**  → Interface web (page HTML)
- **POST /crawl** → API pour crawler une URL
- **GET /health** → Health check
- **GET /stats** → Statistiques Redis

## 🧪 Test rapide de l'API

```bash
curl -X POST http://localhost:8000/crawl \
  -H "Content-Type: application/json" \
  -d '{"url": "https://example.com"}'
```

---

## 🎉 VOTRE APP EST MAINTENANT ACCESSIBLE PAR UNE URL WEB !

Regardez l'onglet **PORTS** en bas de VS Code pour trouver votre URL publique ! 🚀
