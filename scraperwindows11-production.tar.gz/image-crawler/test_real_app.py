#!/usr/bin/env python3
"""
Test DIRECT du crawler - Version simplifiée sans Scrapy
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

async def crawl_url(url: str):
    """Crawl une URL et affiche les résultats."""
    print(f"\n{'='*60}")
    print(f"🔍 CRAWLING: {url}")
    print('='*60)
    
    # Import des modules
    import httpx
    from parsers.standard_parser import standard_parser
    from routing.heuristic import router
    
    # Choisir le bon parser
    mode = router.choose_parser(url)
    print(f"📊 Mode sélectionné: {mode}")
    
    # Télécharger la page
    print(f"⏳ Téléchargement...")
    async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
        response = await client.get(url)
        html = response.text
    
    print(f"✅ Page téléchargée: {len(html):,} bytes")
    
    # Parser les images
    print(f"🔎 Extraction des images...")
    candidates = await standard_parser.extract_images(html, url)
    
    print(f"\n✨ RÉSULTATS: {len(candidates)} images trouvées\n")
    
    if candidates:
        print("📸 Liste des images:")
        for i, img in enumerate(candidates[:10], 1):
            print(f"\n  {i}. {img.url}")
            if img.alt:
                print(f"     Alt: {img.alt[:50]}")
            if img.width and img.height:
                print(f"     Taille: {img.width}x{img.height}px")
        
        if len(candidates) > 10:
            print(f"\n  ... et {len(candidates) - 10} autres images")
    else:
        print("⚠️  Aucune image trouvée sur cette page")
        print("   (La page utilise peut-être du JavaScript)")
    
    return len(candidates)


async def main():
    """Point d'entrée principal."""
    print("\n" + "="*60)
    print("🖼️  IMAGE CRAWLER - TEST EN PRODUCTION")
    print("="*60)
    print("\n👉 Vous êtes sur Codespaces (GitHub Cloud)")
    print("👉 Le crawler va extraire des images de vraies pages web")
    print()
    
    # URLs de test
    test_urls = [
        "https://httpbin.org/html",
        "https://www.example.com",
    ]
    
    print("🎯 URLs de test prédéfinies:")
    for i, url in enumerate(test_urls, 1):
        print(f"  {i}. {url}")
    
    print("\n" + "="*60)
    
    # Option 1: URLs prédéfinies
    print("\nOptions:")
    print("  1. Tester avec les URLs prédéfinies")
    print("  2. Entrer votre propre URL")
    
    choice = input("\n👉 Votre choix (1 ou 2): ").strip()
    
    if choice == "2":
        url = input("\n🌐 Entrez l'URL: ").strip()
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        urls_to_crawl = [url]
    else:
        urls_to_crawl = test_urls
    
    # Crawler les URLs
    total_images = 0
    for url in urls_to_crawl:
        try:
            count = await crawl_url(url)
            total_images += count
        except Exception as e:
            print(f"\n❌ Erreur: {e}")
    
    # Résumé
    print("\n" + "="*60)
    print(f"🎉 CRAWL TERMINÉ!")
    print("="*60)
    print(f"📊 Total: {total_images} images extraites")
    print(f"📄 Pages crawlées: {len(urls_to_crawl)}")
    print()
    
    # Test Redis
    print("🗄️  Test de connexion Redis...")
    try:
        from task_queue.redis_queue import CrawlQueue
        queue = CrawlQueue()
        await queue.enqueue("https://test.com", depth=0)
        size = await queue.size()
        print(f"✅ Redis fonctionne! Queue: {size} items")
        await queue.clear()
        await queue.close()
    except Exception as e:
        print(f"⚠️  Redis non disponible: {e}")
    
    print("\n✅ Application testée avec succès!")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n👋 Interrupted. Bye!")
