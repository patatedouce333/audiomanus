#!/bin/bash
# Script de lancement rapide avec menu interactif

echo "🚀 Lancement du menu de test Image Crawler..."
echo ""

cd "$(dirname "$0")"

# Vérifier les dépendances
if ! python3 -c "import pydantic" 2>/dev/null; then
    echo "📦 Installation des dépendances..."
    python3 -m pip install -q pydantic pydantic-settings beautifulsoup4 lxml httpx
fi

# Lancer le menu
python3 test_menu.py
