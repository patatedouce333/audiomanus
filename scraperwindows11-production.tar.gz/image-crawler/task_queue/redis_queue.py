"""
Redis-based queue for distributing crawl tasks.
"""
import json
import logging
from typing import Any

import redis.asyncio as redis

from config import settings

logger = logging.getLogger(__name__)


class CrawlQueue:
    """Redis-based queue for crawl URLs."""

    def __init__(self, queue_name: str = "crawl:queue") -> None:
        """
        Initialize Redis queue.

        Args:
            queue_name: Name of the Redis queue
        """
        self.queue_name = queue_name
        self.redis_client = redis.from_url(
            settings.redis_url,
            encoding="utf-8",
            decode_responses=True,
        )
        logger.info(f"CrawlQueue initialized: {queue_name}")

    async def enqueue(
        self,
        url: str,
        depth: int = 0,
        mode_hint: str = "auto",
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """
        Add URL to the queue.

        Args:
            url: URL to crawl
            depth: Crawl depth
            mode_hint: Suggested parser mode
            metadata: Additional metadata

        Returns:
            True if enqueued successfully
        """
        message = {
            "url": url,
            "depth": depth,
            "mode_hint": mode_hint,
            "metadata": metadata or {},
        }

        try:
            await self.redis_client.rpush(self.queue_name, json.dumps(message))
            logger.debug(f"Enqueued: {url} (depth={depth})")
            return True
        except Exception as e:
            logger.error(f"Failed to enqueue {url}: {e}")
            return False

    async def dequeue(self, timeout: int = 0) -> dict[str, Any] | None:
        """
        Get next URL from the queue (blocking).

        Args:
            timeout: Timeout in seconds (0 = block indefinitely)

        Returns:
            Message dict or None if timeout
        """
        try:
            result = await self.redis_client.blpop(self.queue_name, timeout=timeout)

            if result:
                _, message_json = result
                message = json.loads(message_json)
                logger.debug(f"Dequeued: {message['url']}")
                return message

            return None

        except Exception as e:
            logger.error(f"Failed to dequeue: {e}")
            return None

    async def size(self) -> int:
        """
        Get queue size.

        Returns:
            Number of items in queue
        """
        try:
            return await self.redis_client.llen(self.queue_name)
        except Exception as e:
            logger.error(f"Failed to get queue size: {e}")
            return 0

    async def clear(self) -> bool:
        """
        Clear the queue.

        Returns:
            True if cleared successfully
        """
        try:
            await self.redis_client.delete(self.queue_name)
            logger.info(f"Cleared queue: {self.queue_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to clear queue: {e}")
            return False

    async def close(self) -> None:
        """Close Redis connection."""
        await self.redis_client.close()
        logger.info("CrawlQueue closed")


# Singleton instance
crawl_queue = CrawlQueue()
