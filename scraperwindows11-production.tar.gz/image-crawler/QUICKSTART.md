# Image Crawler - Guide de démarrage rapide

## 🚀 Démarrage rapide (local avec Docker)

### 1. Configuration initiale

```bash
cd image-crawler

# Copier le fichier d'environnement
cp .env.example .env

# Éditer .env avec vos credentials
nano .env
```

### 2. Installer Poetry et dépendances

```bash
# Installer Poetry (si pas déjà installé)
curl -sSL https://install.python-poetry.org | python3 -

# Installer les dépendances
poetry install

# Installer Playwright
poetry run playwright install chromium --with-deps
```

### 3. Configuration GCP (production)

```bash
# Configurer l'infrastructure GCP
./scripts/setup-gcp.sh

# Initialiser la base de données
gcloud sql connect images-db --user=postgres --database=images_db < schema.sql
```

### 4. Lancer en local (Docker Compose)

```bash
# Démarrer Redis et Cloud SQL Proxy
docker-compose up -d redis cloud-sql-proxy

# Ou tout démarrer
docker-compose up
```

### 5. Tester le système

```bash
# Test des parseurs
poetry run pytest tests/ -v

# Lancer un crawl de test
poetry run python orchestrator.py
```

## 📦 Structure du projet

```
image-crawler/
├── config.py              # Configuration centrale
├── models/                # Modèles Pydantic
├── parsers/               # Parseurs (AI + Standard)
├── navigation/            # Playwright pour SPA
├── routing/               # Heuristique de routage
├── pipelines/             # Pipeline Scrapy
├── spiders/               # Spiders Scrapy
├── queue/                 # File Redis
├── storage/               # GCS + Cloud SQL
├── tests/                 # Tests unitaires
└── scripts/               # Scripts de déploiement
```

## 🔧 Commandes utiles

```bash
# Formater le code
poetry run black .
poetry run ruff check .

# Lancer les tests
poetry run pytest
poetry run pytest tests/test_ai_parser.py -v

# Tests de charge
poetry run locust -f tests/load_test.py

# Builder l'image Docker
docker build -t image-crawler:latest .

# Pousser vers GCR
./scripts/build-images.sh

# Déployer sur Cloud Run
./scripts/deploy-cloud-run.sh
```

## 🎯 Prochaines étapes

1. **PHASE 1 - DONE** ✅
   - Structure projet créée
   - Poetry configuré
   - Modèles Pydantic définis
   - Schéma SQL créé

2. **PHASE 2 - En cours** 🚧
   - Parseurs IA et Standard implémentés
   - Navigation Playwright prête
   - Tests unitaires ajoutés

3. **PHASE 3 - À faire** ⏳
   - Tester l'intégration Scrapy + Playwright
   - Optimiser la file Redis
   - Affiner l'heuristique de routage

4. **PHASE 4 - À faire** ⏳
   - Tests de charge (Locust)
   - Validation GCS/Cloud SQL
   - Gestion erreurs améliorée

5. **PHASE 5 - À faire** ⏳
   - Cloud Logging intégration
   - Dashboards Cloud Monitoring
   - Alertes configurées

6. **PHASE 6 - À faire** ⏳
   - Déploiement Cloud Run
   - CI/CD pipeline
   - Production monitoring

## 💡 Conseils

- **API Keys**: Obtenez une clé Firecrawl sur https://firecrawl.dev
- **GCP**: Budget ~$50-100/mois pour dev, ~$500+/mois pour prod
- **Performance**: Ajustez `CONCURRENT_REQUESTS` selon vos besoins
- **Coûts GCS**: Lifecycle policy supprime les images > 365 jours

## 🐛 Troubleshooting

**Playwright ne démarre pas:**
```bash
poetry run playwright install --with-deps chromium
```

**Erreur GCP credentials:**
```bash
export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account-key.json
```

**Redis connection refused:**
```bash
docker-compose up redis
```

**Cloud SQL timeout:**
```bash
docker-compose up cloud-sql-proxy
```
