# Image Crawler - AI-Powered Web Image Extraction

Un système de crawling d'images hybride utilisant l'IA (Firecrawl) et des parseurs standards (BeautifulSoup/Playwright) pour extraire, dédupliquer et stocker des images web sur Google Cloud.

## 🎯 Fonctionnalités

- **Extraction hybride**: IA (Firecrawl) + parseurs standard avec fallback automatique
- **Navigation headless**: Playwright pour SPA, lazy loading et scroll infini
- **Déduplication**: Hash SHA-256 avec vérification en base
- **Stockage cloud**: Google Cloud Storage + Cloud SQL (PostgreSQL)
- **Architecture async**: Scrapy + Redis pour orchestration
- **Observabilité**: Google Cloud Operations Suite (logs, metrics, traces)

## 📋 Prérequis

- Python 3.12+
- Poetry
- Docker & Docker Compose
- Compte Google Cloud Platform (GCS + Cloud SQL + Memorystore Redis)
- Clé API Firecrawl

## 🚀 Installation

### 1. Cloner et installer les dépendances

```bash
cd image-crawler
poetry install
poetry run playwright install chromium --with-deps
```

### 2. Configuration

```bash
cp .env.example .env
# Éditer .env avec vos credentials GCP et Firecrawl
```

### 3. Démarrage local (avec Docker Compose)

```bash
docker-compose up -d
```

## 🏗️ Architecture

```
image-crawler/
├── models/           # Modèles Pydantic
├── parsers/          # Parseurs IA et standard
├── navigation/       # Playwright headless
├── routing/          # Heuristique de routage
├── pipelines/        # Pipeline Scrapy (download, hash, storage)
├── spiders/          # Spiders Scrapy
├── queue/            # Redis producer/worker
├── storage/          # GCS + Cloud SQL
└── tests/            # Tests unitaires et intégration
```

## 📊 Schéma de base de données

```sql
CREATE TABLE images (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    url TEXT NOT NULL,
    alt TEXT,
    width INTEGER,
    height INTEGER,
    sha256 BYTEA NOT NULL,
    gcs_uri TEXT NOT NULL,
    fetched_at TIMESTAMPTZ DEFAULT NOW(),
    source_page TEXT NOT NULL,
    extractor TEXT NOT NULL,
    status SMALLINT DEFAULT 0
);

CREATE UNIQUE INDEX idx_images_sha256 ON images USING HASH (sha256);
CREATE INDEX idx_images_source_page ON images (source_page);
```

## 🧪 Tests

```bash
poetry run pytest
poetry run pytest tests/test_parsers.py -v
poetry run locust -f tests/load_test.py  # Tests de charge
```

## 🚢 Déploiement

### Cloud Run

```bash
./scripts/build-images.sh
./scripts/deploy-cloud-run.sh
```

### GKE

```bash
./scripts/deploy-gke.sh
```

## 📈 Monitoring

- **Logs**: Google Cloud Logging
- **Metrics**: Cloud Monitoring dashboards
- **Alertes**: Taux d'erreur, queue lag, timeouts

## 🔧 Configuration GCP

```bash
# Créer le bucket GCS
gsutil mb -l europe-west1 gs://your-images-bucket

# Créer l'instance Cloud SQL
gcloud sql instances create images-db \
    --database-version=POSTGRES_15 \
    --tier=db-f1-micro \
    --region=europe-west1

# Créer Memorystore Redis
gcloud redis instances create images-queue \
    --size=1 \
    --region=europe-west1 \
    --redis-version=redis_7_2
```

## 📝 Licence

MIT
