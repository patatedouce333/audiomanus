"""
Main Scrapy spider for image crawling.
"""
import logging
from typing import Any, Generator

import scrapy
from scrapy.http import Response

from models import ImageCandidate
from navigation.playwright_navigator import navigator
from parsers.ai_parser import ai_parser
from parsers.standard_parser import standard_parser
from routing.heuristic import router
from config import settings

logger = logging.getLogger(__name__)


class ImageSpider(scrapy.Spider):
    """Spider to crawl and extract images from web pages."""

    name = "image_spider"
    custom_settings = {
        "PLAYWRIGHT_BROWSER_TYPE": "chromium",
    }

    def __init__(self, urls: list[str] | None = None, *args: Any, **kwargs: Any) -> None:
        """
        Initialize spider.

        Args:
            urls: List of seed URLs to crawl
        """
        super().__init__(*args, **kwargs)
        self.start_urls = urls or []
        logger.info(f"ImageSpider initialized with {len(self.start_urls)} URLs")

    def start_requests(self) -> Generator[scrapy.Request, None, None]:
        """Generate initial requests."""
        for url in self.start_urls:
            # Determine if we need Playwright
            parser_mode = router.choose_parser(url)

            if parser_mode == "navigation":
                # Use Playwright for this request
                yield scrapy.Request(
                    url,
                    callback=self.parse_with_navigation,
                    errback=self.handle_error,
                    meta={
                        "playwright": True,
                        "playwright_include_page": True,
                    },
                )
            else:
                # Standard HTTP request
                yield scrapy.Request(
                    url,
                    callback=self.parse,
                    errback=self.handle_error,
                    meta={"parser_mode": parser_mode},
                )

    async def parse(self, response: Response) -> Generator[dict[str, Any], None, None]:
        """
        Parse response using AI or standard parser.

        Args:
            response: Scrapy response

        Yields:
            Image candidate dicts
        """
        url = response.url
        parser_mode = response.meta.get("parser_mode", "ai")

        logger.info(f"Parsing {url} with {parser_mode} parser")

        try:
            if parser_mode == "ai" and settings.use_ai_parser:
                # Use AI parser
                candidates = await ai_parser.extract_images(url)
            elif settings.use_standard_parser:
                # Use standard parser
                candidates = await standard_parser.extract_images(response.text, url)
            else:
                logger.warning(f"No parser available for {url}")
                return

            # Yield each candidate
            for candidate in candidates:
                yield candidate.model_dump()

            logger.info(f"Extracted {len(candidates)} images from {url}")

        except Exception as e:
            logger.error(f"Parse error for {url}: {e}")

            # Try fallback parser
            fallback = router.should_retry_with_fallback(parser_mode, e)
            if fallback and fallback != parser_mode:
                logger.info(f"Retrying {url} with {fallback} parser")
                yield scrapy.Request(
                    url,
                    callback=self.parse if fallback != "navigation" else self.parse_with_navigation,
                    dont_filter=True,
                    meta={"parser_mode": fallback, "retry_count": response.meta.get("retry_count", 0) + 1},
                )

    async def parse_with_navigation(
        self, response: Response
    ) -> Generator[dict[str, Any], None, None]:
        """
        Parse response using Playwright navigation.

        Args:
            response: Scrapy response

        Yields:
            Image candidate dicts
        """
        url = response.url
        logger.info(f"Parsing {url} with navigation parser")

        try:
            # Fetch page with Playwright (scroll, etc.)
            html, image_urls = await navigator.fetch_page_with_scroll(url)

            # Parse HTML with standard parser
            candidates = await standard_parser.extract_images(html, url)

            # Merge with intercepted image URLs
            for img_url in image_urls:
                # Check if not already in candidates
                if not any(str(c.url) == img_url for c in candidates):
                    try:
                        candidate = ImageCandidate(
                            url=img_url,
                            alt=None,
                            width=None,
                            height=None,
                            source_page=url,
                            extractor="navigation",
                        )
                        candidates.append(candidate)
                    except Exception:
                        pass

            # Yield candidates
            for candidate in candidates:
                yield candidate.model_dump()

            logger.info(f"Extracted {len(candidates)} images from {url} (navigation)")

        except Exception as e:
            logger.error(f"Navigation parse error for {url}: {e}")

    def handle_error(self, failure: Any) -> None:
        """Handle request errors."""
        logger.error(f"Request failed: {failure.request.url} - {failure.value}")
