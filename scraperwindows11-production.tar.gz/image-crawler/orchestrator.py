"""
Orchestrator to seed URLs into the queue and manage crawl jobs.
"""
import asyncio
import logging
import sys
from uuid import uuid4

from pydantic import ValidationError

from models import CrawlRequest
from task_queue.redis_queue import crawl_queue
from storage.db_client import db_client

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)

logger = logging.getLogger(__name__)


async def enqueue_crawl_request(request: CrawlRequest) -> str:
    """
    Enqueue crawl request.

    Args:
        request: CrawlRequest object

    Returns:
        Job ID
    """
    job_id = str(uuid4())

    logger.info(f"Enqueueing crawl job {job_id}: {request.job_name}")

    # Insert job record in database
    # (Simplified - you would use db_client to insert into crawl_jobs table)

    # Enqueue each URL
    for url in request.urls:
        await crawl_queue.enqueue(
            url=str(url),
            depth=0,
            mode_hint=request.force_extractor or "auto",
            metadata={"job_id": job_id, "job_name": request.job_name},
        )

    logger.info(f"Enqueued {len(request.urls)} URLs for job {job_id}")
    return job_id


async def main() -> None:
    """Main orchestrator entry point."""
    # Example: Enqueue some test URLs
    test_request = CrawlRequest(
        urls=["https://example.com", "https://httpbin.org/html"],
        job_name="test-crawl",
        max_depth=0,
        force_extractor="auto",
    )

    try:
        job_id = await enqueue_crawl_request(test_request)
        logger.info(f"Started crawl job: {job_id}")

        # Monitor queue size
        while True:
            size = await crawl_queue.size()
            logger.info(f"Queue size: {size}")
            await asyncio.sleep(10)

    except KeyboardInterrupt:
        logger.info("Orchestrator stopped")
    finally:
        await crawl_queue.close()
        db_client.close()


if __name__ == "__main__":
    asyncio.run(main())
