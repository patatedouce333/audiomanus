# ✅ GUIDE DE TEST RAPIDE - Image Crawler

## 🎯 Tests fonctionnels validés

Voici les différentes options testées et fonctionnelles pour vérifier que le projet marche :

---

## Option 1 : Vérification minimale (30 secondes) ✅ **TESTÉ**

```bash
cd image-crawler

# Créer fichier .env minimal
cat > .env << 'EOF'
FIRECRAWL_API_KEY=test_key_local
GCP_PROJECT_ID=test-project
GCS_BUCKET_NAME=test-bucket
CLOUD_SQL_CONNECTION_NAME=test:test:test
CLOUD_SQL_DATABASE=images_db
CLOUD_SQL_USER=postgres
CLOUD_SQL_PASSWORD=test_password
REDIS_HOST=localhost
REDIS_PORT=6379
USE_AI_PARSER=false
USE_STANDARD_PARSER=true
GCP_LOGGING_ENABLED=false
EOF

# Installer dépendances minimales
python3 -m pip install pydantic pydantic-settings beautifulsoup4 lxml

# Lancer test de vérification
python3 verify.py
```

**Résultats attendus :**
```
✅ All modules imported successfully
✅ Extracted 5 images
✅ Router heuristic works
✅ Pydantic models valid
```

---

## Option 2 : Test crawl simple (2 minutes) ✅ **TESTÉ**

```bash
# Installer httpx
python3 -m pip install httpx

# Test avec votre URL
python3 examples/simple_crawl.py https://your-website.com
```

**Ce que ça fait :**
- ✅ Télécharge la page HTML
- ✅ Parse toutes les balises `<img>`, `<picture>`, `srcset`
- ✅ Normalise les URLs relatives
- ✅ Affiche les résultats

**Exemple de sortie :**
```
🔍 Crawling: https://your-site.com
📊 Extracting images...
✅ Found 12 images:

1. https://site.com/image1.jpg
   Alt: Product photo
   Size: 1920x1080

2. https://site.com/banner.png
   Alt: Hero banner
   ...
```

---

## Option 3 : Avec Poetry (recommandé pour dev complet)

```bash
# Installer Poetry
curl -sSL https://install.python-poetry.org | python3 -

# Installer toutes les dépendances
cd image-crawler
poetry install

# Test de vérification
poetry run python verify.py

# Test crawl
poetry run python examples/simple_crawl.py https://your-url.com

# Tests unitaires
poetry run pytest tests/ -v
```

---

## Option 4 : Docker minimal (Redis seulement)

```bash
# Lancer Redis
docker-compose up redis -d

# Tester la connexion
python3 -c "
import asyncio
import sys
sys.path.insert(0, '.')
from task_queue.redis_queue import CrawlQueue

async def test():
    q = CrawlQueue()
    await q.enqueue('https://example.com', depth=0)
    size = await q.size()
    print(f'✅ Redis: {size} items enqueued')
    await q.clear()
    await q.close()
    
asyncio.run(test())
"
```

---

## Option 5 : Playwright (pour SPA avec lazy loading)

```bash
# Installer Playwright
pip install playwright
playwright install chromium --with-deps

# Test avec navigation
python3 examples/playwright_crawl.py https://unsplash.com
```

**Note :** Télécharge ~300MB de Chromium la première fois.

---

## 📋 Checklist de vérification complète

Après avoir lancé les tests, vérifiez :

- [ ] ✅ `verify.py` passe tous les tests (sauf dépendances optionnelles)
- [ ] ✅ `simple_crawl.py` télécharge et parse une page
- [ ] ✅ Le parseur trouve les images (testez avec un site riche en images)
- [ ] ✅ Les URLs relatives sont converties en absolues
- [ ] ⏳ Redis fonctionne (si docker-compose lancé)
- [ ] ⏳ Playwright fonctionne (si installé)

---

## 🐛 Problèmes courants

### "ModuleNotFoundError: No module named 'X'"
```bash
# Solution rapide
python3 -m pip install pydantic pydantic-settings beautifulsoup4 lxml httpx

# Ou avec Poetry
poetry install
```

### "ImportError: cannot import name 'Queue' from 'queue'"
✅ **Déjà corrigé** : Le module `queue/` a été renommé en `task_queue/`

### "5 validation errors for Settings"
```bash
# Créer le fichier .env (voir Option 1)
cp .env.example .env
```

### La page n'a pas d'images
```bash
# Testez avec des sites riches en images :
python3 examples/simple_crawl.py https://unsplash.com
python3 examples/simple_crawl.py https://pexels.com
```

---

## 🎉 Commande tout-en-un de test

```bash
cd image-crawler && \
cat > .env << 'EOF'
FIRECRAWL_API_KEY=test
GCP_PROJECT_ID=test
GCS_BUCKET_NAME=test
CLOUD_SQL_CONNECTION_NAME=t:t:t
CLOUD_SQL_DATABASE=db
CLOUD_SQL_USER=u
CLOUD_SQL_PASSWORD=p
REDIS_HOST=localhost
REDIS_PORT=6379
USE_AI_PARSER=false
EOF
python3 -m pip install -q pydantic pydantic-settings beautifulsoup4 lxml httpx && \
echo "=== Test 1: Verification ===" && \
python3 verify.py && \
echo "" && \
echo "=== Test 2: Crawl simple ===" && \
python3 examples/simple_crawl.py https://example.com && \
echo "" && \
echo "✅ Tous les tests basiques passent!"
```

---

## 🚀 Prochaines étapes après validation

1. **Configurer GCP** (si production) :
   ```bash
   ./scripts/setup-gcp.sh
   ```

2. **Tests unitaires complets** :
   ```bash
   poetry run pytest tests/ -v --cov
   ```

3. **Lancer le système complet** :
   ```bash
   docker-compose up
   ```

4. **Déployer en production** :
   ```bash
   ./scripts/deploy-cloud-run.sh
   ```

---

## 📊 Résumé des options

| Option | Temps | Prérequis | Statut |
|--------|-------|-----------|--------|
| Vérification | 30s | Python + pip | ✅ Testé |
| Crawl simple | 2min | + httpx | ✅ Testé |
| Poetry | 5min | Poetry installé | ✅ Recommandé |
| Redis | 3min | Docker | ⏳ À tester |
| Playwright | 10min | + 300MB download | ⏳ Optionnel |
| Système complet | 15min | + GCP account | ⏳ Production |

**Recommandation :** Commencez par **Option 1** puis **Option 2** pour une validation rapide.
