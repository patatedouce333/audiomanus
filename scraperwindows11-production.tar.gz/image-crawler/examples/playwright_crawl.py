#!/usr/bin/env python3
"""
Test with Playwright navigation (requires Playwright browsers installed).
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from navigation.playwright_navigator import navigator
from parsers.standard_parser import standard_parser


async def test_with_playwright(url: str):
    """Test crawling with Playwright for SPA/lazy loading."""
    print(f"🎭 Testing with Playwright: {url}\n")
    
    try:
        # Fetch with Playwright
        print("⏳ Fetching page (with scroll and lazy loading)...")
        html, intercepted_images = await navigator.fetch_page_with_scroll(
            url,
            max_scrolls=5,
            scroll_delay_ms=(200, 500)
        )
        
        print(f"✅ Fetched {len(html)} bytes of HTML")
        print(f"✅ Intercepted {len(intercepted_images)} image requests\n")
        
        # Parse HTML
        print("📊 Parsing HTML...")
        candidates = await standard_parser.extract_images(html, url)
        
        print(f"✅ Extracted {len(candidates)} images from HTML\n")
        
        # Display results
        print("🖼️  Sample images (first 10):\n")
        all_images = set(str(c.url) for c in candidates) | set(intercepted_images)
        
        for i, img_url in enumerate(list(all_images)[:10], 1):
            print(f"{i}. {img_url}")
        
        if len(all_images) > 10:
            print(f"\n... and {len(all_images) - 10} more images")
        
        print(f"\n📈 Total unique images: {len(all_images)}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        url = sys.argv[1]
    else:
        # Test with a page that has lazy loading
        url = "https://unsplash.com"
        print(f"💡 Usage: python {sys.argv[0]} <url>")
        print(f"   Using default: {url}\n")
    
    asyncio.run(test_with_playwright(url))
