#!/usr/bin/env python3
"""
Simple example: Crawl a single page without full infrastructure.
Useful for quick testing without Docker, Redis, or GCP.
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from parsers.standard_parser import standard_parser


async def simple_crawl(url: str):
    """Crawl a single URL using standard parser (no external dependencies)."""
    print(f"🔍 Crawling: {url}\n")
    
    # Fetch HTML (using httpx or requests)
    import httpx
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.get(url)
        html = response.text
    
    # Parse images
    print("📊 Extracting images...\n")
    candidates = await standard_parser.extract_images(html, url)
    
    # Display results
    print(f"✅ Found {len(candidates)} images:\n")
    
    for i, img in enumerate(candidates, 1):
        print(f"{i}. {img.url}")
        if img.alt:
            print(f"   Alt: {img.alt}")
        if img.width and img.height:
            print(f"   Size: {img.width}x{img.height}")
        print()
    
    print(f"📈 Summary: {len(candidates)} total images extracted")


if __name__ == "__main__":
    # Test URLs (change as needed)
    test_urls = [
        "https://example.com",
        "https://httpbin.org/html",
    ]
    
    if len(sys.argv) > 1:
        url = sys.argv[1]
    else:
        url = test_urls[0]
        print(f"💡 Usage: python {sys.argv[0]} <url>")
        print(f"   Using default: {url}\n")
    
    asyncio.run(simple_crawl(url))
