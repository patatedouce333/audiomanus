"""
Pydantic models for image extraction and storage.
"""
from datetime import datetime
from typing import Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, HttpUrl, field_validator


class ImageCandidate(BaseModel):
    """Image candidate extracted from a web page."""

    url: HttpUrl = Field(..., description="Absolute URL of the image")
    alt: str | None = Field(None, description="Alt text of the image")
    width: int | None = Field(None, ge=1, description="Width in pixels")
    height: int | None = Field(None, ge=1, description="Height in pixels")
    source_page: HttpUrl = Field(..., description="URL of the page containing the image")
    extractor: Literal["ai", "standard", "navigation"] = Field(
        ..., description="Extraction method used"
    )

    @field_validator("url", "source_page")
    @classmethod
    def validate_url_is_absolute(cls, v: HttpUrl) -> HttpUrl:
        """Ensure URLs are absolute."""
        url_str = str(v)
        if not url_str.startswith(("http://", "https://")):
            raise ValueError("URL must be absolute (http:// or https://)")
        return v

    @field_validator("url")
    @classmethod
    def validate_image_extension(cls, v: HttpUrl) -> HttpUrl:
        """Warn if URL doesn't look like an image (optional check)."""
        url_str = str(v).lower()
        # Remove query parameters for extension check
        url_path = url_str.split("?")[0]
        valid_extensions = (
            ".jpg",
            ".jpeg",
            ".png",
            ".gif",
            ".webp",
            ".svg",
            ".bmp",
            ".ico",
            ".avif",
        )
        # Don't raise error, just pass through (some images don't have extensions)
        return v

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "url": "https://example.com/images/photo.jpg",
                "alt": "Beautiful landscape",
                "width": 1920,
                "height": 1080,
                "source_page": "https://example.com/gallery",
                "extractor": "ai",
            }
        }


class ImageMetadata(BaseModel):
    """Extended metadata for stored images."""

    id: UUID = Field(default_factory=uuid4, description="Unique image ID")
    url: str = Field(..., description="Original image URL")
    alt: str | None = Field(None, description="Alt text")
    width: int | None = Field(None, description="Width in pixels")
    height: int | None = Field(None, description="Height in pixels")
    sha256: bytes = Field(..., description="SHA-256 hash of image content")
    gcs_uri: str = Field(..., description="GCS URI (gs://bucket/path)")
    fetched_at: datetime = Field(default_factory=datetime.utcnow, description="Fetch timestamp")
    source_page: str = Field(..., description="Source page URL")
    extractor: Literal["ai", "standard", "navigation"] = Field(..., description="Extractor used")
    status: int = Field(default=0, description="Processing status")
    file_size: int | None = Field(None, ge=0, description="File size in bytes")
    mime_type: str | None = Field(None, description="MIME type")
    metadata: dict | None = Field(None, description="Additional metadata")

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "url": "https://example.com/photo.jpg",
                "alt": "Sunset over mountains",
                "width": 1920,
                "height": 1080,
                "sha256": b"\x9f\x86\xd0\x81...",
                "gcs_uri": "gs://my-bucket/images/2026/01/abc123.jpg",
                "source_page": "https://example.com/gallery",
                "extractor": "ai",
                "file_size": 245678,
                "mime_type": "image/jpeg",
            }
        }


class CrawlRequest(BaseModel):
    """Request to crawl a URL or list of URLs."""

    urls: list[HttpUrl] = Field(..., min_length=1, description="URLs to crawl")
    job_name: str = Field(..., min_length=1, max_length=255, description="Job name")
    max_depth: int = Field(default=0, ge=0, le=10, description="Max crawl depth")
    force_extractor: Literal["ai", "standard", "navigation", "auto"] | None = Field(
        default="auto", description="Force specific extractor or use auto routing"
    )
    config: dict | None = Field(None, description="Additional config options")

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "urls": ["https://example.com/gallery"],
                "job_name": "example-gallery-crawl",
                "max_depth": 2,
                "force_extractor": "auto",
            }
        }


class CrawlStats(BaseModel):
    """Statistics for a crawl job."""

    job_id: UUID = Field(..., description="Job ID")
    job_name: str = Field(..., description="Job name")
    status: Literal["pending", "running", "completed", "failed"] = Field(
        ..., description="Job status"
    )
    images_extracted: int = Field(default=0, ge=0, description="Total images extracted")
    images_stored: int = Field(default=0, ge=0, description="Unique images stored")
    started_at: datetime | None = Field(None, description="Start timestamp")
    completed_at: datetime | None = Field(None, description="Completion timestamp")
    duration_seconds: float | None = Field(None, ge=0, description="Duration in seconds")
    error_count: int = Field(default=0, ge=0, description="Number of errors")
    error_message: str | None = Field(None, description="Error message if failed")

    class Config:
        """Pydantic config."""

        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "job_name": "example-crawl",
                "status": "completed",
                "images_extracted": 1234,
                "images_stored": 987,
                "started_at": "2026-01-14T10:00:00Z",
                "completed_at": "2026-01-14T10:15:30Z",
                "duration_seconds": 930.5,
                "error_count": 3,
            }
        }
