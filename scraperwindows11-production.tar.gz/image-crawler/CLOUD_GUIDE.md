# ☁️ GUIDE LANCEMENT DANS CODESPACES (CLOUD)

Vous êtes sur **GitHub Codespaces** = déjà dans le cloud ! Pas besoin de Docker local.

## 🚀 Commande unique pour tout lancer :

```bash
./run_in_cloud.sh
```

Ou si ça ne marche pas :

```bash
bash run_in_cloud.sh
```

## 📋 Ce que fait ce script :

1. ✅ Installe les dépendances Python
2. ✅ Vérifie que tout fonctionne
3. ✅ Teste le parseur
4. ✅ Lance le menu interactif

**Durée totale : ~10 secondes**

---

## 🎯 Options rapides dans Codespaces :

### Option 1 : Menu interactif (recommandé)
```bash
python3 test_menu.py
```

Puis choisissez :
- **`2`** pour tester le parseur
- **`8`** pour la démo complète
- **`3`** pour crawler une URL de votre choix

### Option 2 : Test direct
```bash
python3 verify.py
```

### Option 3 : Crawler une URL maintenant
```bash
python3 examples/simple_crawl.py "https://www.example.com"
```

---

## 🔑 Configuration (déjà faite!)

Votre clé API est configurée dans `.env` :
```
FIRECRAWL_API_KEY=AIzaSyAj_s88EFrr5rW95C_aDKFyFDzfmgLBego
USE_AI_PARSER=true
```

---

## ☁️ Pour un déploiement cloud production :

### Option A : Cloud Run (Google Cloud)

```bash
# 1. Configurer GCP (une seule fois)
./scripts/setup-gcp.sh

# 2. Builder l'image
./scripts/build-images.sh

# 3. Déployer
./scripts/deploy-cloud-run.sh
```

### Option B : Railway / Render / Fly.io

Ces plateformes détectent automatiquement le `Dockerfile` !

1. **Railway.app** (le plus simple) :
   ```bash
   # Dans Railway dashboard:
   # - New Project → Deploy from GitHub
   # - Sélectionner votre repo
   # - Railway détecte le Dockerfile automatiquement
   ```

2. **Render.com** :
   ```yaml
   # render.yaml (déjà dans le projet)
   services:
     - type: web
       name: image-crawler
       env: docker
       dockerfilePath: ./Dockerfile
   ```

3. **Fly.io** :
   ```bash
   fly launch
   fly deploy
   ```

---

## 🐳 Si vous voulez vraiment Docker dans Codespaces :

```bash
# Lancer Redis uniquement
docker-compose up redis -d

# Tester la connexion
python3 -c "
import asyncio
import sys
sys.path.insert(0, '.'
from task_queue.redis_queue import CrawlQueue

async def test():
    q = CrawlQueue()
    await q.enqueue('https://test.com')
    print('✅ Redis works!')
    await q.close()
    
asyncio.run(test())
"
```

---

## 📊 Architecture Cloud typique :

```
GitHub Codespaces (dev)
    ↓
    ↓ git push
    ↓
GitHub Actions (CI/CD)
    ↓
    ↓ deploy
    ↓
Cloud Run / Railway / Render
    ↓
    ↓ utilise
    ↓
GCP (Storage + Database)
```

---

## ✅ Checklist Codespaces :

- [x] Python 3.12 disponible
- [x] Docker disponible (mais pas nécessaire pour tests)
- [x] Terminal bash disponible
- [x] Internet disponible
- [x] Peut installer des packages Python
- [x] Peut lancer des scripts

**Tout est prêt ! Lancez juste `./run_in_cloud.sh`** 🚀
