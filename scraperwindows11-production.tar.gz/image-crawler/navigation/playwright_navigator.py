"""
Playwright-based navigation for headless browsing.
Handles SPA, lazy loading, and infinite scroll scenarios.
"""
import asyncio
import logging
import random
from typing import Any

from playwright.async_api import Page, async_playwright

from config import settings

logger = logging.getLogger(__name__)


class PlaywrightNavigator:
    """Navigate web pages using Playwright headless browser."""

    def __init__(
        self,
        headless: bool | None = None,
        viewport_width: int | None = None,
        viewport_height: int | None = None,
    ) -> None:
        """Initialize navigator with Playwright settings."""
        self.headless = headless if headless is not None else settings.playwright_headless
        self.viewport_width = viewport_width or settings.playwright_viewport_width
        self.viewport_height = viewport_height or settings.playwright_viewport_height
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        ]
        logger.info("PlaywrightNavigator initialized")

    async def fetch_page_with_scroll(
        self,
        url: str,
        max_scrolls: int = 10,
        scroll_delay_ms: tuple[int, int] = (100, 300),
        wait_for_network_idle: bool = True,
    ) -> tuple[str, list[str]]:
        """
        Fetch page content with infinite scroll support.

        Args:
            url: URL to fetch
            max_scrolls: Maximum number of scroll iterations
            scroll_delay_ms: Random delay range between scrolls (min, max)
            wait_for_network_idle: Wait for network to be idle after scrolling

        Returns:
            Tuple of (HTML content, list of intercepted image URLs)
        """
        logger.info(f"Fetching {url} with Playwright (max_scrolls={max_scrolls})")

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=self.headless)

            context = await browser.new_context(
                viewport={"width": self.viewport_width, "height": self.viewport_height},
                user_agent=random.choice(self.user_agents),
                locale="en-US",
                timezone_id="America/New_York",
            )

            page = await context.new_page()

            # Intercept image requests
            image_urls: list[str] = []

            async def handle_response(response: Any) -> None:
                """Capture image responses."""
                content_type = response.headers.get("content-type", "")
                if "image/" in content_type:
                    image_urls.append(response.url)

            page.on("response", handle_response)

            try:
                # Navigate to page
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)

                # Wait for initial content
                if wait_for_network_idle:
                    await page.wait_for_load_state("networkidle", timeout=10000)

                # Perform infinite scroll
                await self._infinite_scroll(page, max_scrolls, scroll_delay_ms, wait_for_network_idle)

                # Get final HTML
                html = await page.content()

                logger.info(
                    f"Fetched {url}: {len(html)} bytes HTML, {len(image_urls)} images intercepted"
                )

                return html, image_urls

            finally:
                await browser.close()

    async def _infinite_scroll(
        self,
        page: Page,
        max_scrolls: int,
        scroll_delay_ms: tuple[int, int],
        wait_for_network_idle: bool,
    ) -> None:
        """
        Perform infinite scroll on the page.

        Args:
            page: Playwright page object
            max_scrolls: Maximum scroll iterations
            scroll_delay_ms: Delay range between scrolls
            wait_for_network_idle: Whether to wait for network idle
        """
        previous_height = await page.evaluate("document.body.scrollHeight")

        for i in range(max_scrolls):
            # Scroll to bottom
            await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")

            # Random delay to simulate human behavior
            delay = random.randint(*scroll_delay_ms)
            await asyncio.sleep(delay / 1000)

            # Wait for potential lazy loading
            if wait_for_network_idle:
                try:
                    await page.wait_for_load_state("networkidle", timeout=3000)
                except Exception:
                    pass  # Timeout is ok, content might still load

            # Check if page height changed
            new_height = await page.evaluate("document.body.scrollHeight")

            if new_height == previous_height:
                logger.debug(f"No new content after scroll {i+1}, stopping")
                break

            previous_height = new_height
            logger.debug(f"Scroll {i+1}/{max_scrolls}: new height = {new_height}")

        # Scroll back to top for final capture
        await page.evaluate("window.scrollTo(0, 0)")

    async def simulate_interactions(self, page: Page) -> None:
        """
        Simulate mouse movements and clicks to bypass anti-bot measures.

        Args:
            page: Playwright page object
        """
        # Move mouse randomly
        for _ in range(random.randint(2, 5)):
            x = random.randint(100, self.viewport_width - 100)
            y = random.randint(100, self.viewport_height - 100)
            await page.mouse.move(x, y)
            await asyncio.sleep(random.uniform(0.1, 0.3))

    async def click_load_more_buttons(self, page: Page, max_clicks: int = 5) -> int:
        """
        Find and click "Load More" buttons.

        Args:
            page: Playwright page object
            max_clicks: Maximum number of times to click

        Returns:
            Number of successful clicks
        """
        selectors = [
            'button:has-text("Load More")',
            'button:has-text("Show More")',
            'a:has-text("Load More")',
            'button[class*="load-more"]',
            'button[class*="show-more"]',
        ]

        clicks = 0
        for _ in range(max_clicks):
            clicked = False

            for selector in selectors:
                try:
                    button = page.locator(selector).first
                    if await button.is_visible(timeout=1000):
                        await button.click()
                        await asyncio.sleep(random.uniform(0.5, 1.5))
                        clicks += 1
                        clicked = True
                        logger.debug(f"Clicked load more button: {selector}")
                        break
                except Exception:
                    continue

            if not clicked:
                break

        return clicks


# Singleton instance
navigator = PlaywrightNavigator()
