#!/usr/bin/env python3
"""
Lance le crawler d'images - TEST EN VRAI
"""
import subprocess
import sys
from pathlib import Path

print("🚀 LANCEMENT DU CRAWLER D'IMAGES")
print("=" * 60)

# URLs à crawler
urls = [
    "https://httpbin.org/html",
    "https://www.pexels.com",
    "https://unsplash.com",
]

print("\n📋 URLs qui seront crawlées:")
for i, url in enumerate(urls, 1):
    print(f"  {i}. {url}")

print("\n" + "=" * 60)
input("⏎ Appuyez sur Entrée pour lancer le crawl...")

# Lancer Scrapy
print("\n🕷️  Lancement de Scrapy...\n")

# Créer une liste d'URLs pour scrapy
urls_arg = ",".join(urls)

# Lancer le spider
cmd = [
    sys.executable,
    "-m",
    "scrapy",
    "runspider",
    "spiders/image_spider.py",
    "-a",
    f"start_urls={urls_arg}",
    "-s",
    "LOG_LEVEL=INFO",
]

subprocess.run(cmd, cwd=Path(__file__).parent)
