"""
Unit tests for AI parser.
"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from parsers.ai_parser import AIParser, ai_parser
from models import ImageCandidate


@pytest.fixture
def mock_firecrawl_response():
    """Mock Firecrawl API response."""
    return {
        "extract": {
            "images": [
                {
                    "url": "https://example.com/image1.jpg",
                    "alt": "Test image 1",
                    "width": 1920,
                    "height": 1080,
                },
                {
                    "url": "https://example.com/image2.png",
                    "alt": "Test image 2",
                    "width": 800,
                    "height": 600,
                },
            ]
        }
    }


@pytest.mark.asyncio
async def test_ai_parser_extract_images(mock_firecrawl_response):
    """Test AI parser extracts images correctly."""
    parser = AIParser(api_key="test_key")

    with patch.object(parser.client, "scrape_url", return_value=mock_firecrawl_response):
        candidates = await parser.extract_images("https://example.com")

        assert len(candidates) == 2
        assert all(isinstance(c, ImageCandidate) for c in candidates)
        assert candidates[0].url == "https://example.com/image1.jpg"
        assert candidates[0].alt == "Test image 1"
        assert candidates[0].extractor == "ai"


@pytest.mark.asyncio
async def test_ai_parser_empty_response():
    """Test AI parser handles empty response."""
    parser = AIParser(api_key="test_key")

    with patch.object(parser.client, "scrape_url", return_value={"extract": {"images": []}}):
        candidates = await parser.extract_images("https://example.com")

        assert len(candidates) == 0


@pytest.mark.asyncio
async def test_ai_parser_error_handling():
    """Test AI parser error handling."""
    parser = AIParser(api_key="test_key")

    with patch.object(parser.client, "scrape_url", side_effect=Exception("API Error")):
        with pytest.raises(Exception):
            await parser.extract_images("https://example.com")
