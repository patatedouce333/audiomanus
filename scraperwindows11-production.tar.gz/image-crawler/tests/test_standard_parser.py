"""
Unit tests for standard parser.
"""
import pytest

from parsers.standard_parser import StandardParser
from models import ImageCandidate


@pytest.fixture
def sample_html():
    """Sample HTML with various image types."""
    return """
    <!DOCTYPE html>
    <html>
    <body>
        <img src="/relative/image.jpg" alt="Relative image" width="800" height="600">
        <img src="https://example.com/absolute.png" alt="Absolute image" data-lazy="true">
        <img data-src="https://example.com/lazy.webp" alt="Lazy loaded">
        <picture>
            <source srcset="https://example.com/pic1.webp 1x, https://example.com/pic2.webp 2x">
            <img src="https://example.com/fallback.jpg">
        </picture>
        <div style="background-image: url('https://example.com/bg.jpg');"></div>
    </body>
    </html>
    """


@pytest.mark.asyncio
async def test_standard_parser_extract_images(sample_html):
    """Test standard parser extracts images correctly."""
    parser = StandardParser()
    candidates = await parser.extract_images(sample_html, "https://example.com")

    assert len(candidates) > 0
    assert all(isinstance(c, ImageCandidate) for c in candidates)
    assert all(c.extractor == "standard" for c in candidates)


@pytest.mark.asyncio
async def test_standard_parser_relative_urls():
    """Test standard parser resolves relative URLs."""
    parser = StandardParser()
    html = '<img src="/images/test.jpg" alt="Test">'

    candidates = await parser.extract_images(html, "https://example.com/page")

    assert len(candidates) == 1
    assert str(candidates[0].url) == "https://example.com/images/test.jpg"


@pytest.mark.asyncio
async def test_standard_parser_deduplication():
    """Test standard parser deduplicates images."""
    parser = StandardParser()
    html = '''
        <img src="https://example.com/same.jpg" alt="First">
        <img src="https://example.com/same.jpg" alt="Duplicate">
    '''

    candidates = await parser.extract_images(html, "https://example.com")

    # Should deduplicate
    urls = [str(c.url) for c in candidates]
    assert len(set(urls)) == len(urls)


@pytest.mark.asyncio
async def test_standard_parser_srcset():
    """Test standard parser handles srcset."""
    parser = StandardParser()
    html = '<img srcset="https://example.com/small.jpg 1x, https://example.com/large.jpg 2x">'

    candidates = await parser.extract_images(html, "https://example.com")

    assert len(candidates) >= 1
    assert "example.com" in str(candidates[0].url)
