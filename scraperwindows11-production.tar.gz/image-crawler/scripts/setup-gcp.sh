#!/bin/bash
# GCP setup script for image-crawler infrastructure

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Image Crawler - GCP Infrastructure Setup${NC}"
echo -e "${GREEN}========================================${NC}"

# Check if gcloud is installed
if ! command -v gcloud &> /dev/null; then
    echo -e "${RED}ERROR: gcloud CLI not found. Please install it first.${NC}"
    exit 1
fi

# Load environment variables
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
else
    echo -e "${YELLOW}WARNING: .env file not found. Using defaults.${NC}"
fi

# Set defaults
PROJECT_ID=${GCP_PROJECT_ID:-"my-image-crawler-project"}
REGION=${GCP_REGION:-"europe-west1"}
BUCKET_NAME=${GCS_BUCKET_NAME:-"${PROJECT_ID}-images"}
DB_INSTANCE_NAME=${CLOUD_SQL_INSTANCE_NAME:-"images-db"}
DB_NAME=${CLOUD_SQL_DATABASE:-"images_db"}
DB_USER=${CLOUD_SQL_USER:-"postgres"}
REDIS_INSTANCE_NAME=${REDIS_INSTANCE_NAME:-"images-queue"}

echo ""
echo -e "${YELLOW}Configuration:${NC}"
echo "  Project ID: $PROJECT_ID"
echo "  Region: $REGION"
echo "  Bucket: $BUCKET_NAME"
echo "  DB Instance: $DB_INSTANCE_NAME"
echo "  Redis Instance: $REDIS_INSTANCE_NAME"
echo ""

read -p "Continue with this configuration? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    exit 0
fi

# Set project
echo -e "${GREEN}[1/7] Setting GCP project...${NC}"
gcloud config set project "$PROJECT_ID"

# Enable APIs
echo -e "${GREEN}[2/7] Enabling required APIs...${NC}"
gcloud services enable \
    compute.googleapis.com \
    storage.googleapis.com \
    sqladmin.googleapis.com \
    redis.googleapis.com \
    cloudrun.googleapis.com \
    container.googleapis.com \
    logging.googleapis.com \
    monitoring.googleapis.com \
    --project="$PROJECT_ID"

# Create GCS bucket
echo -e "${GREEN}[3/7] Creating GCS bucket...${NC}"
if gsutil ls "gs://$BUCKET_NAME" 2>/dev/null; then
    echo -e "${YELLOW}  Bucket already exists: gs://$BUCKET_NAME${NC}"
else
    gsutil mb -l "$REGION" "gs://$BUCKET_NAME"
    gsutil versioning set off "gs://$BUCKET_NAME"
    gsutil lifecycle set - "gs://$BUCKET_NAME" <<EOF
{
  "lifecycle": {
    "rule": [
      {
        "action": {"type": "Delete"},
        "condition": {"age": 365}
      }
    ]
  }
}
EOF
    echo -e "${GREEN}  Created bucket: gs://$BUCKET_NAME${NC}"
fi

# Create Cloud SQL instance
echo -e "${GREEN}[4/7] Creating Cloud SQL instance...${NC}"
if gcloud sql instances describe "$DB_INSTANCE_NAME" --project="$PROJECT_ID" 2>/dev/null; then
    echo -e "${YELLOW}  Cloud SQL instance already exists: $DB_INSTANCE_NAME${NC}"
else
    gcloud sql instances create "$DB_INSTANCE_NAME" \
        --database-version=POSTGRES_15 \
        --tier=db-f1-micro \
        --region="$REGION" \
        --network=default \
        --no-assign-ip \
        --project="$PROJECT_ID"
    
    # Set root password
    echo -e "${YELLOW}  Setting database password...${NC}"
    DB_PASSWORD=$(openssl rand -base64 32)
    gcloud sql users set-password "$DB_USER" \
        --instance="$DB_INSTANCE_NAME" \
        --password="$DB_PASSWORD" \
        --project="$PROJECT_ID"
    
    echo -e "${GREEN}  Created Cloud SQL instance: $DB_INSTANCE_NAME${NC}"
    echo -e "${YELLOW}  Database password: $DB_PASSWORD${NC}"
    echo -e "${YELLOW}  (Save this password securely!)${NC}"
fi

# Create database
echo -e "${GREEN}[5/7] Creating database...${NC}"
gcloud sql databases create "$DB_NAME" \
    --instance="$DB_INSTANCE_NAME" \
    --project="$PROJECT_ID" \
    2>/dev/null || echo -e "${YELLOW}  Database already exists: $DB_NAME${NC}"

# Create Memorystore Redis instance
echo -e "${GREEN}[6/7] Creating Redis instance...${NC}"
if gcloud redis instances describe "$REDIS_INSTANCE_NAME" --region="$REGION" --project="$PROJECT_ID" 2>/dev/null; then
    echo -e "${YELLOW}  Redis instance already exists: $REDIS_INSTANCE_NAME${NC}"
else
    gcloud redis instances create "$REDIS_INSTANCE_NAME" \
        --size=1 \
        --region="$REGION" \
        --redis-version=redis_7_2 \
        --project="$PROJECT_ID"
    echo -e "${GREEN}  Created Redis instance: $REDIS_INSTANCE_NAME${NC}"
fi

# Create service account
echo -e "${GREEN}[7/7] Creating service account...${NC}"
SA_NAME="image-crawler-sa"
SA_EMAIL="${SA_NAME}@${PROJECT_ID}.iam.gserviceaccount.com"

if gcloud iam service-accounts describe "$SA_EMAIL" --project="$PROJECT_ID" 2>/dev/null; then
    echo -e "${YELLOW}  Service account already exists: $SA_EMAIL${NC}"
else
    gcloud iam service-accounts create "$SA_NAME" \
        --display-name="Image Crawler Service Account" \
        --project="$PROJECT_ID"
fi

# Grant IAM roles
echo -e "${YELLOW}  Granting IAM roles...${NC}"
gcloud projects add-iam-policy-binding "$PROJECT_ID" \
    --member="serviceAccount:$SA_EMAIL" \
    --role="roles/storage.objectAdmin" \
    --condition=None

gcloud projects add-iam-policy-binding "$PROJECT_ID" \
    --member="serviceAccount:$SA_EMAIL" \
    --role="roles/cloudsql.client" \
    --condition=None

gcloud projects add-iam-policy-binding "$PROJECT_ID" \
    --member="serviceAccount:$SA_EMAIL" \
    --role="roles/logging.logWriter" \
    --condition=None

# Download service account key
echo -e "${YELLOW}  Downloading service account key...${NC}"
gcloud iam service-accounts keys create "service-account-key.json" \
    --iam-account="$SA_EMAIL" \
    --project="$PROJECT_ID"

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Setup Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo "  1. Update .env file with the following:"
echo "     CLOUD_SQL_CONNECTION_NAME=$PROJECT_ID:$REGION:$DB_INSTANCE_NAME"
echo "     GOOGLE_APPLICATION_CREDENTIALS=./service-account-key.json"
echo ""
echo "  2. Initialize the database schema:"
echo "     gcloud sql connect $DB_INSTANCE_NAME --user=$DB_USER --database=$DB_NAME < schema.sql"
echo ""
echo "  3. Test the connection:"
echo "     docker-compose up"
echo ""
echo -e "${GREEN}Done!${NC}"
