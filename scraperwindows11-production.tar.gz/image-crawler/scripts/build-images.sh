#!/bin/bash
# Build Docker images for image-crawler

set -e

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}Building Docker images...${NC}"

# Load env vars
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

PROJECT_ID=${GCP_PROJECT_ID:-"my-project"}
REGION=${GCP_REGION:-"europe-west1"}
IMAGE_NAME="image-crawler"
VERSION=${VERSION:-"latest"}

# Build image
echo -e "${YELLOW}Building $IMAGE_NAME:$VERSION...${NC}"
docker build -t "$IMAGE_NAME:$VERSION" .

# Tag for GCR
GCR_IMAGE="gcr.io/$PROJECT_ID/$IMAGE_NAME:$VERSION"
docker tag "$IMAGE_NAME:$VERSION" "$GCR_IMAGE"

echo -e "${GREEN}Built images:${NC}"
echo "  - $IMAGE_NAME:$VERSION"
echo "  - $GCR_IMAGE"

# Push to GCR (optional)
read -p "Push to Google Container Registry? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Pushing to GCR...${NC}"
    docker push "$GCR_IMAGE"
    echo -e "${GREEN}Pushed to GCR!${NC}"
fi

echo -e "${GREEN}Done!${NC}"
