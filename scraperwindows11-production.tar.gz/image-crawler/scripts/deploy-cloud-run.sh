#!/bin/bash
# Deploy to Cloud Run

set -e

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}Deploying to Cloud Run...${NC}"

# Load env
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

PROJECT_ID=${GCP_PROJECT_ID}
REGION=${GCP_REGION:-"europe-west1"}
SERVICE_NAME="image-crawler"
IMAGE="gcr.io/$PROJECT_ID/image-crawler:latest"

echo -e "${YELLOW}Deploying $SERVICE_NAME...${NC}"

gcloud run deploy "$SERVICE_NAME" \
    --image="$IMAGE" \
    --platform=managed \
    --region="$REGION" \
    --allow-unauthenticated \
    --memory=2Gi \
    --cpu=2 \
    --timeout=300 \
    --max-instances=10 \
    --set-env-vars="GCP_PROJECT_ID=$PROJECT_ID,GCS_BUCKET_NAME=$GCS_BUCKET_NAME" \
    --set-secrets="FIRECRAWL_API_KEY=firecrawl-api-key:latest" \
    --add-cloudsql-instances="$CLOUD_SQL_CONNECTION_NAME" \
    --service-account="image-crawler-sa@$PROJECT_ID.iam.gserviceaccount.com" \
    --project="$PROJECT_ID"

echo -e "${GREEN}Deployment complete!${NC}"

# Get service URL
SERVICE_URL=$(gcloud run services describe "$SERVICE_NAME" \
    --region="$REGION" \
    --project="$PROJECT_ID" \
    --format="value(status.url)")

echo -e "${GREEN}Service URL: $SERVICE_URL${NC}"
