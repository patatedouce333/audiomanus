"""
Configuration settings for the image crawler.
Loads from environment variables using pydantic-settings.
"""
from typing import Literal
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Firecrawl API
    firecrawl_api_key: str = Field(..., description="Firecrawl API key")

    # Google Cloud Platform
    gcp_project_id: str = Field(..., description="GCP Project ID")
    gcs_bucket_name: str = Field(..., description="GCS bucket name for images")
    google_application_credentials: str | None = Field(
        None, description="Path to GCP service account JSON"
    )

    # Cloud SQL
    cloud_sql_connection_name: str = Field(
        ..., description="Cloud SQL connection name (project:region:instance)"
    )
    cloud_sql_database: str = Field(default="images_db", description="Database name")
    cloud_sql_user: str = Field(default="postgres", description="Database user")
    cloud_sql_password: str = Field(..., description="Database password")

    # Redis
    redis_host: str = Field(default="localhost", description="Redis host")
    redis_port: int = Field(default=6379, description="Redis port")
    redis_db: int = Field(default=0, description="Redis database number")
    redis_password: str = Field(default="", description="Redis password")

    # Scrapy settings
    concurrent_requests: int = Field(default=16, description="Concurrent requests")
    download_timeout: int = Field(default=30, description="Download timeout in seconds")
    retry_times: int = Field(default=3, description="Number of retries")

    # Playwright
    playwright_headless: bool = Field(default=True, description="Run Playwright headless")
    playwright_viewport_width: int = Field(default=1280, description="Viewport width")
    playwright_viewport_height: int = Field(default=720, description="Viewport height")

    # Feature flags
    use_ai_parser: bool = Field(default=True, description="Enable AI parser")
    use_standard_parser: bool = Field(default=True, description="Enable standard parser")
    use_navigation: bool = Field(default=True, description="Enable navigation parser")

    # Logging
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = Field(
        default="INFO", description="Log level"
    )
    gcp_logging_enabled: bool = Field(
        default=True, description="Enable GCP Cloud Logging"
    )

    @field_validator("concurrent_requests")
    @classmethod
    def validate_concurrent_requests(cls, v: int) -> int:
        """Validate concurrent requests is reasonable."""
        if v < 1 or v > 100:
            raise ValueError("concurrent_requests must be between 1 and 100")
        return v

    @property
    def redis_url(self) -> str:
        """Build Redis connection URL."""
        auth = f":{self.redis_password}@" if self.redis_password else ""
        return f"redis://{auth}{self.redis_host}:{self.redis_port}/{self.redis_db}"


# Global settings instance
settings = Settings()
