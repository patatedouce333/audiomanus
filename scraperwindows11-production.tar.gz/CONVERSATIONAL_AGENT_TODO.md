# To-Do List : Implémentation de l'Agent Conversationnel

Ce document décrit les tâches nécessaires pour transformer le worker actuel en un agent conversationnel interactif et doté de mémoire.

---

### ✅ Phase 1 : Mémoire Persistante (Socle Technique) - TERMINÉE

**Objectif :** Donner une mémoire à l'agent.

*   **[x] Tâche 1.1 & 1.2 : Modèle et Mise à Jour de la Base de Données**
*   **[x] Tâche 1.3 : Création d'un "Gestionnaire de Mémoire"**
*   **[x] Tâche 1.4 : Intégration dans la Logique de l'Agent**

---

### ⏳ Phase 2 : Streaming et Faible Latence (Interaction en Temps Réel) - EN COURS

**Objectif :** Rendre l'agent réactif.

*   **[x] Tâche 2.1 : Endpoint de Streaming**
    *   **Action :** Créé un endpoint `/chat/stream` dans `api.py` qui utilise une `StreamingResponse`.

*   **[x] Tâche 2.2 : Mettre à Jour l'Agent pour le Streaming**
    *   **Action :** Créé une méthode `generate_chat_response_stream` dans `vertex_ai_transcriber.py` qui `yield` les morceaux de réponse depuis l'API de streaming de Gemini.

*   **[ ] Tâche 2.3 : Mettre à Jour le Frontend**
    *   **Action :** Modifier le client pour qu'il consomme l'endpoint `/chat/stream` et affiche le texte au fur et à mesure de sa réception.
    *   **STATUT : EN ATTENTE -** Code du frontend non disponible.

---

### Phase 3 : Interruptibilité

**Objectif :** Permettre à l'utilisateur d'interrompre l'agent.

*   **[ ] Tâche 3.1 : Détection de l'Interruption (Frontend)**
*   **[ ] Tâche 3.2 : Signal d'Interruption (WebSocket)**
*   **[ ] Tâche 3.3 : Gestion de l'Interruption (Backend)**

---

### Phase 4 : Injection de Contexte (Fallback)

**Objectif :** Permettre de "guider" la conversation manuellement.

*   **[ ] Tâche 4.1 : Endpoint d'Injection de Contexte**
*   **[ ] Tâche 4.2 : Interface d'Injection (Frontend)**
