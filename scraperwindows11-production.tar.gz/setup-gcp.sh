#!/usr/bin/env bash
set -euo pipefail

# Configuration projet
PROJECT_ID="project-91ffa63d-6bed-405c-bc3"
REGION="europe-west1"
SERVICE_ACCOUNT="app-ia-backend@project-91ffa63d-6bed-405c-bc3.iam.gserviceaccount.com"
TOPIC="scraper-topic"
SUBSCRIPTION="scraper-agent-sub"
BUCKET="scraper-results-${PROJECT_ID}"

# Couleurs pour l'affichage
RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
NC="\033[0m"

info() { echo -e "${YELLOW}[*]${NC} $*"; }
ok()   { echo -e "${GREEN}[OK]${NC} $*"; }
err()  { echo -e "${RED}[ERR]${NC} $*"; }

require_cmd() {
	if ! command -v "$1" >/dev/null 2>&1; then
		err "Commande requise manquante: $1"
		exit 1
	fi
}

require_cmd gcloud
require_cmd gsutil
require_cmd openssl

info "Vérification de l'authentification gcloud"
ACCOUNTS="$(gcloud auth list --format="value(account)" 2>/dev/null || true)"
if [[ -z "${ACCOUNTS}" ]]; then
	err "Aucun compte gcloud n'est authentifié dans ce conteneur."
	err "Lance (mode headless): gcloud auth login --no-launch-browser"
	exit 1
fi

ACTIVE_ACCOUNT="$(gcloud config get-value account 2>/dev/null || true)"
if [[ -z "${ACTIVE_ACCOUNT}" ]]; then
	ACTIVE_ACCOUNT="$(printf '%s\n' "${ACCOUNTS}" | head -n 1)"
fi
ok "Compte détecté: ${ACTIVE_ACCOUNT}"

info "Configuration du projet par défaut"
gcloud config set project "${PROJECT_ID}" --quiet
ok "Projet configuré: ${PROJECT_ID}"

info "Activation des APIs nécessaires"
gcloud services enable \
	run.googleapis.com \
	pubsub.googleapis.com \
	sqladmin.googleapis.com \
	storage.googleapis.com \
	artifactregistry.googleapis.com \
	cloudbuild.googleapis.com \
	--quiet
ok "APIs activées (ou déjà actives)"

info "Vérification/création du topic Pub/Sub"
if gcloud pubsub topics describe "${TOPIC}" >/dev/null 2>&1; then
	ok "Topic déjà présent: ${TOPIC}"
else
	gcloud pubsub topics create "${TOPIC}" --project="${PROJECT_ID}" --quiet
	ok "Topic créé: ${TOPIC}"
fi

info "Vérification/création de la subscription Pub/Sub"
if gcloud pubsub subscriptions describe "${SUBSCRIPTION}" >/dev/null 2>&1; then
	ok "Subscription déjà présente: ${SUBSCRIPTION}"
else
	gcloud pubsub subscriptions create "${SUBSCRIPTION}" \
		--topic="${TOPIC}" \
		--ack-deadline=600 \
		--max-retry-delay=60s \
		--quiet
	ok "Subscription créée: ${SUBSCRIPTION}"
fi

info "Vérification/création du bucket Cloud Storage"
if gsutil ls -b "gs://${BUCKET}" >/dev/null 2>&1; then
	ok "Bucket déjà présent: gs://${BUCKET}"
else
	gsutil mb -p "${PROJECT_ID}" -c STANDARD -l "${REGION}" "gs://${BUCKET}"
	ok "Bucket créé: gs://${BUCKET}"
fi

info "Vérification/création de l'instance Cloud SQL Postgres"
SQL_INSTANCE="scraper-db"
SQL_DB="scraper"
SQL_USER="scraper_user"
SQL_PASSWORD=""

if gcloud sql instances describe "${SQL_INSTANCE}" --project="${PROJECT_ID}" >/dev/null 2>&1; then
	ok "Instance déjà présente: ${SQL_INSTANCE}"
else
	gcloud sql instances create "${SQL_INSTANCE}" \
		--project="${PROJECT_ID}" \
		--database-version=POSTGRES_15 \
		--tier=db-f1-micro \
		--region="${REGION}" \
		--quiet
	ok "Instance créée: ${SQL_INSTANCE}"
fi

info "Vérification/création de la base de données ${SQL_DB}"
if gcloud sql databases describe "${SQL_DB}" --instance="${SQL_INSTANCE}" --project="${PROJECT_ID}" >/dev/null 2>&1; then
	ok "Base déjà présente: ${SQL_DB}"
else
	gcloud sql databases create "${SQL_DB}" --instance="${SQL_INSTANCE}" --project="${PROJECT_ID}" --quiet
	ok "Base créée: ${SQL_DB}"
fi

info "Vérification/création de l'utilisateur ${SQL_USER}"
if gcloud sql users list --instance="${SQL_INSTANCE}" --project="${PROJECT_ID}" --format="value(name)" | grep -Fx "${SQL_USER}" >/dev/null 2>&1; then
	ok "Utilisateur déjà présent: ${SQL_USER} (mot de passe non modifié)"
else
	SQL_PASSWORD="$(openssl rand -base64 18)"
	gcloud sql users create "${SQL_USER}" \
		--instance="${SQL_INSTANCE}" \
		--project="${PROJECT_ID}" \
		--password="${SQL_PASSWORD}" \
		--quiet
	ok "Utilisateur créé: ${SQL_USER}"
fi

info "Vérification/création du repository Artifact Registry"
AR_REPO="scraper-images"
if gcloud artifacts repositories describe "${AR_REPO}" --location="${REGION}" --project="${PROJECT_ID}" >/dev/null 2>&1; then
	ok "Repository déjà présent: ${AR_REPO} (${REGION})"
else
	gcloud artifacts repositories create "${AR_REPO}" \
		--repository-format=docker \
		--location="${REGION}" \
		--description="Images crawl4ai agents" \
		--project="${PROJECT_ID}" \
		--quiet
	ok "Repository créé: ${AR_REPO} (${REGION})"
fi

echo
ok "Résumé de configuration"
cat <<EOF
Projet           : ${PROJECT_ID}
Région           : ${REGION}
Service Account  : ${SERVICE_ACCOUNT}
Topic Pub/Sub    : ${TOPIC}
Subscription     : ${SUBSCRIPTION}
Bucket Storage   : gs://${BUCKET}
Cloud SQL        : instance=${SQL_INSTANCE}, db=${SQL_DB}, user=${SQL_USER}
Artifact Repo    : ${AR_REPO} (region ${REGION})

Commande de test:
gcloud pubsub topics publish ${TOPIC} --message='{"url":"https://example.com"}'

Commande docker pour push image agent:
docker tag crawl4ai-agent:latest ${REGION}-docker.pkg.dev/${PROJECT_ID}/${AR_REPO}/crawl4ai-agent:latest
docker push ${REGION}-docker.pkg.dev/${PROJECT_ID}/${AR_REPO}/crawl4ai-agent:latest
EOF

if [[ -n "${SQL_PASSWORD}" ]]; then
	echo
	info "Mot de passe généré pour l'utilisateur ${SQL_USER} (conserve-le en lieu sûr)"
	echo "${SQL_PASSWORD}"
fi
