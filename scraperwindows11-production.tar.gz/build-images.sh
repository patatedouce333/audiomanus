#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="project-91ffa63d-6bed-405c-bc3"
REGION="europe-west1"
REPO="scraper-images"

echo "Building and pushing agent image..."
cd agent
gcloud builds submit \
  --tag="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/crawl4ai-agent:latest" \
  --project="${PROJECT_ID}" \
  --timeout=30m

echo "Building and pushing orchestrator image..."
cd ../orchestrator
gcloud builds submit \
  --tag="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/scraper-orchestrator:latest" \
  --project="${PROJECT_ID}"

echo "✅ Images built and pushed successfully!"
