#!/bin/bash
set -e

##############################################################################
# Script de Monitoring Complet - YouTube Transcription
# Combine monitoring base de données + analyse des logs
##############################################################################

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║        MONITORING COMPLET - YouTube Transcription              ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}\n"

# 1. Vérifier que les services sont actifs
echo -e "${CYAN}[1/4] Vérification des services...${NC}"
if docker ps | grep -q youtube-worker; then
    echo -e "${GREEN}✅ Worker actif${NC}"
else
    echo -e "${RED}❌ Worker non actif${NC}"
    exit 1
fi

if docker ps | grep -q youtube-api; then
    echo -e "${GREEN}✅ API active${NC}"
else
    echo -e "${YELLOW}⚠️  API non active${NC}"
fi

if docker ps | grep -q db; then
    echo -e "${GREEN}✅ Database active${NC}"
else
    echo -e "${RED}❌ Database non active${NC}"
    exit 1
fi

echo ""

# 2. Monitoring base de données
echo -e "${CYAN}[2/4] Récupération des métriques de base de données...${NC}\n"
if docker exec youtube-worker python3 monitoring.py 2>/dev/null; then
    echo -e "${GREEN}✅ Dashboard base de données généré${NC}\n"
else
    echo -e "${RED}❌ Erreur lors de la récupération des données${NC}"
    echo -e "${YELLOW}Vérifiez que la base de données est accessible${NC}\n"
fi

# 3. Analyse des logs récents (dernières 500 lignes)
echo -e "${CYAN}[3/4] Analyse des logs récents...${NC}\n"
if docker logs youtube-worker --tail 500 2>/dev/null | docker exec -i youtube-worker python3 logs_analyzer.py; then
    echo -e "${GREEN}✅ Analyse des logs terminée${NC}\n"
else
    echo -e "${YELLOW}⚠️  Analyse des logs partiellement réussie${NC}\n"
fi

# 4. Résumé rapide
echo -e "${CYAN}[4/4] Résumé rapide...${NC}\n"

# Compter les jobs
TOTAL_JOBS=$(docker exec youtube-worker python3 -c "
from database import get_session, Job
session = get_session()
try:
    print(session.query(Job).count())
finally:
    session.close()
" 2>/dev/null || echo "0")

COMPLETED_JOBS=$(docker exec youtube-worker python3 -c "
from database import get_session, Job
session = get_session()
try:
    print(session.query(Job).filter(Job.status == 'completed').count())
finally:
    session.close()
" 2>/dev/null || echo "0")

FAILED_JOBS=$(docker exec youtube-worker python3 -c "
from database import get_session, Job
session = get_session()
try:
    print(session.query(Job).filter(Job.status == 'failed').count())
finally:
    session.close()
" 2>/dev/null || echo "0")

PROCESSING_JOBS=$(docker exec youtube-worker python3 -c "
from database import get_session, Job
session = get_session()
try:
    print(session.query(Job).filter(Job.status == 'processing').count())
finally:
    session.close()
" 2>/dev/null || echo "0")

echo -e "   📊 ${BLUE}Total Jobs:${NC} $TOTAL_JOBS"
echo -e "   ✅ ${GREEN}Complétés:${NC} $COMPLETED_JOBS"
echo -e "   ⚠️  ${YELLOW}En cours:${NC} $PROCESSING_JOBS"
echo -e "   ❌ ${RED}Échoués:${NC} $FAILED_JOBS"

if [ "$TOTAL_JOBS" -gt 0 ]; then
    SUCCESS_RATE=$(awk "BEGIN {printf \"%.1f\", ($COMPLETED_JOBS/$TOTAL_JOBS)*100}")
    echo -e "   📈 ${CYAN}Taux de succès:${NC} ${SUCCESS_RATE}%"
fi

echo ""

# Afficher les derniers logs (en temps réel si demandé)
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Options supplémentaires                                      ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}\n"

echo -e "${YELLOW}Commandes utiles:${NC}"
echo -e "  • Suivre les logs en direct:"
echo -e "    ${GREEN}docker-compose logs -f youtube-worker${NC}\n"
echo -e "  • Voir seulement les comparaisons Shadow:"
echo -e "    ${GREEN}docker logs youtube-worker | grep \"SHADOW COMPARE\"${NC}\n"
echo -e "  • Voir seulement les erreurs:"
echo -e "    ${GREEN}docker logs youtube-worker | grep ERROR${NC}\n"
echo -e "  • Dashboard interactif Streamlit:"
echo -e "    ${GREEN}http://localhost:8501${NC}\n"
echo -e "  • Exporter les logs pour analyse:"
echo -e "    ${GREEN}docker logs youtube-worker > /tmp/worker_logs.txt${NC}\n"

# Optionnel: Suivre les logs
read -p "Voulez-vous suivre les logs en temps réel? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${BLUE}Suivi des logs... (Ctrl+C pour quitter)${NC}\n"
    docker-compose logs -f youtube-worker | grep --color=auto "SHADOW\|ERROR\|SUCCESS\|COMPLETE\|INFO"
fi
