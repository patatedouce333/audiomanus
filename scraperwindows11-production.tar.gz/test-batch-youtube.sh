#!/bin/bash
set -e

##############################################################################
# Script de Test Batch - Phase 2 Modernisation
# Soumet 22 vidéos YouTube pour transcription en mode Shadow
##############################################################################

# Couleurs pour output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  Test Batch YouTube Transcription${NC}"
echo -e "${BLUE}  Mode: Shadow (Whisper + Vertex AI)${NC}"
echo -e "${BLUE}========================================${NC}\n"

# Configuration
PROJECT_ID="${PROJECT_ID:-project-91ffa63d-6bed-405c-bc3}"
REGION="${REGION:-europe-west1}"
BATCH_FILE="youtube_batch.json"
API_URL="${API_URL:-http://localhost:8081}"

# Vérifications préalables
echo -e "${YELLOW}[1/5] Vérifications préalables...${NC}"

if [ ! -f "$BATCH_FILE" ]; then
    echo -e "${RED}❌ Erreur: $BATCH_FILE introuvable${NC}"
    exit 1
fi

# Valider le JSON
if ! python3 -c "import json; json.load(open('$BATCH_FILE'))" 2>/dev/null; then
    echo -e "${RED}❌ Erreur: $BATCH_FILE n'est pas un JSON valide${NC}"
    exit 1
fi

# Compter les URLs
URL_COUNT=$(python3 -c "import json; print(len(json.load(open('$BATCH_FILE'))['urls']))")
echo -e "${GREEN}✅ $URL_COUNT URLs trouvées dans $BATCH_FILE${NC}\n"

# Vérifier que les services sont actifs
echo -e "${YELLOW}[2/5] Vérification des services...${NC}"

# Détection si on tourne en local ou contre le cloud
if [[ "$API_URL" == *"localhost"* ]] || [[ "$API_URL" == *"127.0.0.1"* ]]; then
    echo "Mode LOCAL détecté (API: $API_URL)"
    if ! docker ps | grep -q youtube-api; then
        echo -e "${RED}❌ Service youtube-api non actif. Lancer: docker-compose up -d${NC}"
        exit 1
    fi
else
    echo "Mode CLOUD détecté (API: $API_URL)"
    echo "⚠️  Assurez-vous que l'URL est accessible depuis ce terminal."
fi

    if ! docker ps | grep -q youtube-worker; then
        echo -e "${RED}❌ Service youtube-worker non actif. Lancer: docker-compose up -d${NC}"
        exit 1
    fi
    echo -e "${GREEN}✅ Services actifs${NC}\n"
else
    echo -e "${GREEN}✅ Mode Cloud: Ignorer vérification Docker local${NC}\n"
fi

# Vérifier l'API
echo -e "${YELLOW}[3/5] Test de connexion API...${NC}"
if ! curl -s "$API_URL/health" > /dev/null; then
    echo -e "${RED}❌ API inaccessible à $API_URL${NC}"
    exit 1
fi
echo -e "${GREEN}✅ API accessible${NC}\n"

# Soumettre le batch
echo -e "${YELLOW}[4/5] Soumission du batch...${NC}"
RESPONSE=$(curl -s -X POST "$API_URL/transcribe" \
    -H "Content-Type: application/json" \
    -d @"$BATCH_FILE")

# Vérifier la réponse
if echo "$RESPONSE" | python3 -c "import sys, json; data = json.load(sys.stdin); sys.exit(0 if data.get('status') == 'success' else 1)" 2>/dev/null; then
    JOB_COUNT=$(echo "$RESPONSE" | python3 -c "import sys, json; print(len(json.load(sys.stdin).get('job_ids', [])))")
    echo -e "${GREEN}✅ $JOB_COUNT jobs soumis avec succès${NC}"
    echo -e "${GREEN}   Réponse API:${NC}"
    echo "$RESPONSE" | python3 -m json.tool | sed 's/^/   /'
else
    echo -e "${RED}❌ Erreur lors de la soumission${NC}"
    echo "$RESPONSE" | python3 -m json.tool
    exit 1
fi

echo ""

# Instructions de monitoring
echo -e "${YELLOW}[5/5] Monitoring des résultats${NC}"

if [[ "$API_URL" == *"localhost"* ]] || [[ "$API_URL" == *"127.0.0.1"* ]]; then
echo -e "${BLUE}
╔════════════════════════════════════════════════════════════════╗
║  Instructions de Monitoring (LOCAL)                            ║
╚════════════════════════════════════════════════════════════════╝${NC}

${GREEN}1. Suivre les logs en temps réel:${NC}
   docker-compose logs -f youtube-worker | grep --color=auto \"SHADOW\\|ERROR\\|SUCCESS\"

${GREEN}2. Rechercher les comparaisons Shadow Mode:${NC}
   docker-compose logs youtube-worker | grep \"SHADOW COMPARE\"

${GREEN}3. Vérifier la progression dans la base:${NC}
   docker exec -it youtube-worker python3 -c \"
from database import get_session, Job
with get_session() as session:
    total = session.query(Job).count()
    completed = session.query(Job).filter(Job.status == 'completed').count()
    failed = session.query(Job).filter(Job.status == 'failed').count()
    print(f'Total: {total} | Completed: {completed} | Failed: {failed}')
\"

${GREEN}4. Dashboard Streamlit (interface graphique):${NC}
   Accéder à: http://localhost:8501
   Onglet: \"Monitoring Dashboard\"

${GREEN}5. Statistiques détaillées:${NC}
   docker exec -it youtube-worker python3 monitoring.py
"
else
echo -e "${BLUE}
╔════════════════════════════════════════════════════════════════╗
║  Instructions de Monitoring (CLOUD)                            ║
╚════════════════════════════════════════════════════════════════╝${NC}

${GREEN}1. Suivre les logs via Google Cloud Console:${NC}
   https://console.cloud.google.com/run/jobs/details/$REGION/youtube-transcriber-worker/logs

${GREEN}2. Logs via CLI:${NC}
   gcloud beta run jobs logs tail youtube-transcriber-worker --project $PROJECT_ID --region $REGION

${GREEN}3. Vérifier la base de données:${NC}
   Connectez-vous à Cloud SQL via le proxy ou la console GCP.
"
fi

${BLUE}╔════════════════════════════════════════════════════════════════╗
║  Temps estimé de traitement: 15-30 minutes pour 22 vidéos     ║
╚════════════════════════════════════════════════════════════════╝${NC}
"

# Optionnel: Suivre automatiquement les logs
read -p "Voulez-vous suivre les logs maintenant? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${BLUE}Suivi des logs... (Ctrl+C pour quitter)${NC}\n"
    docker-compose logs -f youtube-worker | grep --color=auto "SHADOW\|ERROR\|SUCCESS\|COMPLETE"
fi
