#!/usr/bin/env bash
# Script de test pour l'orchestrateur et l'agent

set -euo pipefail

PROJECT_ID="project-91ffa63d-6bed-405c-bc3"
REGION="europe-west1"

echo "🔍 Récupération de l'URL de l'orchestrateur..."
ORCHESTRATOR_URL=$(gcloud run services describe scraper-orchestrator \
  --region="${REGION}" \
  --project="${PROJECT_ID}" \
  --format="value(status.url)" 2>/dev/null || echo "")

if [[ -z "${ORCHESTRATOR_URL}" ]]; then
  echo "❌ Orchestrateur non déployé. Lance d'abord: ./deploy.sh"
  exit 1
fi

echo "✅ Orchestrateur trouvé: ${ORCHESTRATOR_URL}"
echo

# Test 1: Health check
echo "📡 Test 1: Health check"
curl -s "${ORCHESTRATOR_URL}/" | jq .
echo

# Test 2: Dispatch d'une URL simple
echo "📡 Test 2: Dispatch d'une URL"
curl -X POST "${ORCHESTRATOR_URL}/dispatch" \
  -H "Content-Type: application/json" \
  -d '{"urls": ["https://example.com"]}' | jq .
echo

# Test 3: Vérifier que le message est dans Pub/Sub
echo "📊 Messages en attente dans Pub/Sub:"
gcloud pubsub subscriptions describe scraper-agent-sub \
  --project="${PROJECT_ID}" \
  --format="value(numUndeliveredMessages)"
echo

# Test 4: Exécuter l'agent manuellement
echo "🚀 Démarrage manuel de l'agent (Cloud Run Job)..."
gcloud run jobs execute scraper-agent \
  --region="${REGION}" \
  --project="${PROJECT_ID}" \
  --wait

echo
echo "✅ Tests terminés pour le scraper crawl4ai !"
echo

# --- NOUVEAU : Tests YouTube Transcriber ---

echo "📺 --- Section YouTube Transcriber ---"
YOUTUBE_API_URL=$(gcloud run services describe youtube-transcriber-api \
  --region="${REGION}" \
  --project="${PROJECT_ID}" \
  --format="value(status.url)" 2>/dev/null || echo "http://localhost:8081")

echo "📡 Test YouTube: Health check"
curl -s "${YOUTUBE_API_URL}/" | jq . || echo "⚠️ YouTube API non accessible à ${YOUTUBE_API_URL}"
echo

echo "📡 Test YouTube: Soumission URL"
curl -X POST "${YOUTUBE_API_URL}/transcribe" \
  -H "Content-Type: application/json" \
  -d '{"urls": ["https://www.youtube.com/watch?v=dQw4w9WgXcQ"]}' | jq . || echo "⚠️ Échec de soumission YouTube"
echo

echo "🚀 Exécution manuelle du worker YouTube..."
gcloud run jobs execute youtube-transcriber-worker \
  --region="${REGION}" \
  --project="${PROJECT_ID}" \
  --wait || echo "⚠️ Impossible de lancer le job YouTube sur GCP (mode local ?)"

echo
echo "🏁 Tous les tests E2E (Scraper + YouTube) sont terminés !"
echo
echo "📝 Pour voir les résultats:"
echo "  - Logs orchestrateur: gcloud logging read 'resource.type=cloud_run_revision AND resource.labels.service_name=scraper-orchestrator' --limit=10"
echo "  - Logs agent: gcloud logging read 'resource.type=cloud_run_job AND resource.labels.job_name=scraper-agent' --limit=10"
echo "  - Storage: gsutil ls gs://scraper-results-${PROJECT_ID}/results/"
echo "  - SQL: gcloud sql connect scraper-db --user=scraper_user"
