#!/bin/bash
set -e

##############################################################################
# Test Rapide du Monitoring - Avant Batch Test
# Vérifie que tous les outils de monitoring fonctionnent
##############################################################################

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Test Monitoring System - Vérifications Préalables            ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}\n"

# 1. Vérifier docker-compose
echo -e "${YELLOW}[1/6] Vérification docker-compose...${NC}"
if docker-compose ps | grep -q youtube-worker; then
    echo -e "${GREEN}✅ Services actifs${NC}\n"
else
    echo -e "${RED}❌ Services non actifs. Lancer: docker-compose up -d${NC}"
    exit 1
fi

# 2. Vérifier connexion database
echo -e "${YELLOW}[2/6] Test connexion base de données...${NC}"
if docker exec youtube-worker python3 -c "
from database import get_session
session = get_session()
print('✅ Connexion réussie')
session.close()
" 2>/dev/null; then
    echo -e "${GREEN}✅ Base de données accessible${NC}\n"
else
    echo -e "${RED}❌ Impossible de se connecter à la base${NC}"
    exit 1
fi

# 3. Vérifier que monitoring.py fonctionne
echo -e "${YELLOW}[3/6] Test monitoring.py...${NC}"
if docker exec youtube-worker python3 -c "
from monitoring import get_job_stats, get_performance_stats
stats = get_job_stats()
print(f'✅ Fonction get_job_stats() OK - {len(stats)} statuts trouvés')
" 2>/dev/null; then
    echo -e "${GREEN}✅ monitoring.py fonctionnel${NC}\n"
else
    echo -e "${RED}❌ Erreur dans monitoring.py${NC}"
    exit 1
fi

# 4. Vérifier logs_analyzer.py
echo -e "${YELLOW}[4/6] Test logs_analyzer.py...${NC}"
if docker logs youtube-worker --tail 10 2>/dev/null | docker exec -i youtube-worker python3 logs_analyzer.py >/dev/null 2>&1; then
    echo -e "${GREEN}✅ logs_analyzer.py fonctionnel${NC}\n"
else
    echo -e "${YELLOW}⚠️  logs_analyzer.py fonctionne avec avertissements${NC}\n"
fi

# 5. Tester une insertion dans la DB
echo -e "${YELLOW}[5/6] Test écriture base de données...${NC}"
docker exec youtube-worker python3 -c "
from database import get_session, Job
import uuid

session = get_session()
try:
    test_job = Job(
        job_id=f'test-{uuid.uuid4()}',
        video_id='test-video-123',
        status='pending'
    )
    session.add(test_job)
    session.commit()
    print('✅ Écriture réussie')
    
    # Nettoyer
    session.delete(test_job)
    session.commit()
finally:
    session.close()
" 2>/dev/null

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Écriture/lecture base OK${NC}\n"
else
    echo -e "${RED}❌ Problème d'écriture dans la base${NC}"
    exit 1
fi

# 6. Afficher un aperçu des données actuelles
echo -e "${YELLOW}[6/6] État actuel de la base...${NC}"
docker exec youtube-worker python3 -c "
from database import get_session, Job, Transcript, Video

session = get_session()
try:
    videos = session.query(Video).count()
    transcripts = session.query(Transcript).count()
    jobs = session.query(Job).count()
    
    print(f'   • Vidéos: {videos}')
    print(f'   • Transcriptions: {transcripts}')
    print(f'   • Jobs: {jobs}')
finally:
    session.close()
" 2>/dev/null

echo ""

# Résumé
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Résultat des Tests                                           ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}\n"

echo -e "${GREEN}✅ Tous les systèmes de monitoring sont opérationnels !${NC}\n"

echo -e "${BLUE}Vous pouvez maintenant:${NC}"
echo -e "  1. Lancer le test batch:"
echo -e "     ${GREEN}./test-batch-youtube.sh${NC}\n"
echo -e "  2. Monitorer en temps réel:"
echo -e "     ${GREEN}./monitor-system.sh${NC}\n"
echo -e "  3. Voir le dashboard complet:"
echo -e "     ${GREEN}docker exec youtube-worker python3 monitoring.py${NC}\n"
echo -e "  4. Analyser les logs:"
echo -e "     ${GREEN}docker logs youtube-worker | docker exec -i youtube-worker python3 logs_analyzer.py${NC}\n"
