#!/usr/bin/env bash
"""
Script de test pour valider le Shadow Mode localement.
Simule l'arrivée d'un message Pub/Sub et l'exécution du worker.
"""

echo "🧪 Test du Shadow Mode (Vertex AI vs Whisper)..."

# Mock des variables d'env pour le test local
export USE_VERTEX_AI=True
export SHADOW_MODE=True
export STORAGE_BUCKET="test-bucket"
export PROJECT_ID="test-project"

# Simulation d'un traitement vidéo
# Note: Ce script nécessite un environnement Python configuré avec les dépendances installées.
python3 -c "
import json
from youtube_transcriber.worker import TranscriptionWorker
from unittest.mock import MagicMock

# On mock les clients cloud pour ne pas faire d'appels réels en test local simple
worker = TranscriptionWorker()
worker.transcriber.transcribe_video = MagicMock(return_value=({'text': 'Whisper output', 'method': 'whisper', 'language': 'fr', 'segments': []}, 'vid123'))
worker.vertex_transcriber.download_video_only = MagicMock(return_value='test.mp4')
worker.vertex_transcriber.transcribe_video = MagicMock(return_value=({'text': 'Vertex output', 'visual_context': 'Some slides', 'language': 'fr', 'segments': []}, 0.005))
worker.bucket = MagicMock()
worker.store_transcript_in_gcs = MagicMock(return_value='gs://test/path.json')

# Simuler l'appel
print('Running process_video in shadow mode...')
worker.process_video('https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'job-456')
print('✅ Test complété (mock)')
"
