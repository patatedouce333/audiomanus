#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="project-91ffa63d-6bed-405c-bc3"
REGION="europe-west1"
REPO="scraper-images"
SERVICE_ACCOUNT="app-ia-backend@project-91ffa63d-6bed-405c-bc3.iam.gserviceaccount.com"

# Récupération sécurisée du mot de passe SQL (depuis l'env ou Secret Manager)
if [[ -z "${SQL_PASSWORD:-}" ]]; then
  echo "🔐 Récupération du mot de passe depuis Secret Manager..."
  SQL_PASSWORD=$(gcloud secrets versions access latest --secret="sql-password" --project="${PROJECT_ID}" 2>/dev/null || echo "m7JBMb+acUTlNNZolVBdqys6")
fi

echo "Deploying Cloud Run orchestrator..."
gcloud run deploy scraper-orchestrator \
  --image="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/scraper-orchestrator:latest" \
  --region="${REGION}" \
  --project="${PROJECT_ID}" \
  --platform=managed \
  --service-account="${SERVICE_ACCOUNT}" \
  --set-env-vars="PROJECT_ID=${PROJECT_ID},PUBSUB_TOPIC=scraper-topic" \
  --allow-unauthenticated \
  --memory=512Mi \
  --cpu=1 \
  --timeout=300 \
  --max-instances=10 \
  --quiet

echo "Deploying Cloud Run Job agent..."
gcloud run jobs create scraper-agent \
  --image="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/crawl4ai-agent:latest" \
  --region="${REGION}" \
  --project="${PROJECT_ID}" \
  --service-account="${SERVICE_ACCOUNT}" \
  --set-env-vars="PROJECT_ID=${PROJECT_ID},REGION=${REGION},PUBSUB_SUBSCRIPTION=scraper-agent-sub,STORAGE_BUCKET=scraper-results-${PROJECT_ID},CLOUD_SQL_CONNECTION_NAME=${PROJECT_ID}:${REGION}:scraper-db,SQL_USER=scraper_user,SQL_PASSWORD=${SQL_PASSWORD},SQL_DATABASE=scraper" \
  --tasks=1 \
  --max-retries=3 \
  --task-timeout=1800s \
  --memory=8Gi \
  --cpu=4 \
  --parallelism=1 \
  --quiet \
  || echo "Job already exists, updating..."

# Update if already exists
gcloud run jobs update scraper-agent \
  --image="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/crawl4ai-agent:latest" \
  --region="${REGION}" \
  --project="${PROJECT_ID}" \
  --set-env-vars="PROJECT_ID=${PROJECT_ID},REGION=${REGION},PUBSUB_SUBSCRIPTION=scraper-agent-sub,STORAGE_BUCKET=scraper-results-${PROJECT_ID},CLOUD_SQL_CONNECTION_NAME=${PROJECT_ID}:${REGION}:scraper-db,SQL_USER=scraper_user,SQL_PASSWORD=${SQL_PASSWORD},SQL_DATABASE=scraper" \
  --tasks=1 \
  --max-retries=3 \
  --task-timeout=1800s \
  --memory=8Gi \
  --cpu=4 \
  --parallelism=1 \
  --quiet \
  || true

echo "------------------------------------------------"
echo "Deploying YouTube Transcriber..."
echo "------------------------------------------------"
(cd youtube-transcriber && chmod +x deploy.sh && ./deploy.sh)

echo "✅ Deployment complete!"
echo ""
echo "Orchestrator URL:"
gcloud run services describe scraper-orchestrator --region="${REGION}" --project="${PROJECT_ID}" --format="value(status.url)"
echo ""
echo "Test command:"
echo "curl -X POST \$(gcloud run services describe scraper-orchestrator --region=${REGION} --project=${PROJECT_ID} --format='value(status.url)')/dispatch \\"
echo "  -H 'Content-Type: application/json' \\"
echo "  -d '{\"urls\": [\"https://example.com\"]}'"
