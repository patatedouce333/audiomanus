#!/usr/bin/env python3
"""
Agent principal pour le scraping, gérant à la fois le scraping standard (crawl4ai)
 et le scraping visuel (VisionAgent).
"""

import asyncio
import json
import logging
import os
import sys
from datetime import datetime
from typing import Dict, Any, Optional

from google.cloud import pubsub_v1, storage
from cloud_sql_python_connector import Connector
import pg8000
from crawl4ai import AsyncWebCrawler

# --- NOUVELLE IMPORTATION ---
from agent.vision_agent import VisionAgent

# ... (Le reste de la configuration reste inchangé) ...
PROJECT_ID = os.getenv("PROJECT_ID", "project-91ffa63d-6bed-405c-bc3")
REGION = os.getenv("REGION", "europe-west1")
SUBSCRIPTION = os.getenv("PUBSUB_SUBSCRIPTION", "scraper-agent-sub")
STORAGE_BUCKET = os.getenv("STORAGE_BUCKET", "scraper-results-project-91ffa63d-6bed-405c-bc3")
SQL_CONNECTION = os.getenv("CLOUD_SQL_CONNECTION_NAME", "project-91ffa63d-6bed-405c-bc3:europe-west1:scraper-db")
SQL_USER = os.getenv("SQL_USER", "scraper_user")
SQL_PASSWORD = os.getenv("SQL_PASSWORD", "")
SQL_DATABASE = os.getenv("SQL_DATABASE", "scraper")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT", "5432")

logging.basicConfig(level=logging.INFO, format='{"time":"%(asctime)s","level":"%(levelname)s","msg":"%(message)s"}', stream=sys.stdout)
logger = logging.getLogger(__name__)


class MainAgent:
    """
    Agent principal orchestrant les différents types de tâches de scraping.
    """
    
    def __init__(self):
        self.subscriber = pubsub_v1.SubscriberClient()
        self.storage_client = storage.Client()
        self.bucket = self.storage_client.bucket(STORAGE_BUCKET) 
        self.connector = Connector()
        self.subscription_path = self.subscriber.subscription_path(PROJECT_ID, SUBSCRIPTION)
        
        # --- INITIALISATION DE L'AGENT VISUEL ---
        self.vision_agent = VisionAgent()
        
    def get_db_connection(self):
        # ... (inchangé) ...
        if DB_HOST:
            return pg8000.connect(user=SQL_USER, password=SQL_PASSWORD, host=DB_HOST, port=int(DB_PORT), database=SQL_DATABASE)
        return self.connector.connect(SQL_CONNECTION, "pg8000", user=SQL_USER, password=SQL_PASSWORD, db=SQL_DATABASE)
    
    async def scrape_url_standard(self, url: str, options: Dict[str, Any]) -> Dict[str, Any]:
        # ... (le code de l'ancienne méthode scrape_url est ici, renommé) ...
        logger.info(f"Starting standard scrape for URL: {url}")
        try:
            async with AsyncWebCrawler() as crawler:
                result = await crawler.arun(url=url)
                # ... (le reste de la logique de crawl4ai)
                return {"success": result.success, "url": url, "markdown": result.markdown, "timestamp": datetime.utcnow().isoformat()}
        except Exception as e:
            return {"success": False, "url": url, "error": str(e), "timestamp": datetime.utcnow().isoformat()}

    def store_result(self, result: Dict[str, Any]):
        # ... (légèrement modifié pour inclure les données visuelles)
        url = result["url"]
        timestamp = result["timestamp"]
        success = result["success"]
        visual_data = result.get("visual_data") # Nouvelle donnée

        # ... (logique de stockage GCS inchangée)

        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS scrape_results (
                    id SERIAL PRIMARY KEY,
                    url TEXT NOT NULL,
                    success BOOLEAN NOT NULL,
                    storage_path TEXT,
                    error_message TEXT,
                    visual_data JSONB, -- NOUVEAU CHAMP
                    scraped_at TIMESTAMP NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            cursor.execute(
                "INSERT INTO scrape_results (url, success, storage_path, error_message, visual_data, scraped_at) VALUES (%s, %s, %s, %s, %s, %s)",
                (url, success, None, result.get("error"), json.dumps(visual_data), timestamp)
            )
            conn.commit()
        finally:
            if conn: conn.close()

    # --- LOGIQUE DE TRAITEMENT MISE À JOUR ---
    def process_message(self, message: pubsub_v1.subscriber.message.Message):
        """Traite un message Pub/Sub en fonction du type de tâche."""
        try:
            data = json.loads(message.data.decode("utf-8"))
            url = data.get("url")
            task_type = data.get("task_type", "standard") # Par défaut: standard
            prompt = data.get("prompt")
            element_description = data.get("element_description")

            if not url:
                logger.error("Message ignoré: champ 'url' manquant.")
                message.ack()
                return

            result = None
            if task_type == "visual_extraction":
                logger.info(f"Tâche de scraping visuel (extraction) pour: {url}")
                extracted_data = self.vision_agent.extract_visual_data(url, prompt)
                result = {
                    "success": bool(extracted_data),
                    "url": url,
                    "visual_data": {"extracted_text": extracted_data},
                    "timestamp": datetime.utcnow().isoformat()
                }
            elif task_type == "visual_location":
                logger.info(f"Tâche de scraping visuel (localisation) pour: {url}")
                coordinates = self.vision_agent.find_element_coordinates(url, element_description)
                result = {
                    "success": bool(coordinates),
                    "url": url,
                    "visual_data": {"coordinates": coordinates},
                    "timestamp": datetime.utcnow().isoformat()
                }
            else: # Tâche "standard"
                logger.info(f"Tâche de scraping standard pour: {url}")
                result = asyncio.run(self.scrape_url_standard(url, {}))

            if result:
                self.store_result(result)
            
            message.ack()
            logger.info(f"Message traité et acquitté pour {url}")

        except Exception as e:
            logger.error(f"Erreur lors du traitement du message: {e}", exc_info=True)
            message.nack()

    def run(self):
        """Lance l'agent."""
        # ... (inchangé) ...
        logger.info(f"Lancement de l'agent, écoute sur: {self.subscription_path}")
        streaming_pull_future = self.subscriber.subscribe(self.subscription_path, callback=self.process_message)
        try:
            streaming_pull_future.result(timeout=600)
        except Exception as e:
            streaming_pull_future.cancel()
        finally:
            self.connector.close()
            logger.info("Agent arrêté.")

if __name__ == "__main__":
    agent = MainAgent()
    agent.run()
