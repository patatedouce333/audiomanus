#!/usr/bin/env python3
"""
Agent de Scraping Visuel utilisant les capacités multi-modales de Gemini 3.
"""

import os
import base64
import json
from typing import Dict, Optional
from loguru import logger
import vertexai
from vertexai.generative_models import GenerativeModel, Part
from playwright.async_api import async_playwright
import asyncio

# Configuration
PROJECT_ID = os.getenv("GCP_PROJECT")
LOCATION = os.getenv("GCP_LOCATION", "us-central1")

class VisionAgent:
    """
    Un agent capable d'analyser et d'interagir avec le contenu visuel de pages web.
    """

    def __init__(self, project_id: str = PROJECT_ID, location: str = LOCATION):
        if not project_id:
            raise ValueError("Le projet GCP (GCP_PROJECT) doit être défini.")
        self.project_id = project_id
        self.location = location
        self.model = None
        try:
            logger.info(f"Initialisation de Vertex AI pour le projet '{self.project_id}' à '{self.location}'")
            vertexai.init(project=self.project_id, location=self.location)
            self.model = GenerativeModel("gemini-3.0-pro-multimodal")
            logger.success("Agent Visuel initialisé avec succès.")
        except Exception as e:
            logger.error(f"Erreur lors de l'initialisation de l'Agent Visuel: {e}")
            raise

    async def take_screenshot_async(self, url: str) -> str:
        """Prend une capture d'écran et la retourne en base64."""
        logger.info(f"Prise de capture d'écran pour l'URL: {url}")
        async with async_playwright() as p:
            try:
                browser = await p.chromium.launch()
                page = await browser.new_page()
                await page.goto(url, wait_until="networkidle")
                screenshot_bytes = await page.screenshot(full_page=True)
                await browser.close()
                return base64.b64encode(screenshot_bytes).decode('utf-8')
            except Exception as e:
                logger.error(f"Erreur de capture d'écran: {e}")
                return ""

    def analyze_image(self, screenshot_base64: str, prompt: str) -> str:
        """Envoie une image (base64) et un prompt à Gemini et retourne la réponse texte."""
        if not self.model or not screenshot_base64:
            logger.error("Modèle non initialisé ou capture d'écran vide.")
            return ""
        logger.info("Analyse de l'image avec Gemini...")
        try:
            image_part = Part.from_data(data=base64.b64decode(screenshot_base64), mime_type="image/png")
            response = self.model.generate_content([image_part, prompt])
            logger.success("Analyse d'image terminée.")
            return response.text
        except Exception as e:
            logger.error(f"Erreur d'analyse d'image: {e}")
            return ""

    def extract_visual_data(self, url: str, prompt: str) -> str:
        """Orchestre la capture et l'analyse pour extraire une donnée textuelle."""
        logger.info(f"Lancement de l'extraction visuelle sur {url}")
        screenshot_b64 = asyncio.run(self.take_screenshot_async(url))
        return self.analyze_image(screenshot_b64, prompt)

    def find_element_coordinates(self, url: str, element_description: str) -> Optional[Dict[str, int]]:
        """
        Trouve les coordonnées (approximatives) du centre d'un élément visuel sur une page.
        """
        logger.info(f"Recherche des coordonnées pour: '{element_description}'")
        prompt = f"""
        Analyse l'image de cette page web. Ta tâche est de localiser le CENTRE de l'élément correspondant à la description : '{element_description}'.
        Réponds **uniquement** avec un objet JSON au format suivant : {{"x": <valeur_x>, "y": <valeur_y>}}.
        Si l'élément n'est pas visible ou n'existe pas, réponds avec {{"x": null, "y": null}}.
        Ne fournis aucune explication ou texte en dehors de l'objet JSON.
        """
        response_text = self.extract_visual_data(url, prompt)
        if not response_text:
            return None
        try>
            # Nettoyage de la réponse pour extraire uniquement le JSON
            clean_response = response_text.strip()
            if "```json" in clean_response:
                clean_response = clean_response.split("```json")[1].split("```")[0]
            
            coords = json.loads(clean_response)
            
            if coords.get('x') is not None and coords.get('y') is not None:
                logger.success(f"Coordonnées trouvées pour '{element_description}': {coords}")
                return coords
            else:
                logger.warning(f"L'élément '{element_description}' n'a pas été trouvé.")
                return None
        except (json.JSONDecodeError, KeyError) as e:
            logger.error(f"Impossible de parser les coordonnées depuis la réponse de l'IA: {e}")
            logger.debug(f"Réponse brute reçue: {response_text}")
            return None

# --- Main pour tests ---
if __name__ == '__main__':
    def main_test():
        try:
            agent = VisionAgent()
            
            # --- Test Tâche 2.2 : Localisation d'élément --- 
            logger.info("--- Début du test de la Tâche 2.2 ---")
            test_url_2_2 = "https://www.google.com/?hl=fr"
            element_desc = "la barre de recherche principale"
            coordinates = agent.find_element_coordinates(test_url_2_2, element_desc)
            
            if coordinates:
                logger.success("Test de localisation d'élément réussi.")
                print("\n--- Coordonnées trouvées ---")
                print(f"Coordonnées pour '{element_desc}': {coordinates}")
                print("---------------------------\n")
            else:
                logger.error("Test de localisation d'élément échoué.")

        except Exception as e:
            logger.error(f"Une erreur est survenue durant le test principal: {e}")

    main_test()
