# Liste de Tests YouTube - Modernisation Phase 2

## 📋 Vue d'ensemble
- **Nombre de vidéos**: 22
- **Objectif**: Validation de la transcription Vertex AI Gemini 3 en mode Shadow
- **Format API**: `youtube_batch.json`
- **Date**: 13 janvier 2026

## 📝 Description
Cette liste contient 22 URLs YouTube soigneusement sélectionnées pour tester l'intégralité des capacités de transcription de Vertex AI Gemini 3, incluant :
- Variété de sujets techniques (IA, développement, business)
- Différents accents et styles de présentation
- Extraction de contexte visuel (slides, démos, code)
- Diarisation multi-locuteurs

## 🤖 Claude Code & Gemini CLI
- [The New Claude Code Meta](https://www.youtube.com/watch?v=SqmXS8q_2BM)
- [My Obsidian And Gemini CLI Workflow](https://www.youtube.com/watch?v=JGwFsyyewYc)
- [NEW Claude Code Plugin: Code Simplifier](https://www.youtube.com/watch?v=puynahM0Wew)
- [Dont Use Claude Code Without This Plugin](https://www.youtube.com/watch?v=eU4ojT6uJNY)
- [Build Your Own Claude Code From Scratch](https://www.youtube.com/watch?v=3GjE_YAs03s)
- [800+ hours of Learning Claude Code in 8 minutes](https://www.youtube.com/watch?v=Ffh9OeJ7yxw)
- [Claude Code's Chrome Extension Tricks](https://www.youtube.com/watch?v=yKKqxLLJCm4)
- [Claude Canvas Turns Claude Code Into a Visual Terminal App](https://www.youtube.com/watch?v=M_iCVJSZsu0)

## 🌌 Google Antigravity & AI Systems
- [Algo trading research with Google’s Antigravity and Gemini 3](https://www.youtube.com/watch?v=ypFG006G4WQ)
- [How I Build $100,000 CEO Systems in 25 mins (AntiGravity)](https://www.youtube.com/watch?v=X__6Zjltw48)
- [Award-Winning Website in 15 Minutes using Google's Antigravity](https://www.youtube.com/watch?v=rbqIivbTJao)
- [DON'T build AI automations, build agentic workflows! (Google Antigravity)](https://www.youtube.com/watch?v=7U6pKex9tbE)

## 🛠️ Développement & UI
- [Top Trending GitHub Projects This Week](https://www.youtube.com/watch?v=Qn18s9O9o2A)
- [Vibecode An Apple-Style AI Website Fast (Gemini Tools)](https://www.youtube.com/watch?v=KIsuIj-Ll3k)
- [Build My Entire Design System in 4 Hours With AI](https://www.youtube.com/watch?v=nafNPuElCtY)
- [Google's Firebase Studio Just Changed Everything](https://www.youtube.com/watch?v=kV7skm1NXno)
- [How to Build ACTUALLY Beautiful UI (Claude Code Skill)](https://www.youtube.com/watch?v=95_NJ-a-CMQ)
- [Design OS: Greatest AI Design System](https://www.youtube.com/watch?v=4M9BItUIazQ)

## 📈 Business & Projets
- [This app made over $1M](https://www.youtube.com/watch?v=VfNRd5Rk0cM)
- [NotebookLM: Build ANYTHING (FREE!)](https://www.youtube.com/watch?v=M75SszeVGeo)
- [How to Build AI Engineering Projects That Get You Interviews](https://www.youtube.com/watch?v=3ZDSdMpczXE)
- [Nano Banana Pro Cinematic AI Ads!](https://www.youtube.com/watch?v=CldGNJhBaNw)
