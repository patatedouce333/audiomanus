# Mode d'Emploi - Projet Scraper crawl4ai avec Transcription YouTube

## Vue d'ensemble du projet

Ce projet est un système de scraping web utilisant crawl4ai pour extraire du contenu de sites web, intégré avec une architecture GCP serverless. Il inclut également des fonctionnalités de transcription YouTube utilisant Vertex AI.

Le système est composé de plusieurs composants :
- **Orchestrateur** : API Flask qui reçoit les demandes de scraping et les distribue via Pub/Sub
- **Agent** : Travailleur qui consomme les messages Pub/Sub et effectue le scraping
- **Transcripteur YouTube** : Service pour transcrire des vidéos YouTube
- **Frontend** : Interface utilisateur pour interagir avec le système
- **Base de données** : PostgreSQL pour stocker les métadonnées
- **Stockage** : Cloud Storage pour les résultats complets

## Prérequis

### Environnement de développement
- Python 3.10 ou supérieur
- Docker et Docker Compose
- Google Cloud SDK (gcloud)
- Compte GCP avec les services activés :
  - Cloud Run
  - Pub/Sub
  - Cloud Storage
  - Cloud SQL
  - Vertex AI (pour la transcription YouTube)

### Clés API
- Clé API YouTube (pour la transcription)
- Clé API GCP avec les permissions appropriées

## Installation

### 1. Clonage du repository
```bash
git clone <url-du-repo>
cd codespaces-blank
```

### 2. Configuration de l'environnement Python
```bash
# Créer un environnement virtuel
python -m venv venv
source venv/bin/activate  # Sur Windows: venv\Scripts\activate

# Installer les dépendances
pip install -r requirements.txt
```

### 3. Configuration GCP
```bash
# Se connecter à GCP
gcloud auth login
gcloud config set project YOUR_PROJECT_ID

# Exécuter le script de configuration
chmod +x setup-gcp.sh
./setup-gcp.sh
```

### 4. Configuration YouTube API
Suivez les instructions dans `setup-youtube-api-key.md` pour obtenir et configurer votre clé API YouTube.

## Configuration

### Variables d'environnement
Créez un fichier `.env` basé sur `.env.local` :

```bash
cp .env.local .env
```

Éditez `.env` avec vos valeurs :
- `PROJECT_ID` : ID de votre projet GCP
- `REGION` : Région GCP (ex: europe-west1)
- `YOUTUBE_API_KEY` : Votre clé API YouTube
- `SQL_PASSWORD` : Mot de passe Cloud SQL
- Etc.

## Utilisation

### Développement local

#### Lancement des services
```bash
# Construire et lancer tous les services
docker-compose up --build
```

Les services seront disponibles sur :
- Orchestrateur : http://localhost:8080
- YouTube API : http://localhost:8081
- Pub/Sub Emulator : http://localhost:8085

#### Test des endpoints

**Scraping simple :**
```bash
curl -X POST "http://localhost:8080/dispatch" \
  -H "Content-Type: application/json" \
  -d '{
    "urls": ["https://example.com"],
    "options": {"depth": 1}
  }'
```

**Batch scraping :**
```bash
curl -X POST "http://localhost:8080/batch" \
  -H "Content-Type: application/json" \
  -d '{
    "batch_id": "test-batch",
    "urls": ["https://site1.com", "https://site2.com"],
    "options": {"extract_links": true}
  }'
```

**Transcription YouTube :**
```bash
curl -X POST "http://localhost:8081/transcribe" \
  -H "Content-Type: application/json" \
  -d '{
    "video_id": "VIDEO_ID",
    "language": "fr"
  }'
```

### Déploiement en production

#### Build des images
```bash
chmod +x build-images.sh
./build-images.sh
```

#### Déploiement
```bash
export SQL_PASSWORD="votre-mot-de-passe"
chmod +x deploy.sh
./deploy.sh
```

Après le déploiement, notez l'URL de l'orchestrateur (ex: https://scraper-orchestrator-xxx.run.app).

#### Utilisation en production
Remplacez `http://localhost:8080` par l'URL de production dans les commandes curl ci-dessus.

## Tests

### Tests unitaires et d'intégration
```bash
# Tests de l'agent
cd agent
python -m pytest

# Tests de l'orchestrateur
cd ../orchestrator
python -m pytest

# Tests du transcripteur YouTube
cd ../youtube-transcriber
python -m pytest
```

### Tests E2E
```bash
chmod +x test-e2e.sh
./test-e2e.sh
```

### Tests de monitoring
```bash
chmod +x test-monitoring.sh
./test-monitoring.sh
```

### Tests en mode shadow
```bash
chmod +x test-shadow-mode.sh
./test-shadow-mode.sh
```

## Monitoring

### Logs
```bash
# Logs orchestrateur
gcloud logging read "resource.type=cloud_run_revision AND resource.labels.service_name=scraper-orchestrator" \
  --limit=50

# Logs agent
gcloud logging read "resource.type=cloud_run_job AND resource.labels.job_name=scraper-agent" \
  --limit=50
```

### Métriques Pub/Sub
```bash
gcloud pubsub subscriptions describe scraper-agent-sub
```

### Résultats dans Cloud Storage
```bash
gsutil ls gs://votre-bucket/results/
```

### Base de données
```bash
gcloud sql connect scraper-db --user=scraper_user

# Dans psql:
\c scraper
SELECT url, success, scraped_at FROM scrape_results ORDER BY created_at DESC LIMIT 10;
```

## Scripts disponibles

- `build-images.sh` : Construit les images Docker
- `deploy.sh` : Déploie sur GCP
- `setup-gcp.sh` : Configure l'environnement GCP
- `monitor-system.sh` : Script de monitoring
- `test-batch-youtube.sh` : Tests batch YouTube
- `test-e2e.sh` : Tests end-to-end

## Dépannage

### Problèmes courants

1. **Erreur de connexion GCP** : Vérifiez `gcloud auth list` et `gcloud config get-value project`

2. **Problème avec Docker** : Assurez-vous que Docker est en cours d'exécution et que les ports ne sont pas utilisés

3. **Échec de scraping** : Vérifiez les logs de l'agent et les permissions Cloud Storage

4. **Erreur YouTube API** : Vérifiez votre clé API et les quotas

### Ressources supplémentaires
- Consultez `MONITORING_GUIDE.md` pour plus de détails sur le monitoring
- `implementation_roadmap_2026.md` pour la roadmap future
- `phase2_vertex_ai_deep_dive.md` pour les détails techniques de Vertex AI

## Support

Pour des problèmes ou questions, consultez les issues du repository ou contactez l'équipe de développement.