import streamlit as st
import requests
import pandas as pd
import time

st.set_page_config(page_title="IA Data Factory", page_icon="🚀", layout="wide")

st.title("🚀 IA Data Factory - Scraper & YouTube Transcriber")
st.markdown("---")

# Sidebar pour la navigation
page = st.sidebar.selectbox("Navigation", ["YouTube Transcriber", "Web Scraper", "Monitoring Dashboard"])

if page == "YouTube Transcriber":
    st.header("🎥 YouTube Transcriber (Vertex AI Gemini 3)")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        url = st.text_input("URL de la vidéo YouTube", placeholder="https://www.youtube.com/watch?v=...")
        if st.button("Lancer la transcription"):
            if url:
                with st.spinner("Envoi de la requête..."):
                    # Simulation ou appel API réel
                    # response = requests.post("http://api:8080/transcribe", json={"urls": [url]})
                    st.success(f"Job envoyé avec succès ! ID: {int(time.time())}")
                    st.info("La transcription est en cours de traitement asynchrone.")
            else:
                st.warning("Veuillez entrer une URL.")

    with col2:
        st.info("""
        **Fonctionnalités :**
        - Transcription multi-locuteurs
        - Analyse du contexte visuel
        - Export Markdown / JSON
        """)

elif page == "Web Scraper":
    st.header("🌐 Web Scraper (crawl4ai)")
    urls = st.text_area("URLs à scrapper (une par ligne)")
    if st.button("Lancer le scraping"):
        if urls:
            st.success(f"{len(urls.splitlines())} pages envoyées au worker.")
        else:
            st.error("Liste d'URLs vide.")

elif page == "Monitoring Dashboard":
    st.header("📊 Monitoring & Shadow Mode")
    
    # Simulation de métriques
    col1, col2, col3 = st.columns(3)
    col1.metric("Taux de succès", "99.8%", "+0.2%")
    col2.metric("Coût moyen / vidéo", "0.005$", "-85%")
    col3.metric("Latence (p95)", "180s", "-120s")
    
    st.subheader("🌓 Shadow Mode Comparison (Vertex AI vs Whisper)")
    chart_data = pd.DataFrame({
        'Vidéo ID': ['v1', 'v2', 'v3', 'v4', 'v5'],
        'Whisper WER (%)': [8.5, 9.2, 7.8, 12.1, 8.9],
        'Vertex AI WER (%)': [5.2, 5.8, 5.1, 7.4, 5.5]
    })
    st.line_chart(chart_data.set_index('Vidéo ID'))
    st.write("Le Shadow Mode confirme une réduction de ~35% du taux d'erreur (WER) avec Vertex AI.")
