# Scraper crawl4ai - Architecture GCP

## Structure du projet

```
.
├── agent/                      # Agent de scraping Cloud Run Job
│   ├── agent.py               # Code principal
│   ├── Dockerfile             # Image avec Playwright
│   └── requirements.txt       # Dépendances Python
├── orchestrator/              # Orchestrateur Cloud Run Service
│   ├── orchestrator.py        # API Flask
│   ├── Dockerfile
│   └── requirements.txt
├── build-images.sh            # Build des images via Cloud Build
├── deploy.sh                  # Déploiement sur GCP
├── setup-gcp.sh              # Configuration initiale GCP
└── PROJET_PLAN.md            # Plan détaillé

```

## Architecture

1. **Orchestrator** (Cloud Run Service) : API HTTP qui reçoit des listes d'URLs et publie dans Pub/Sub
2. **Pub/Sub** : Queue de messages pour découpler orchestrateur et agents
3. **Agent** (Cloud Run Job) : Consomme Pub/Sub, scrappe avec crawl4ai, stocke résultats
4. **Cloud Storage** : Stockage des résultats complets (HTML, markdown, metadata)
5. **Cloud SQL** : Base PostgreSQL avec métadonnées (URL, timestamp, succès/échec)

## Développement Local (Codespaces)

Pour tester l'ensemble de la stack sans déployer sur GCP :

1.  **Préparer l'environnement** :
    ```bash
    cp .env.local .env
    ```
2.  **Lancer les services** :
    ```bash
    docker-compose up --build
    ```
3.  **Tester les endpoints** :
    - Scraper API : `http://localhost:8080`
    - YouTube API : `http://localhost:8081`
    - Pub/Sub Emulator : `http://localhost:8085`

## Déploiement GCP

### 1. Configuration initiale GCP (déjà fait ✅)
```bash
./setup-gcp.sh
```

### 2. Build des images Docker
```bash
chmod +x build-images.sh
./build-images.sh
```

### 3. Déploiement Cloud Run
```bash
chmod +x deploy.sh
export SQL_PASSWORD="m7JBMb+acUTlNNZolVBdqys6"  # Mot de passe Cloud SQL
./deploy.sh
```

## Utilisation

### Déclencher un scrape simple
```bash
ORCHESTRATOR_URL="https://scraper-orchestrator-xxx.run.app"

curl -X POST "${ORCHESTRATOR_URL}/dispatch" \
  -H "Content-Type: application/json" \
  -d '{
    "urls": ["https://example.com", "https://example.org"],
    "options": {"depth": 1}
  }'
```

### Déclencher un batch
```bash
curl -X POST "${ORCHESTRATOR_URL}/batch" \
  -H "Content-Type: application/json" \
  -d '{
    "batch_id": "batch-001",
    "urls": ["https://site1.com", "https://site2.com"],
    "options": {"extract_links": true}
  }'
```

### Démarrer manuellement l'agent (pour tests)
```bash
gcloud run jobs execute scraper-agent \
  --region=europe-west1 \
  --project=project-91ffa63d-6bed-405c-bc3
```

## Monitoring

### Logs orchestrateur
```bash
gcloud logging read "resource.type=cloud_run_revision AND resource.labels.service_name=scraper-orchestrator" \
  --limit=50 \
  --project=project-91ffa63d-6bed-405c-bc3
```

### Logs agent
```bash
gcloud logging read "resource.type=cloud_run_job AND resource.labels.job_name=scraper-agent" \
  --limit=50 \
  --project=project-91ffa63d-6bed-405c-bc3
```

### Messages Pub/Sub en attente
```bash
gcloud pubsub subscriptions describe scraper-agent-sub \
  --project=project-91ffa63d-6bed-405c-bc3
```

### Résultats dans Cloud Storage
```bash
gsutil ls gs://scraper-results-project-91ffa63d-6bed-405c-bc3/results/
```

### Requêter Cloud SQL
```bash
gcloud sql connect scraper-db --user=scraper_user --project=project-91ffa63d-6bed-405c-bc3

# Dans psql:
\c scraper
SELECT url, success, scraped_at FROM scrape_results ORDER BY created_at DESC LIMIT 10;
```

## Variables d'environnement

### Agent
- `PROJECT_ID`: ID du projet GCP
- `REGION`: Région GCP
- `PUBSUB_SUBSCRIPTION`: Nom de la subscription Pub/Sub
- `STORAGE_BUCKET`: Bucket Cloud Storage
- `CLOUD_SQL_CONNECTION_NAME`: Nom de connexion Cloud SQL
- `SQL_USER`: Utilisateur PostgreSQL
- `SQL_PASSWORD`: Mot de passe PostgreSQL
- `SQL_DATABASE`: Nom de la base de données

### Orchestrateur
- `PROJECT_ID`: ID du projet GCP
- `PUBSUB_TOPIC`: Topic Pub/Sub pour publier

## Évolutions futures

- [ ] Ajout de retry DLQ pour échecs persistants
- [ ] Support LLM extraction avec Gemini
- [ ] Intégration YouTube transcription
- [ ] Dashboard de monitoring (Cloud Monitoring)
- [ ] Budget alerts
- [ ] Tests E2E automatisés
