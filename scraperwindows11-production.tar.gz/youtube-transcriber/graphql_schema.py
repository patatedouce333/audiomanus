#!/usr/bin/env python3
"""GraphQL schema for the YouTube Transcriber API."""

import strawberry
from typing import List, Optional
from datetime import datetime


@strawberry.type
class TranscriptSegment:
    start: float
    end: float
    text: str


@strawberry.type
class Transcript:
    id: int
    video_id: str
    method: str
    language: str
    text: str
    segments: List[TranscriptSegment]
    processing_time: int
    cost_usd: Optional[float]
    created_at: datetime
    success: bool


@strawberry.type
class Job:
    id: int
    video_id: str
    status: str
    created_at: datetime
    updated_at: datetime
    transcript_id: Optional[int]


@strawberry.input
class TranscriptFilter:
    video_id: Optional[str] = None
    method: Optional[str] = None
    language: Optional[str] = None
    success: Optional[bool] = None


@strawberry.type
class Query:
    @strawberry.field
    def transcripts(self, filters: Optional[TranscriptFilter] = None, limit: int = 50) -> List[Transcript]:
        """Get transcripts with optional filters"""
        from database import get_db_session, Transcript as DBTranscript

        with get_db_session() as session:
            query = session.query(DBTranscript)

            if filters:
                if filters.video_id:
                    query = query.filter(DBTranscript.video_id == filters.video_id)
                if filters.method:
                    query = query.filter(DBTranscript.method == filters.method)
                if filters.language:
                    query = query.filter(DBTranscript.language == filters.language)
                if filters.success is not None:
                    query = query.filter(DBTranscript.success == filters.success)

            results = query.limit(limit).all()

            return [
                Transcript(
                    id=t.id,
                    video_id=t.video_id,
                    method=t.method,
                    language=t.language,
                    text=t.text,
                    segments=[
                        TranscriptSegment(start=s['start'], end=s['end'], text=s['text'])
                        for s in t.segments
                    ],
                    processing_time=t.processing_time,
                    cost_usd=t.cost_usd,
                    created_at=t.created_at,
                    success=t.success
                )
                for t in results
            ]

    @strawberry.field
    def jobs(self, status: Optional[str] = None, limit: int = 50) -> List[Job]:
        """Get jobs with optional status filter"""
        from database import get_db_session, Job as DBJob

        with get_db_session() as session:
            query = session.query(DBJob)
            if status:
                query = query.filter(DBJob.status == status)

            results = query.limit(limit).all()

            return [
                Job(
                    id=j.id,
                    video_id=j.video_id,
                    status=j.status,
                    created_at=j.created_at,
                    updated_at=j.updated_at,
                    transcript_id=j.transcript_id
                )
                for j in results
            ]

    @strawberry.field
    def transcript(self, id: int) -> Optional[Transcript]:
        """Get a specific transcript by ID"""
        from database import get_db_session, Transcript as DBTranscript

        with get_db_session() as session:
            t = session.query(DBTranscript).filter(DBTranscript.id == id).first()
            if not t:
                return None

            return Transcript(
                id=t.id,
                video_id=t.video_id,
                method=t.method,
                language=t.language,
                text=t.text,
                segments=[
                    TranscriptSegment(start=s['start'], end=s['end'], text=s['text'])
                    for s in t.segments
                ],
                processing_time=t.processing_time,
                cost_usd=t.cost_usd,
                created_at=t.created_at,
                success=t.success
            )


schema = strawberry.Schema(query=Query)