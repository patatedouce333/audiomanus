#!/usr/bin/env python3
"""
Script de récupération des logs du worker pour analyse.
Extrait et formate les logs pertinents pour le monitoring.
"""

import sys
import re
from datetime import datetime
from collections import defaultdict


def parse_log_line(line):
    """Parse une ligne de log structurée."""
    # Format: 2026-01-13 10:30:45 | INFO | Message
    pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) \| (\w+) \| (.+)'
    match = re.match(pattern, line)
    
    if match:
        timestamp, level, message = match.groups()
        return {
            'timestamp': timestamp,
            'level': level,
            'message': message
        }
    return None


def extract_shadow_comparisons(log_lines):
    """Extrait les comparaisons Shadow Mode des logs."""
    comparisons = []
    pattern = r'SHADOW COMPARE \[(.+?)\]: Whisper len=(\d+), Vertex len=(\d+)'
    
    for line in log_lines:
        match = re.search(pattern, line)
        if match:
            video_id, whisper_len, vertex_len = match.groups()
            comparisons.append({
                'video_id': video_id,
                'whisper_len': int(whisper_len),
                'vertex_len': int(vertex_len),
                'diff': int(vertex_len) - int(whisper_len),
                'diff_pct': ((int(vertex_len) - int(whisper_len)) / int(whisper_len) * 100) if int(whisper_len) > 0 else 0
            })
    
    return comparisons


def extract_processing_info(log_lines):
    """Extrait les informations de traitement."""
    processing = []
    
    # Pattern pour les messages de succès
    success_pattern = r'Video (.+?) processed successfully \(method: (.+?)\)'
    # Pattern pour les erreurs
    error_pattern = r'Error processing video .+?: (.+?)$'
    
    for line in log_lines:
        # Succès
        match = re.search(success_pattern, line)
        if match:
            video_id, method = match.groups()
            parsed = parse_log_line(line)
            processing.append({
                'video_id': video_id,
                'method': method,
                'status': 'success',
                'timestamp': parsed['timestamp'] if parsed else None
            })
        
        # Erreurs
        match = re.search(error_pattern, line)
        if match:
            error_msg = match.group(1)
            parsed = parse_log_line(line)
            processing.append({
                'error': error_msg,
                'status': 'failed',
                'timestamp': parsed['timestamp'] if parsed else None
            })
    
    return processing


def analyze_logs(log_file=None):
    """Analyse les logs et génère un rapport."""
    if log_file:
        with open(log_file, 'r') as f:
            lines = f.readlines()
    else:
        # Lire depuis stdin
        lines = sys.stdin.readlines()
    
    print("\n" + "="*80)
    print(" 📜 ANALYSE DES LOGS - YouTube Transcription Worker")
    print("="*80 + "\n")
    
    # Statistiques générales
    total_lines = len(lines)
    log_levels = defaultdict(int)
    
    for line in lines:
        parsed = parse_log_line(line)
        if parsed:
            log_levels[parsed['level']] += 1
    
    print("📊 Statistiques Générales:")
    print(f"   • Total lignes: {total_lines}")
    for level, count in sorted(log_levels.items()):
        icon = "✅" if level == "INFO" else "⚠️" if level == "WARNING" else "❌"
        print(f"   {icon} {level}: {count}")
    print()
    
    # Comparaisons Shadow Mode
    comparisons = extract_shadow_comparisons(lines)
    if comparisons:
        print(f"🔍 Comparaisons Shadow Mode ({len(comparisons)} trouvées):")
        print("   Video ID         | Whisper | Vertex  | Différence")
        print("   " + "-"*60)
        for comp in comparisons[:10]:  # Limiter à 10
            diff_sign = "+" if comp['diff'] > 0 else ""
            print(f"   {comp['video_id'][:16]:<16} | {comp['whisper_len']:>7} | {comp['vertex_len']:>7} | {diff_sign}{comp['diff']:>6} ({diff_sign}{comp['diff_pct']:.1f}%)")
        
        if len(comparisons) > 10:
            print(f"   ... et {len(comparisons) - 10} autres")
        
        # Statistiques agrégées
        avg_whisper = sum(c['whisper_len'] for c in comparisons) / len(comparisons)
        avg_vertex = sum(c['vertex_len'] for c in comparisons) / len(comparisons)
        avg_diff = sum(c['diff'] for c in comparisons) / len(comparisons)
        
        print()
        print("   Moyennes:")
        print(f"   • Whisper: {avg_whisper:.0f} caractères")
        print(f"   • Vertex AI: {avg_vertex:.0f} caractères")
        print(f"   • Différence moyenne: {avg_diff:+.0f} ({(avg_diff/avg_whisper*100):+.1f}%)")
    else:
        print("🔍 Comparaisons Shadow Mode: Aucune trouvée")
    print()
    
    # Traitement vidéos
    processing = extract_processing_info(lines)
    if processing:
        successes = [p for p in processing if p.get('status') == 'success']
        failures = [p for p in processing if p.get('status') == 'failed']
        
        print(f"🎥 Traitement des Vidéos:")
        print(f"   ✅ Succès: {len(successes)}")
        print(f"   ❌ Échecs: {len(failures)}")
        
        if successes:
            methods = defaultdict(int)
            for s in successes:
                methods[s.get('method', 'unknown')] += 1
            print(f"\n   Méthodes utilisées:")
            for method, count in methods.items():
                print(f"   • {method}: {count}")
        
        if failures:
            print(f"\n   Erreurs récentes:")
            for f in failures[:5]:
                print(f"   • {f.get('timestamp', 'N/A')}: {f.get('error', 'Unknown')[:60]}")
    else:
        print("🎥 Traitement des Vidéos: Aucune information trouvée")
    print()
    
    print("="*80 + "\n")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Analyse les logs du worker YouTube')
    parser.add_argument('logfile', nargs='?', help='Fichier de log à analyser (stdin si omis)')
    args = parser.parse_args()
    
    try:
        analyze_logs(args.logfile)
    except Exception as e:
        print(f"❌ Erreur lors de l'analyse: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
