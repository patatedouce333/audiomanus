#!/usr/bin/env python3
"""
API FastAPI pour soumettre des transcriptions YouTube et interagir avec l'agent conversationnel.
"""

import json
import uuid
from typing import List, Optional, AsyncGenerator
from datetime import datetime

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, HttpUrl
from google.cloud import pubsub_v1
from loguru import logger

from config import settings
from database import get_session, Video, Transcript, Job, init_db
from vertex_ai_transcriber import VertexAITranscriber
from graphql_schema import schema

from strawberry.fastapi import GraphQLRouter

# Initialiser DB
init_db()

app = FastAPI(
    title="YouTube Transcription & Chat API",
    description="API pour transcrire des vidéos et discuter avec un agent IA.",
    version="1.2.0" # Version incrémentée
)

# Add GraphQL support
graphql_app = GraphQLRouter(schema)
app.include_router(graphql_app, prefix="/graphql")

# Clients
publisher = pubsub_v1.PublisherClient()
topic_path = publisher.topic_path(settings.project_id, settings.pubsub_topic)
vertex_transcriber = VertexAITranscriber()

# --- Modèles de Données ---

class TranscribeRequest(BaseModel): urls: List[HttpUrl]
class TranscribeResponse(BaseModel): status: str; job_ids: List[str]; message: str
class ChatRequest(BaseModel): session_id: str; message: str
class ChatResponse(BaseModel): session_id: str; response: str
class TranscriptResponse(BaseModel): id: int; video_id: str; method: str; language: str; text: str; created_at: datetime
class JobStatusResponse(BaseModel): job_id: str; video_id: str; status: str; error_message: Optional[str]; created_at: datetime; updated_at: datetime

# --- Endpoints ---

@app.get("/")
def root():
    return {"service": "YouTube Transcription & Chat API", "version": "1.2.0", "status": "healthy"}

@app.post("/chat", response_model=ChatResponse)
def chat_with_agent(request: ChatRequest):
    """Point d'entrée pour l'agent conversationnel (non-streamé)."""
    try:
        agent_response = vertex_transcriber.generate_chat_response(request.session_id, request.message)
        return ChatResponse(session_id=request.session_id, response=agent_response)
    except Exception as e:
        logger.error(f"Chat endpoint failed: {e}")
        raise HTTPException(status_code=500, detail="An error occurred in the chat agent.")

@app.post("/chat/stream") # NOUVEL ENDPOINT STREAMING
async def chat_with_agent_stream(request: ChatRequest):
    """Point d'entrée pour l'agent conversationnel (streaming)."""
    try:
        # La fonction retourne un générateur asynchrone
        stream_generator = vertex_transcriber.generate_chat_response_stream(
            request.session_id,
            request.message
        )
        return StreamingResponse(stream_generator, media_type="text/plain")
    except Exception as e:
        logger.error(f"Chat streaming endpoint failed: {e}")
        # Ne pas lever d'HTTPException ici car la réponse a peut-être déjà commencé
        # Le générateur gère sa propre erreur.
        async def error_stream():
            yield "Désolé, une erreur critique est survenue."
        return StreamingResponse(error_stream(), media_type="text/plain", status_code=500)

@app.post("/transcribe", response_model=TranscribeResponse)
def transcribe_videos(request: TranscribeRequest):
    """Soumet des URLs YouTube pour transcription asynchrone."""
    try:
        job_ids = []
        for url in request.urls:
            job_id = str(uuid.uuid4())
            message_data = {"url": str(url), "job_id": job_id, "submitted_at": datetime.utcnow().isoformat()}
            message_bytes = json.dumps(message_data).encode("utf-8")
            future = publisher.publish(topic_path, message_bytes)
            future.result()
            job_ids.append(job_id)
        return TranscribeResponse(status="success", job_ids=job_ids, message=f"{len(job_ids)} video(s) submitted")
    except Exception as e:
        logger.error(f"Error submitting transcription: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ... (Les autres endpoints restent les mêmes pour la brièveté) ...

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=settings.api_host, port=settings.api_port)
