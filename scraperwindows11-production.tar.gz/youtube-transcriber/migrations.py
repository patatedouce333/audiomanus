#!/usr/bin/env python3
"""Database migration scripts for adding vector search capabilities."""

from database import get_connection_pool


def enable_pgvector():
    """Enable pgvector extension in the database."""
    engine = get_connection_pool()
    with engine.connect() as conn:
        conn.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        conn.commit()
    print("pgvector extension enabled")


def add_embedding_column():
    """Add embedding column to transcripts table."""
    engine = get_connection_pool()
    with engine.connect() as conn:
        # Add the column
        conn.execute("ALTER TABLE transcripts ADD COLUMN IF NOT EXISTS embedding vector(768);")
        # Create an index for similarity search
        conn.execute("CREATE INDEX IF NOT EXISTS transcripts_embedding_idx ON transcripts USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);")
        conn.commit()
    print("Embedding column and index added to transcripts table")


if __name__ == "__main__":
    enable_pgvector()
    add_embedding_column()
    print("Migration completed successfully")