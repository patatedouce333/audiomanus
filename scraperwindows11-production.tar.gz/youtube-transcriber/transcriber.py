#!/usr/bin/env python3
"""Logique de transcription avec stratégie 3 niveaux."""

import os
import tempfile
from pathlib import Path
from typing import Dict, Optional, Tuple
import time

from loguru import logger
from youtube_transcript_api import YouTubeTranscriptApi, NoTranscriptFound
import yt_dlp
from vertex_ai_transcriber import VertexAITranscriber

from config import settings


class YouTubeTranscriber:
    """Transcripteur YouTube avec stratégie hybride utilisant Vertex AI Gemini."""

    def __init__(self):
        self.vertex_transcriber = VertexAITranscriber()


    
    def extract_video_id(self, url: str) -> Optional[str]:
        """Extrait le video_id d'une URL YouTube."""
        try:
            if "youtu.be/" in url:
                return url.split("youtu.be/")[1].split("?")[0]
            elif "youtube.com/watch?v=" in url:
                return url.split("v=")[1].split("&")[0]
            elif "youtube.com/embed/" in url:
                return url.split("embed/")[1].split("?")[0]
            else:
                return None
        except Exception as e:
            logger.error(f"Failed to extract video_id from {url}: {e}")
            return None
    
    def get_native_transcript(self, video_id: str) -> Optional[Dict]:
        """
        Niveau 1: Tente d'obtenir le transcript natif YouTube.
        Gratuit, instantané.
        """
        try:
            logger.info(f"Trying native transcript for {video_id}")
            transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)
            
            # Cherche d'abord en français, puis en anglais, puis auto-généré
            for lang in ['fr', 'en']:
                try:
                    transcript = transcript_list.find_transcript([lang])
                    data = transcript.fetch()
                    
                    # Formater le résultat
                    full_text = " ".join([item['text'] for item in data])
                    segments = [
                        {
                            "start": item['start'],
                            "end": item['start'] + item['duration'],
                            "text": item['text']
                        }
                        for item in data
                    ]
                    
                    logger.success(f"Native transcript found for {video_id} (lang: {lang})")
                    return {
                        "method": "native",
                        "language": lang,
                        "text": full_text,
                        "segments": segments
                    }
                except NoTranscriptFound:
                    continue
            
            logger.warning(f"No native transcript found for {video_id}")
            return None
            
        except Exception as e:
            logger.warning(f"Native transcript failed for {video_id}: {e}")
            return None
    
    def download_audio(self, video_id: str) -> Optional[str]:
        """Télécharge l'audio d'une vidéo YouTube."""
        try:
            logger.info(f"Downloading audio for {video_id}")
            temp_dir = tempfile.mkdtemp()
            audio_path = os.path.join(temp_dir, f"{video_id}.mp3")
            
            ydl_opts = {
                'format': 'bestaudio/best',
                'outtmpl': audio_path,
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '192',
                }],
                'quiet': True,
                'no_warnings': True,
            }
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                url = f"https://www.youtube.com/watch?v={video_id}"
                ydl.download([url])
            
            # yt-dlp ajoute .mp3 automatiquement
            final_path = audio_path if os.path.exists(audio_path) else audio_path + ".mp3"
            
            if os.path.exists(final_path):
                logger.success(f"Audio downloaded: {final_path}")
                return final_path
            else:
                logger.error(f"Audio file not found after download: {final_path}")
                return None
                
        except Exception as e:
            logger.error(f"Audio download failed for {video_id}: {e}")
            return None
    
    def transcribe_with_gemini(self, video_url: str) -> Optional[Dict]:
        """
        Niveau 2: Transcription avec Vertex AI Gemini.
        Utilise l'IA Google pour transcription précise avec analyse contextuelle.
        """
        try:
            logger.info(f"Transcribing with Gemini: {video_url}")
            start_time = time.time()

            # Télécharger la vidéo
            video_path = self.vertex_transcriber.download_video_only(video_url)
            if not video_path:
                logger.error("Failed to download video for Gemini transcription")
                return None

            # Pour Gemini, nous avons besoin de l'URI GCS. Simulons avec le fichier local pour l'instant
            # En production, il faudrait uploader vers GCS d'abord
            from google.cloud import storage
            import uuid

            client = storage.Client()
            bucket = client.bucket(settings.storage_bucket)
            blob_name = f"temp/{uuid.uuid4()}.mp4"
            blob = bucket.blob(blob_name)

            with open(video_path, 'rb') as video_file:
                blob.upload_from_file(video_file)

            gcs_uri = f"gs://{settings.storage_bucket}/{blob_name}"

            # Transcrire avec Gemini
            result, cost = self.vertex_transcriber.transcribe_video(gcs_uri, language="fr")
            processing_time = int(time.time() - start_time)

            # Nettoyer le fichier temporaire
            try:
                os.remove(video_path)
                blob.delete()  # Supprimer du GCS aussi
            except:
                pass

            if result:
                logger.success(f"Gemini transcription completed in {processing_time}s")
                return {
                    "method": "vertex-ai-gemini",
                    "language": "fr",
                    "text": result.get("text", ""),
                    "segments": result.get("segments", []),
                    "processing_time": processing_time,
                    "cost_usd": cost
                }

        except Exception as e:
            logger.error(f"Gemini transcription failed: {e}")
            return None
    
    def transcribe_video(self, url: str) -> Tuple[Optional[Dict], Optional[str]]:
        """
        Transcrit une vidéo YouTube avec stratégie 3 niveaux.
        
        Returns:
            (transcript_data, video_id) ou (None, None) si échec
        """
        # Extraire video_id
        video_id = self.extract_video_id(url)
        if not video_id:
            logger.error(f"Invalid YouTube URL: {url}")
            return None, None
        
        logger.info(f"Starting transcription for {video_id}")
        
        # Niveau 1: Native transcript
        result = self.get_native_transcript(video_id)
        if result:
            return result, video_id
        
        # Niveau 2: Vertex AI Gemini
        video_url = f"https://www.youtube.com/watch?v={video_id}"
        result = self.transcribe_with_gemini(video_url)

        if result:
            return result, video_id
        
        # Niveau 3: Together AI (TODO: implémenter si besoin)
        # if settings.together_api_key:
        #     result = self.transcribe_with_together_ai(audio_path)
        #     if result:
        #         return result, video_id
        
        logger.error(f"All transcription methods failed for {video_id}")
        return None, video_id
