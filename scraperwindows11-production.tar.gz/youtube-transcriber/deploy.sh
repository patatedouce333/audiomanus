#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="project-91ffa63d-6bed-405c-bc3"
REGION="europe-west1"
REPO="scraper-images"
SERVICE_ACCOUNT="app-ia-backend@project-91ffa63d-6bed-405c-bc3.iam.gserviceaccount.com"
SQL_PASSWORD="${SQL_PASSWORD:-m7JBMb+acUTlNNZolVBdqys6}"

echo "🔨 Building YouTube Transcriber image..."
gcloud builds submit \
  --tag="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/youtube-transcriber:latest" \
  --project="${PROJECT_ID}" \
  --timeout=30m

echo "🚀 Deploying Worker (Cloud Run Job)..."
gcloud run jobs create youtube-transcriber-worker \
  --image="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/youtube-transcriber:latest" \
  --region="${REGION}" \
  --project="${PROJECT_ID}" \
  --service-account="${SERVICE_ACCOUNT}" \
  --set-env-vars="PROJECT_ID=${PROJECT_ID},REGION=${REGION},PUBSUB_SUBSCRIPTION=scraper-agent-sub,STORAGE_BUCKET=scraper-results-${PROJECT_ID},SQL_CONNECTION_NAME=${PROJECT_ID}:${REGION}:scraper-db,SQL_USER=scraper_user,SQL_PASSWORD=${SQL_PASSWORD},SQL_DATABASE=scraper,USE_VERTEX_AI=True,SHADOW_MODE=True" \
  --tasks=1 \
  --max-retries=3 \
  --task-timeout=1800s \
  --memory=2Gi \
  --cpu=1 \
  --parallelism=1 \
  --command=python \
  --args=worker.py \
  --quiet \
  || gcloud run jobs update youtube-transcriber-worker \
    --image="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/youtube-transcriber:latest" \
    --region="${REGION}" \
    --project="${PROJECT_ID}" \
    --set-env-vars="PROJECT_ID=${PROJECT_ID},REGION=${REGION},PUBSUB_SUBSCRIPTION=scraper-agent-sub,STORAGE_BUCKET=scraper-results-${PROJECT_ID},SQL_CONNECTION_NAME=${PROJECT_ID}:${REGION}:scraper-db,SQL_USER=scraper_user,SQL_PASSWORD=${SQL_PASSWORD},SQL_DATABASE=scraper,USE_VERTEX_AI=True,SHADOW_MODE=True" \
    --tasks=1 \
    --max-retries=3 \
    --task-timeout=1800s \
    --memory=2Gi \
    --cpu=1 \
    --parallelism=1 \
    --command=python \
    --args=worker.py \
    --quiet

echo "🌐 Deploying API (Cloud Run Service)..."
gcloud run deploy youtube-transcriber-api \
  --image="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/youtube-transcriber:latest" \
  --region="${REGION}" \
  --project="${PROJECT_ID}" \
  --platform=managed \
  --service-account="${SERVICE_ACCOUNT}" \
  --set-env-vars="PROJECT_ID=${PROJECT_ID},REGION=${REGION},STORAGE_BUCKET=scraper-results-${PROJECT_ID},SQL_CONNECTION_NAME=${PROJECT_ID}:${REGION}:scraper-db,SQL_USER=scraper_user,SQL_PASSWORD=${SQL_PASSWORD},SQL_DATABASE=scraper" \
  --allow-unauthenticated \
  --memory=2Gi \
  --cpu=2 \
  --timeout=300 \
  --max-instances=10 \
  --command=uvicorn \
  --args=api:app,--host,0.0.0.0,--port,8080 \
  --quiet

echo ""
echo "✅ Deployment complete!"
echo ""
echo "API URL:"
gcloud run services describe youtube-transcriber-api --region="${REGION}" --project="${PROJECT_ID}" --format="value(status.url)"
echo ""
echo "Test command:"
echo 'curl -X POST $(gcloud run services describe youtube-transcriber-api --region=europe-west1 --project=project-91ffa63d-6bed-405c-bc3 --format="value(status.url)")/transcribe \'
echo '  -H "Content-Type: application/json" \'
echo '  -d '"'"'{"urls": ["https://www.youtube.com/watch?v=dQw4w9WgXcQ"]}'"'"
