#!/usr/bin/env python3
"""Modèles de base de données SQLAlchemy."""

import os
from datetime import datetime
from typing import Optional
from sqlalchemy import create_engine, Column, String, Integer, Boolean, DateTime, Text, JSON
from pgvector.sqlalchemy import Vector
from sqlalchemy.orm import declarative_base, sessionmaker
from google.cloud.sql.connector import Connector
import sqlalchemy

from config import settings

Base = declarative_base()


class Video(Base):
    """Modèle pour les vidéos YouTube."""
    
    __tablename__ = "videos"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    video_id = Column(String(50), unique=True, nullable=False, index=True)
    url = Column(Text, nullable=False)
    title = Column(Text)
    channel = Column(String(255))
    duration = Column(Integer)  # secondes
    uploaded_at = Column(DateTime)
    cost_usd = Column(sqlalchemy.Float, default=0.0)  # NOUVEAU: Coût estimé
    created_at = Column(DateTime, default=datetime.utcnow)


class Transcript(Base):
    """Modèle pour les transcriptions."""
    
    __tablename__ = "transcripts"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    video_id = Column(String(50), nullable=False, index=True)
    method = Column(String(50))  # 'native', 'vertex-ai-gemini', 'together-ai', 'vertex-ai'
    language = Column(String(10))
    text = Column(Text, nullable=False)
    segments = Column(JSON)  # timestamps
    visual_context = Column(JSON)  # NOUVEAU: Contexte visuel (Gemini)
    embedding = Column(Vector(768))  # Vector embedding for semantic search
    storage_path = Column(Text)  # GCS path
    processing_time = Column(Integer)  # secondes
    cost_usd = Column(sqlalchemy.Float, default=0.0)  # NOUVEAU: Coût estimé
    success = Column(Boolean, default=True)  # Success status
    created_at = Column(DateTime, default=datetime.utcnow)


class Job(Base):
    """Modèle pour les jobs de transcription."""
    
    __tablename__ = "jobs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    job_id = Column(String(100), unique=True, nullable=False, index=True)
    video_id = Column(String(50), nullable=False, index=True)
    status = Column(String(20), default="pending")  # pending, processing, completed, failed
    error_message = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ConversationHistory(Base):
    """Modèle pour l'historique des conversations."""

    __tablename__ = "conversation_history"

    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(100), nullable=False, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    sender = Column(String(50))  # 'user' or 'agent'
    message = Column(Text, nullable=False)


def get_connection_pool():
    """Crée un pool de connexions (Cloud SQL ou local)."""
    db_host = os.getenv("DB_HOST")
    
    if db_host:
        # Connexion locale standard
        db_user = settings.sql_user
        db_pass = settings.sql_password
        db_name = settings.sql_database
        db_port = os.getenv("DB_PORT", "5432")
        
        engine = sqlalchemy.create_engine(
            f"postgresql+pg8000://{db_user}:{db_pass}@{db_host}:{db_port}/{db_name}",
            pool_size=5,
            max_overflow=2,
        )
        return engine

    # Connexion Cloud SQL via le connector
    connector = Connector()
    
    def getconn():
        conn = connector.connect(
            settings.sql_connection_name,
            "pg8000",
            user=settings.sql_user,
            password=settings.sql_password,
            db=settings.sql_database
        )
        return conn
    
    engine = sqlalchemy.create_engine(
        "postgresql+pg8000://",
        creator=getconn,
        pool_size=5,
        max_overflow=2,
        pool_timeout=30,
        pool_recycle=1800,
    )
    
    return engine


def init_db():
    """Initialise la base de données (crée les tables)."""
    engine = get_connection_pool()
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)


def get_session():
    """Retourne une session de base de données."""
    engine = get_connection_pool()
    Session = sessionmaker(bind=engine)
    return Session()
