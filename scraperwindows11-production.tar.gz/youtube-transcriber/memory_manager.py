#!/usr/bin/env python3
"""Gestionnaire de mémoire pour l'agent conversationnel."""

from database import get_session, ConversationHistory

def load_history(session_id: str):
    """Charge l'historique d'une conversation depuis la base de données."""
    session = get_session()
    history = (
        session.query(ConversationHistory)
        .filter(ConversationHistory.session_id == session_id)
        .order_by(ConversationHistory.timestamp.asc())
        .all()
    )
    session.close()
    return history

def save_message(session_id: str, sender: str, message: str):
    """Sauvegarde un message dans la base de données."""
    session = get_session()
    new_message = ConversationHistory(
        session_id=session_id,
        sender=sender,
        message=message,
    )
    session.add(new_message)
    session.commit()
    session.close()
