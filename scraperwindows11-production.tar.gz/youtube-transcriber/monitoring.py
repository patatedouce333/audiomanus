#!/usr/bin/env python3
"""
Script de monitoring pour extraire les métriques de transcription.
Fonctionne en local (docker-compose) et en production (Cloud SQL).
"""

import os
import sys
from datetime import datetime, timedelta
from sqlalchemy import func, and_
from tabulate import tabulate

from database import get_session, Video, Transcript, Job
from config import settings


def get_performance_stats():
    """Récupère les statistiques de performance par méthode."""
    session = get_session()
    try:
        stats = session.query(
            Transcript.method,
            func.count(Transcript.id).label('count'),
            func.avg(Transcript.cost_usd).label('avg_cost'),
            func.sum(Transcript.cost_usd).label('total_cost'),
            func.avg(Transcript.processing_time).label('avg_time'),
            func.min(Transcript.created_at).label('first_transcription'),
            func.max(Transcript.created_at).label('last_transcription')
        ).group_by(Transcript.method).all()
        
        return stats
    finally:
        session.close()


def get_job_stats():
    """Récupère les statistiques des jobs."""
    session = get_session()
    try:
        stats = session.query(
            Job.status,
            func.count(Job.id).label('count')
        ).group_by(Job.status).all()
        
        return stats
    finally:
        session.close()


def get_recent_transcriptions(limit=10):
    """Récupère les dernières transcriptions."""
    session = get_session()
    try:
        transcripts = session.query(
            Transcript.video_id,
            Transcript.method,
            Transcript.cost_usd,
            Transcript.processing_time,
            Transcript.created_at
        ).order_by(Transcript.created_at.desc()).limit(limit).all()
        
        return transcripts
    finally:
        session.close()


def get_shadow_mode_comparison():
    """Compare les transcriptions en shadow mode (même video_id, différentes méthodes)."""
    session = get_session()
    try:
        # Trouver les video_ids qui ont plusieurs transcriptions
        duplicates = session.query(
            Transcript.video_id,
            func.count(Transcript.id).label('count')
        ).group_by(Transcript.video_id).having(func.count(Transcript.id) > 1).all()
        
        comparisons = []
        for video_id, count in duplicates:
            transcripts = session.query(Transcript).filter(
                Transcript.video_id == video_id
            ).all()
            
            if len(transcripts) == 2:
                t1, t2 = transcripts
                comparisons.append({
                    'video_id': video_id,
                    'method_1': t1.method,
                    'method_2': t2.method,
                    'cost_1': t1.cost_usd,
                    'cost_2': t2.cost_usd,
                    'time_1': t1.processing_time,
                    'time_2': t2.processing_time,
                    'text_len_1': len(t1.text) if t1.text else 0,
                    'text_len_2': len(t2.text) if t2.text else 0,
                })
        
        return comparisons
    finally:
        session.close()


def get_failed_jobs():
    """Récupère les jobs échoués avec leurs messages d'erreur."""
    session = get_session()
    try:
        failed = session.query(
            Job.job_id,
            Job.video_id,
            Job.error_message,
            Job.created_at
        ).filter(Job.status == 'failed').order_by(Job.created_at.desc()).limit(20).all()
        
        return failed
    finally:
        session.close()


def print_dashboard():
    """Affiche un dashboard complet dans le terminal."""
    print("\n" + "="*80)
    print(" 📊 DASHBOARD MONITORING - YouTube Transcription (Phase 2)")
    print("="*80 + "\n")
    
    # Configuration actuelle
    print(f"⚙️  Configuration:")
    print(f"   • Use Vertex AI: {settings.use_vertex_ai}")
    print(f"   • Shadow Mode: {settings.shadow_mode}")
    print(f"   • Project ID: {settings.project_id}")
    print(f"   • Database: {settings.sql_database}")
    print()
    
    # Stats des jobs
    print("📋 Statut des Jobs:")
    job_stats = get_job_stats()
    if job_stats:
        job_data = [[status, count] for status, count in job_stats]
        print(tabulate(job_data, headers=['Status', 'Count'], tablefmt='grid'))
    else:
        print("   Aucun job trouvé")
    print()
    
    # Stats par méthode
    print("🎯 Performance par Méthode de Transcription:")
    perf_stats = get_performance_stats()
    if perf_stats:
        perf_data = []
        for method, count, avg_cost, total_cost, avg_time, first, last in perf_stats:
            perf_data.append([
                method or 'N/A',
                count,
                f"${avg_cost:.4f}" if avg_cost else "$0.00",
                f"${total_cost:.2f}" if total_cost else "$0.00",
                f"{avg_time:.0f}s" if avg_time else "N/A",
                first.strftime('%Y-%m-%d %H:%M') if first else 'N/A'
            ])
        print(tabulate(perf_data, 
                      headers=['Méthode', 'Count', 'Coût Moyen', 'Coût Total', 'Temps Moyen', 'Première'],
                      tablefmt='grid'))
    else:
        print("   Aucune transcription trouvée")
    print()
    
    # Comparaison Shadow Mode
    print("🔍 Comparaisons Shadow Mode:")
    comparisons = get_shadow_mode_comparison()
    if comparisons:
        comp_data = []
        for c in comparisons[:10]:  # Limiter à 10 pour lisibilité
            cost_diff = (c['cost_2'] - c['cost_1']) if c['cost_1'] and c['cost_2'] else 0
            time_diff = (c['time_2'] - c['time_1']) if c['time_1'] and c['time_2'] else 0
            text_diff = c['text_len_2'] - c['text_len_1']
            
            comp_data.append([
                c['video_id'][:12],
                f"{c['method_1']} vs {c['method_2']}",
                f"${cost_diff:+.4f}",
                f"{time_diff:+.0f}s",
                f"{text_diff:+d} chars"
            ])
        print(tabulate(comp_data,
                      headers=['Video ID', 'Méthodes', 'Δ Coût', 'Δ Temps', 'Δ Texte'],
                      tablefmt='grid'))
    else:
        print("   Aucune comparaison shadow trouvée")
    print()
    
    # Dernières transcriptions
    print("🕐 Dernières Transcriptions:")
    recent = get_recent_transcriptions(5)
    if recent:
        recent_data = []
        for video_id, method, cost, time, created in recent:
            recent_data.append([
                video_id[:12],
                method or 'N/A',
                f"${cost:.4f}" if cost else "$0.00",
                f"{time}s" if time else "N/A",
                created.strftime('%Y-%m-%d %H:%M:%S')
            ])
        print(tabulate(recent_data,
                      headers=['Video ID', 'Méthode', 'Coût', 'Temps', 'Date'],
                      tablefmt='grid'))
    else:
        print("   Aucune transcription récente")
    print()
    
    # Jobs échoués
    failed = get_failed_jobs()
    if failed:
        print("❌ Jobs Échoués (derniers 5):")
        failed_data = []
        for job_id, video_id, error, created in failed[:5]:
            error_short = (error[:50] + '...') if error and len(error) > 50 else (error or 'N/A')
            failed_data.append([
                job_id[:12],
                video_id[:12] if video_id else 'N/A',
                error_short,
                created.strftime('%Y-%m-%d %H:%M')
            ])
        print(tabulate(failed_data,
                      headers=['Job ID', 'Video ID', 'Erreur', 'Date'],
                      tablefmt='grid'))
        print()
    
    print("="*80)
    print(f"⏰ Dernière mise à jour: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80 + "\n")


if __name__ == "__main__":
    try:
        print_dashboard()
    except Exception as e:
        print(f"❌ Erreur lors de la récupération des données: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
