#!/usr/bin/env python3
"""
Worker Cloud Run Job pour transcription YouTube.
Consomme Pub/Sub, transcrit vidéos, sauvegarde dans Storage + SQL.
"""

import os
import json
import sys
import uuid
from datetime import datetime

from loguru import logger
from google.cloud import pubsub_v1, storage
from tenacity import retry, stop_after_attempt, wait_exponential

from config import settings
from database import get_session, Video, Transcript, Job, init_db
from transcriber import YouTubeTranscriber
from vertex_ai_transcriber import VertexAITranscriber

# Configuration logging
logger.remove()
logger.add(sys.stdout, format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}", level="INFO")


class TranscriptionWorker:
    """Worker de transcription YouTube."""
    
    def __init__(self):
        self.transcriber = YouTubeTranscriber()
        self.vertex_transcriber = VertexAITranscriber()
        self.subscriber = pubsub_v1.SubscriberClient()
        self.storage_client = storage.Client()
        self.bucket = self.storage_client.bucket(settings.storage_bucket)
        self.subscription_path = self.subscriber.subscription_path(
            settings.project_id, 
            settings.pubsub_subscription
        )
        
        # Initialiser la base de données
        init_db()
        logger.info("Database initialized")
    
    def store_transcript_in_gcs(self, video_id: str, transcript_data: dict) -> str:
        """Stocke le transcript dans Cloud Storage."""
        try:
            timestamp = datetime.utcnow().isoformat()
            blob_path = f"transcripts/{video_id}/{timestamp}.json"
            
            blob = self.bucket.blob(blob_path)
            blob.upload_from_string(
                json.dumps(transcript_data, ensure_ascii=False, indent=2),
                content_type="application/json"
            )
            
            storage_path = f"gs://{settings.storage_bucket}/{blob_path}"
            logger.info(f"Transcript stored in GCS: {storage_path}")
            return storage_path
            
        except Exception as e:
            logger.error(f"Failed to store transcript in GCS: {e}")
            return ""
    
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    def process_video(self, url: str, job_id: str):
        """Traite une vidéo YouTube."""
        session = get_session()
        
        try:
            logger.info(f"Processing video: {url} (job: {job_id})")
            
            # Créer le job
            job = Job(job_id=job_id, video_id="", status="processing")
            session.add(job)
            session.commit()
            
            # CHOIX DE LA MÉTHODE (Phase 2)
            transcript_data = None
            video_id = None
            
            if settings.shadow_mode:
                logger.info("SHADOW MODE ENABLED: Running both pipelines")
                # 1. Pipeline Original (Whisper/Native)
                orig_data, vid_id = self.transcriber.transcribe_video(url)
                
                # 2. Pipeline Vertex AI (Shadow)
                try:
                    # Download & Upload
                    local_path = self.vertex_transcriber.download_video_only(url)
                    if local_path:
                        temp_gcs_path = f"shadow/{vid_id}.mp4"
                        blob = self.bucket.blob(temp_gcs_path)
                        blob.upload_from_filename(local_path)
                        gcs_uri = f"gs://{settings.storage_bucket}/{temp_gcs_path}"
                        
                        vertex_data, cost = self.vertex_transcriber.transcribe_video(gcs_uri)
                        vertex_data["cost_usd"] = cost
                        
                        # Log comparison (simplified)
                        logger.info(f"SHADOW COMPARE [{vid_id}]: Whisper len={len(orig_data['text'])}, Vertex len={len(vertex_data['text'])}")
                        
                        # Nettoyage
                        os.remove(local_path)
                        blob.delete()
                except Exception as shadow_e:
                    logger.warning(f"Shadow pipeline failed: {shadow_e}")
                
                # On garde le résultat original comme vérité terrain pendant le shadow mode
                transcript_data = orig_data
                video_id = vid_id
                transcript_data["method"] = orig_data.get("method", "vertex-ai-gemini")
                transcript_data["cost_usd"] = 0.0

            elif settings.use_vertex_ai:
                logger.info("Using Vertex AI for transcription")
                # 1. Download basic file
                local_path = self.vertex_transcriber.download_video_only(url)
                if not local_path:
                    raise Exception("Failed to download video for Vertex AI")
                
                # 2. Upload to GCS temporarily for Vertex AI
                video_id = self.vertex_transcriber.extract_video_id(url)
                temp_gcs_path = f"temp/{video_id}.mp4"
                blob = self.bucket.blob(temp_gcs_path)
                blob.upload_from_filename(local_path)
                gcs_uri = f"gs://{settings.storage_bucket}/{temp_gcs_path}"
                
                # 3. Transcribe with Vertex AI
                transcript_data, cost = self.vertex_transcriber.transcribe_video(gcs_uri)
                transcript_data["method"] = "vertex-ai"
                transcript_data["cost_usd"] = cost
                
                # Nettoyage
                os.remove(local_path)
            else:
                # Ancienne méthode (Niveau 1 native, Niveau 2 Whisper)
                transcript_data, video_id = self.transcriber.transcribe_video(url)
                transcript_data["cost_usd"] = 0.0 # Whisper local approx 0
            
            if not transcript_data or not video_id:
                raise Exception("Transcription failed")
            
            # Mettre à jour le job avec video_id
            job.video_id = video_id
            session.commit()
            
            # Vérifier si vidéo existe
            video = session.query(Video).filter_by(video_id=video_id).first()
            if not video:
                video = Video(
                    video_id=video_id,
                    url=url,
                    title=f"Video {video_id}",  # TODO: fetch metadata with yt-dlp
                )
                session.add(video)
                session.commit()
            
            # Stocker dans GCS
            storage_path = self.store_transcript_in_gcs(video_id, transcript_data)
            
            # Sauvegarder dans SQL
            transcript = Transcript(
                video_id=video_id,
                method=transcript_data.get("method"),
                language=transcript_data.get("language"),
                text=transcript_data.get("text"),
                segments=transcript_data.get("segments"),
                visual_context=transcript_data.get("visual_context"),
                storage_path=storage_path,
                processing_time=transcript_data.get("processing_time", 0),
                cost_usd=transcript_data.get("cost_usd", 0.0)
            )
            session.add(transcript)
            
            # Mettre à jour le coût sur la vidéo aussi
            if video:
                video.cost_usd = (video.cost_usd or 0.0) + transcript_data.get("cost_usd", 0.0)

            # Marquer job comme terminé
            job.status = "completed"
            session.commit()
            
            logger.success(f"Video {video_id} processed successfully (method: {transcript_data['method']})")
            
        except Exception as e:
            logger.error(f"Error processing video {url}: {e}")
            
            # Marquer job comme échoué
            if job:
                job.status = "failed"
                job.error_message = str(e)
                session.commit()
            
            raise
        
        finally:
            session.close()
    
    def callback(self, message: pubsub_v1.subscriber.message.Message):
        """Callback pour traiter un message Pub/Sub."""
        try:
            data = json.loads(message.data.decode("utf-8"))
            url = data.get("url")
            job_id = data.get("job_id", str(uuid.uuid4()))
            
            if not url:
                logger.error("Message missing 'url' field")
                message.ack()
                return
            
            # Vérifier si c'est une URL YouTube
            if "youtube.com" not in url and "youtu.be" not in url:
                logger.warning(f"Not a YouTube URL, skipping: {url}")
                message.ack()
                return
            
            logger.info(f"Received YouTube URL: {url}")
            
            # Traiter la vidéo
            self.process_video(url, job_id)
            
            # Acknowledge
            message.ack()
            logger.success(f"Message acknowledged for {url}")
            
        except Exception as e:
            logger.error(f"Error processing message: {e}")
            message.nack()
    
    def run(self):
        """Lance le worker."""
        logger.info(f"Starting worker, listening on: {self.subscription_path}")
        
        streaming_pull_future = self.subscriber.subscribe(
            self.subscription_path,
            callback=self.callback
        )
        
        logger.info("Worker is listening for messages...")
        
        try:
            # Block jusqu'à timeout ou exception
            streaming_pull_future.result(timeout=1800)  # 30 minutes max
        except Exception as e:
            logger.error(f"Streaming pull error: {e}")
            streaming_pull_future.cancel()
        finally:
            logger.info("Worker shutting down")


if __name__ == "__main__":
    worker = TranscriptionWorker()
    worker.run()
