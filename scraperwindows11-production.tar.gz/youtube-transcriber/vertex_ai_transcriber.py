#!/usr/bin/env python3
"""
Transcripteur et agent conversationnel basé sur Vertex AI Gemini.
"""

import os
import time
import json
import re
import tempfile
from typing import Dict, List, Optional, Tuple, AsyncGenerator

from loguru import logger
import vertexai
from vertexai.generative_models import GenerativeModel, Part
import yt_dlp

from config import settings
from memory_manager import load_history, save_message


class VertexAITranscriber:
    """
    Implémentation de la transcription et conversation via Vertex AI Gemini.
    """
    
    def __init__(self):
        self.project_id = settings.project_id
        self.location = os.getenv("GCP_LOCATION", "us-central1")
        vertexai.init(project=self.project_id, location=self.location)
        self.model = GenerativeModel("gemini-1.5-pro-002")

    # ... (méthodes de téléchargement et d'extraction d'ID vidéo inchangées) ...
    def download_video_only(self, url: str) -> Optional[str]:
        try:
            video_id = self.extract_video_id(url)
            if not video_id: return None
            output_path = os.path.join(tempfile.gettempdir(), f"{video_id}.mp4")
            ydl_opts = {'format': 'bestaudio/best', 'outtmpl': output_path, 'quiet': True, 'no_warnings': True}
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])
            return output_path
        except Exception as e:
            logger.error(f"Failed to download video with yt-dlp: {e}")
            return None

    def extract_video_id(self, url: str) -> Optional[str]:
        if "youtu.be/" in url:
            return url.split("youtu.be/")[1].split("?")[0]
        elif "v=" in url:
            return url.split("v=")[1].split("&")[0]
        return None

    # --- Méthodes de conversation ---

    def generate_chat_response(self, session_id: str, user_message: str) -> str:
        """Génère une réponse conversationnelle unique (non-streamée)."""
        try:
            history = load_history(session_id)
            prompt_history = []
            for entry in history:
                role = "user" if entry.sender == "user" else "model"
                prompt_history.append({"role": role, "parts": [{"text": entry.message}]})
            
            conversation = self.model.start_chat(history=prompt_history)
            response = conversation.send_message(user_message)
            agent_response = response.text
            
            save_message(session_id, "user", user_message)
            save_message(session_id, "agent", agent_response)
            
            return agent_response
        except Exception as e:
            logger.error(f"Chat generation failed: {e}")
            return "Désolé, une erreur est survenue."

    async def generate_chat_response_stream(self, session_id: str, user_message: str) -> AsyncGenerator[str, None]:
        """Génère une réponse conversationnelle en streaming."""
        full_agent_response = ""
        try:
            history = load_history(session_id)
            prompt_history = []
            for entry in history:
                role = "user" if entry.sender == "user" else "model"
                prompt_history.append({"role": role, "parts": [{"text": entry.message}]})

            conversation = self.model.start_chat(history=prompt_history)
            stream = conversation.send_message(user_message, stream=True)

            for chunk in stream:
                # Le SDK gère la reconnexion et les erreurs de manière transparente dans l'itérateur
                chunk_text = chunk.text
                full_agent_response += chunk_text
                yield chunk_text

        except Exception as e:
            logger.error(f"Chat streaming failed: {e}")
            error_message = "\nDésolé, une erreur est survenue pendant le streaming."
            yield error_message
            full_agent_response += error_message
        finally:
            # Sauvegarder l'échange complet une fois le streaming terminé
            save_message(session_id, "user", user_message)
            save_message(session_id, "agent", full_agent_response)
            logger.info(f"Saved full exchange for session {session_id}")

    # ... (méthode de transcription vidéo inchangée) ...
    def transcribe_video(self, gcs_uri: str, language: str = "fr") -> Tuple[Optional[Dict], float]:
        start_time = time.time()
        try:
            logger.info(f"Starting Vertex AI transcription for {gcs_uri}")
            video_part = Part.from_uri(mime_type="video/mp4", uri=gcs_uri)
            prompt = "Analyse cette vidéo et fournis une transcription JSON complète."
            response = self.model.generate_content(
                [video_part, prompt],
                generation_config={"max_output_tokens": 8192, "temperature": 0.1, "response_mime_type": "application/json"}
            )
            content = re.sub(r'```json\n?|\n?```', '', response.text).strip()
            data = json.loads(content)
            estimated_cost = 0.005
            duration = time.time() - start_time
            logger.success(f"Vertex AI transcription completed in {duration:.2f}s")
            return data, estimated_cost
        except Exception as e:
            logger.error(f"Vertex AI transcription failed: {e}")
            return None, 0.0
