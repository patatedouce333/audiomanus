# YouTube Transcriber - Backend complet

## 🎯 Architecture

```
API (Cloud Run Service)
  ↓ POST /transcribe
Pub/Sub (scraper-topic)
  ↓
Worker (Cloud Run Job)
  ↓
├── YouTube Native Transcript (gratuit, instant)
├── faster-whisper local (2min/h vidéo)
└── Together.AI API (ultra-rapide)
  ↓
Cloud Storage + Cloud SQL
```

## 📦 Stack technique

- **yt-dlp** : download audio YouTube
- **youtube-transcript-api** : transcripts natifs
- **faster-whisper** : Whisper large-v3 optimisé
- **FastAPI** : API REST
- **SQLAlchemy** : ORM PostgreSQL
- **Google Cloud** : Pub/Sub, Storage, Cloud SQL, Cloud Run

## 🚀 Déploiement

### 1. Build & Deploy
```bash
cd youtube-transcriber
chmod +x deploy.sh
export SQL_PASSWORD="m7JBMb+acUTlNNZolVBdqys6"
./deploy.sh
```

### 2. Tester l'API
```bash
API_URL="https://youtube-transcriber-api-xxx.run.app"

# Soumettre une vidéo
curl -X POST "${API_URL}/transcribe" \
  -H "Content-Type: application/json" \
  -d '{"urls": ["https://www.youtube.com/watch?v=dQw4w9WgXcQ"]}'

# Récupérer le statut
curl "${API_URL}/status/{job_id}"

# Lister les transcripts
curl "${API_URL}/transcripts"

# Récupérer un transcript
curl "${API_URL}/transcript/{video_id}"
```

### 3. Démarrer le worker manuellement
```bash
gcloud run jobs execute youtube-transcriber-worker \
  --region=europe-west1 \
  --project=project-91ffa63d-6bed-405c-bc3
```

## 📊 Performance

- **Vidéo 10min** : ~30s (native) ou ~1min (Whisper)
- **Vidéo 1h** : ~2min (Whisper large-v3)
- **Batch 100 vidéos** : parallélisé sur 300 workers

## 🔧 Configuration

Variables d'environnement (définies dans `config.py`) :
- `PROJECT_ID` : projet GCP
- `PUBSUB_TOPIC` : topic Pub/Sub
- `STORAGE_BUCKET` : bucket Cloud Storage
- `SQL_CONNECTION_NAME` : connexion Cloud SQL
- `WHISPER_MODEL` : modèle Whisper (default: large-v3)

## 📝 Endpoints API

- `GET /` : health check
- `POST /transcribe` : soumettre URLs YouTube
- `GET /transcripts` : lister transcripts (avec filtres)
- `GET /transcript/{video_id}` : récupérer transcript complet
- `GET /status/{job_id}` : statut d'un job
- `GET /videos` : lister vidéos traitées

## 🗄️ Modèles de données

### Video
- `video_id` : ID YouTube
- `url` : URL complète
- `title`, `channel`, `duration`

### Transcript
- `video_id` : référence vidéo
- `method` : native, faster-whisper, together-ai
- `language` : langue détectée
- `text` : transcript complet
- `segments` : timestamps JSON

### Job
- `job_id` : UUID unique
- `status` : pending, processing, completed, failed
- `error_message` : si échec

## 🔍 Monitoring

```bash
# Logs API
gcloud logging read "resource.type=cloud_run_revision AND resource.labels.service_name=youtube-transcriber-api" --limit=50

# Logs Worker
gcloud logging read "resource.type=cloud_run_job AND resource.labels.job_name=youtube-transcriber-worker" --limit=50

# Transcripts dans Storage
gsutil ls gs://scraper-results-project-91ffa63d-6bed-405c-bc3/transcripts/

# Requêtes SQL
gcloud sql connect scraper-db --user=scraper_user
# Dans psql:
# \c scraper
# SELECT video_id, method, language, created_at FROM transcripts ORDER BY created_at DESC LIMIT 10;
```

## 🧪 Tests locaux

```bash
# Créer .env
cat > .env << EOF
PROJECT_ID=project-91ffa63d-6bed-405c-bc3
SQL_PASSWORD=m7JBMb+acUTlNNZolVBdqys6
EOF

# Installer dépendances
pip install -r requirements.txt

# Lancer API locale
python api.py

# Lancer worker local (nécessite auth GCP)
python worker.py
```
