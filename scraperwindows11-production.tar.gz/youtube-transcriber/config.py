#!/usr/bin/env python3
"""Configuration centralisée du backend YouTube Transcriber."""

import os
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Configuration du projet."""
    
    # GCP Project
    project_id: str = "project-91ffa63d-6bed-405c-bc3"
    region: str = "europe-west1"
    
    # Pub/Sub
    pubsub_topic: str = "scraper-topic"
    pubsub_subscription: str = "scraper-agent-sub"
    
    # Cloud Storage
    storage_bucket: str = "scraper-results-project-91ffa63d-6bed-405c-bc3"
    
    # Cloud SQL
    sql_connection_name: str = "project-91ffa63d-6bed-405c-bc3:europe-west1:scraper-db"
    sql_user: str = "scraper_user"
    sql_password: str = "m7JBMb+acUTlNNZolVBdqys6"
    sql_database: str = "scraper"
    
    # Gemini AI (Google)
    gemini_model: str = "gemini-1.5-pro-002"
    vertex_ai_location: str = "us-central1"
    
    # Together AI (optional)
    together_api_key: str = ""
    
    # API
    api_host: str = "0.0.0.0"
    api_port: int = 8080
    
    # Modernization (Phase 2)
    use_vertex_ai: bool = True
    shadow_mode: bool = False
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
