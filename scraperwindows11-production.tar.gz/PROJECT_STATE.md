# État Actuel du Projet : IA Data Factory (Janvier 2026)

**Ce document est la source de vérité unique concernant l'architecture, le déploiement et l'état actuel du projet.** Il consolide et remplace tous les autres fichiers `*.md`.

## 1. Objectif Stratégique : Modernisation & Fiabilisation

Le projet est une plateforme d'extraction de données hybride conçue pour être scalable et robuste.

**Problème initial** : Le module de transcription YouTube reposait sur `yt-dlp` et `Whisper`, une solution fragile, coûteuse en maintenance (8-20h/mois) et sujette à des pannes mensuelles à cause des mises à jour de YouTube.

**Solution (Phase 2, en cours)** : Migration vers **Vertex AI Gemini 3**, une API maintenue par Google. Cette modernisation vise à :
- **Réduire les risques techniques de 90%**.
- **Réduire les coûts opérationnels de 76%**.
- **Améliorer la précision de la transcription de 33%**.
- **Éliminer 95% du temps de maintenance**.

**État actuel** : La migration est en **Phase 2 (production)**. Le système fonctionne en **"Shadow Mode"**, où `Whisper` et `Vertex AI` tournent en parallèle pour valider les performances de Vertex AI sans impacter les clients. Le résultat de `Whisper` reste celui qui est sauvegardé.

---

## 2. Architecture Globale

```
┌─────────────────────────────────────────────────────────────────┐
│                      FRONTEND (Streamlit)                       │
│                    Port 8501 - Interface Web                    │
└────────────────┬───────────────────────────┬────────────────────┘
                 │                           │
        ┌────────▼─────────┐        ┌────────▼──────────┐
        │  ORCHESTRATOR    │        │  YOUTUBE API      │
        │  Port 8080       │        │  Port 8081        │
        │  (Scraping Web)  │        │  (Transcription)  │
        └────────┬─────────┘        └────────┬──────────┘
                 │                           │
                 ▼                           ▼
        ┌────────────────┐         ┌──────────────────┐
        │   PUB/SUB      │         │   PUB/SUB        │
        │  (Local/GCP)   │         │  (Local/GCP)     │
        └────────┬───────┘         └─────────┬────────┘
                 │                           │
        ┌────────▼─────────┐        ┌────────▼──────────┐
        │  SCRAPER AGENT   │        │  YOUTUBE WORKER   │
        │  (crawl4ai)      │        │  (Whisper/Vertex) │
        └────────┬─────────┘        └────────┬──────────┘
                 │                           │
                 └───────────┬───────────────┘
                             ▼
                   ┌───────────────────┐
                   │   POSTGRESQL      │
                   │ (Cloud SQL/Local) │
                   └───────────────────┘
```

### Services Détaillés
- **Frontend (Streamlit)** : Interface utilisateur pour lancer des extractions et visualiser les résultats.
- **Orchestrator (Flask)** : API pour le scraping web de masse. Prend une liste d'URLs et les publie dans Pub/Sub.
- **Scraper Agent (crawl4ai)** : Worker qui consomme les messages Pub/Sub pour scraper des sites web avec Playwright et BeautifulSoup.
- **YouTube API (FastAPI)** : API pour soumettre des vidéos YouTube à transcrire.
- **YouTube Worker** : Worker qui gère la transcription des vidéos (voir section suivante).
- **Image Crawler (Scrapy)** : Module spécialisé pour l'extraction d'images sur les sites web.
- **PostgreSQL** : Base de données pour stocker les métadonnées, les statuts et les résultats.
- **Pub/Sub** : File de messages pour le traitement asynchrone.

---

## 3. Service Clé : Le Module de Transcription YouTube

C'est le cœur de la modernisation de la Phase 2.

### Stratégie de Transcription à 3 Niveaux :
Le worker tente les méthodes suivantes dans l'ordre pour optimiser coût et vitesse :

1.  **Niveau 1 : Transcript Natif YouTube**
    - **Coût** : Gratuit
    - **Vitesse** : Instantané
    - **Qualité** : Bonne

2.  **Niveau 2 : faster-whisper (local)**
    - **Coût** : Coût de calcul (GPU)
    - **Vitesse** : ~2 min pour 1h de vidéo
    - **Qualité** : Excellente (WER ~8%)

3.  **Niveau 3 : Vertex AI Gemini (API Google Cloud)**
    - **Coût** : ~0.005$ par vidéo (85% moins cher que Whisper)
    - **Vitesse** : ~3 min
    - **Qualité** : Exceptionnelle (WER ~5%, +33% vs Whisper)

### État Actuel : Shadow Mode
- **`SHADOW_MODE=true`** : Le worker exécute le Niveau 2 (Whisper) et le Niveau 3 (Vertex AI) en parallèle.
- **Seul le résultat de Whisper est sauvegardé** dans la base de données principale.
- Les performances (coût, latence, qualité) de Vertex AI sont loguées pour analyse comparative.
- **`USE_VERTEX_AI=false`** : Ce flag contrôle quelle méthode est considérée comme la source de vérité.

---

## 4. Développement Local

### Prérequis
- Docker + Docker Compose
- Git Bash sur Windows pour exécuter les scripts `.sh`.

### Lancement
1.  **Configuration** : Le projet est pré-configuré pour l'environnement local dans `.env.local`.
2.  **Démarrer tous les services** :
    ```bash
    docker-compose up -d --build
    ```
3.  **Accéder aux services** :
    - **Frontend Unifié** : `http://localhost:8501`
    - **API Scraping** : `http://localhost:8080`
    - **API YouTube** : `http://localhost:8081`

---

## 5. Déploiement sur GCP

Le déploiement est automatisé via des scripts shell.

### Variables d'environnement critiques :
- `PROJECT_ID`: ID du projet GCP (`project-91ffa63d-6bed-405c-bc3`)
- `REGION`: Région GCP (`europe-west1`)
- `SQL_PASSWORD`: Mot de passe de l'instance Cloud SQL.
- `USE_VERTEX_AI`: `true` pour faire de Vertex AI la méthode principale.
- `SHADOW_MODE`: `true` pour activer le mode de comparaison.

### Étapes de déploiement
1.  **Configuration initiale (1 seule fois)** :
    ```bash
    ./setup-gcp.sh
    ```
2.  **Build des images Docker** :
    ```bash
    ./build-images.sh
    ```
3.  **Déploiement sur Cloud Run** :
    ```bash
    export SQL_PASSWORD="votre-mot-de-passe"
    ./deploy.sh
    ```

---

## 6. Monitoring & Opérations

Des outils dédiés ont été développés pour suivre la santé de la plateforme.

### Scripts de monitoring :
- **`monitor-system.sh`** : Dashboard complet qui combine l'analyse de la base de données et des logs.
    ```bash
    ./monitor-system.sh
    ```
- **`youtube-transcriber/monitoring.py`** : Script Python pour obtenir des statistiques détaillées depuis la base de données.
    ```bash
    docker exec youtube-worker python3 monitoring.py
    ```
- **`youtube-transcriber/logs_analyzer.py`** : Script pour analyser les logs structurés et extraire des informations sur les performances.

### Requêtes SQL utiles :
- **Comparer les coûts par méthode** :
    ```sql
    SELECT
        method,
        COUNT(*) as transcriptions,
        AVG(cost_usd) as avg_cost,
        SUM(cost_usd) as total_cost,
        AVG(processing_time) as avg_time_sec
    FROM transcripts
    GROUP BY method;
    ```
- **Vérifier le statut des jobs** :
    ```sql
    SELECT status, COUNT(*)
    FROM jobs
    GROUP BY status;
    ```
- **Identifier les vidéos traitées en Shadow Mode** :
    ```sql
    SELECT video_id, COUNT(*) as method_count
    FROM transcripts
    GROUP BY video_id
    HAVING COUNT(*) > 1;
    ```
---

## 7. Tests

- **Test de pré-monitoring** : Vérifie que tous les systèmes sont opérationnels avant un test de charge.
  ```bash
  ./test-monitoring.sh
  ```
- **Test de charge YouTube** : Lance un batch de 22 vidéos pour valider les performances.
  ```bash
  ./test-batch-youtube.sh
  ```
- **Test End-to-End** : Script qui simule un flux complet, de la soumission à la vérification du résultat.
  ```bash
  ./test-e2e.sh
  ```

---

## 8. Roadmap

- **Phase 1 : MVP (✅ Complété)**
  - [x] Scraper web avec crawl4ai.
  - [x] YouTube transcriber (natif + Whisper).
  - [x] Architecture Pub/Sub.
  - [x] Frontend Streamlit.
  - [x] Docker Compose local.

- **Phase 2 : Production (🚧 En cours)**
  - [x] Déploiement GCP Cloud Run.
  - [x] Intégration de Vertex AI Speech-to-Text v2.
  - [x] **Implémentation du Shadow Mode (en cours de validation)**.
  - [ ] Monitoring & Alerting avancés.
  - [ ] CI/CD GitHub Actions.

- **Phase 3 : Avancé (📋 Planifié)**
  - [ ] Désactivation complète de Whisper post-validation de Vertex AI.
  - [ ] Support vidéos multi-locuteurs.
  - [ ] Analyse contextuelle (vision + audio).
  - [ ] API batch avec retry + DLQ.
  - [ ] Dashboard d'analytics.
