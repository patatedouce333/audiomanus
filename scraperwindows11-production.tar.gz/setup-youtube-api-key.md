# Configuration de la clé API YouTube

## APIs activées ✅
- YouTube Data API v3
- Cloud Speech-to-Text API
- Cloud Translation API
- Secret Manager API

## Créer une clé API YouTube (manuel)

1. **Ouvre la console GCP** :
   ```
   https://console.cloud.google.com/apis/credentials?project=project-91ffa63d-6bed-405c-bc3
   ```

2. **Créer une clé API** :
   - Clique sur "Créer des identifiants" → "Clé API"
   - Une clé sera générée (ex: `AIzaSyDxxxxxxxxxxxxxxxxxxxxxxxxxx`)
   - **Restreindre la clé** :
     - Application restrictions : None (ou HTTP referrers si web)
     - API restrictions : Sélectionne "YouTube Data API v3"

3. **Stocker la clé dans Secret Manager** :
   ```bash
   # Créer le secret (remplace YOUR_API_KEY par ta vraie clé)
   echo -n "YOUR_API_KEY" | gcloud secrets create youtube-api-key \
     --data-file=- \
     --project=project-91ffa63d-6bed-405c-bc3 \
     --replication-policy="automatic"
   
   # Accorder l'accès au service account
   gcloud secrets add-iam-policy-binding youtube-api-key \
     --member="serviceAccount:app-ia-backend@project-91ffa63d-6bed-405c-bc3.iam.gserviceaccount.com" \
     --role="roles/secretmanager.secretAccessor" \
     --project=project-91ffa63d-6bed-405c-bc3
   ```

4. **Utiliser le secret dans Cloud Run** :
   ```bash
   # Lors du déploiement, monter le secret comme variable d'env
   gcloud run deploy SERVICE_NAME \
     --set-secrets=YOUTUBE_API_KEY=youtube-api-key:latest \
     --region=europe-west1
   ```

## Alternative : créer via gcloud (limitée)

⚠️ Note : `gcloud` ne peut pas créer de clés API directement. Tu dois passer par la console ou l'API REST.

## Commande de test (après création de la clé)

```bash
# Test direct avec curl
curl "https://www.googleapis.com/youtube/v3/videos?id=VIDEO_ID&key=YOUR_API_KEY&part=snippet,contentDetails"
```

## Code Python pour récupérer le secret

```python
from google.cloud import secretmanager

def get_youtube_api_key(project_id="project-91ffa63d-6bed-405c-bc3"):
    client = secretmanager.SecretManagerServiceClient()
    name = f"projects/{project_id}/secrets/youtube-api-key/versions/latest"
    response = client.access_secret_version(request={"name": name})
    return response.payload.data.decode("UTF-8")

# Usage
api_key = get_youtube_api_key()
```
