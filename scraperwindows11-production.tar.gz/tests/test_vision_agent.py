
import unittest
from unittest.mock import patch, MagicMock
import json
import sys
import os

# Ajout du répertoire parent au path pour trouver le module 'agent'
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from agent.vision_agent import VisionAgent

class TestVisionAgent(unittest.TestCase):
    """
    Tests unitaires pour le VisionAgent.
    Ces tests utilisent des mocks pour simuler le comportement du webdriver
    et de l'API Gemini, évitant ainsi les appels réseau réels.
    """

    def setUp(self):
        """Initialise une instance de VisionAgent avant chaque test."""
        self.agent = VisionAgent()

    @patch('agent.vision_agent.webdriver.Chrome')
    @patch('agent.vision_agent.genai.GenerativeModel')
    def test_extract_visual_data_success(self, mock_generative_model, mock_webdriver):
        """
        Vérifie que l'extraction de données visuelles réussit lorsque
        les dépendances fonctionnent correctement.
        """
        # --- Configuration des Mocks ---
        mock_driver_instance = MagicMock()
        mock_driver_instance.get_screenshot_as_png.return_value = b'fake_screenshot'
        mock_webdriver.return_value.__enter__.return_value = mock_driver_instance

        mock_model_instance = MagicMock()
        mock_gemini_response = MagicMock()
        mock_gemini_response.text = "Titre principal de la page"
        mock_model_instance.generate_content.return_value = mock_gemini_response
        mock_generative_model.return_value = mock_model_instance

        # --- Appel de la méthode ---
        url = "https://example.com"
        prompt = "Quel est le titre de la page ?"
        result = self.agent.extract_visual_data(url, prompt)

        # --- Assertions ---
        self.assertEqual(result, "Titre principal de la page")
        mock_driver_instance.get.assert_called_once_with(url)
        mock_model_instance.generate_content.assert_called_once()
        self.assertIn(prompt, mock_model_instance.generate_content.call_args[0][0][0])

    @patch('agent.vision_agent.webdriver.Chrome')
    @patch('agent.vision_agent.genai.GenerativeModel')
    def test_find_element_coordinates_success(self, mock_generative_model, mock_webdriver):
        """
        Vérifie que la localisation d'élément réussit et parse
        correctement le JSON retourné par le modèle.
        """
        # --- Configuration des Mocks ---
        mock_driver_instance = MagicMock()
        mock_driver_instance.get_screenshot_as_png.return_value = b'fake_screenshot'
        mock_webdriver.return_value.__enter__.return_value = mock_driver_instance

        mock_model_instance = MagicMock()
        mock_gemini_response = MagicMock()
        # Le modèle peut retourner le JSON dans un bloc de code markdown
        mock_gemini_response.text = '''```json
{"x": 120, "y": 450, "width": 80, "height": 40}
```'''
        mock_model_instance.generate_content.return_value = mock_gemini_response
        mock_generative_model.return_value = mock_model_instance

        # --- Appel de la méthode ---
        url = "https://example.com"
        description = "le bouton de connexion bleu"
        result = self.agent.find_element_coordinates(url, description)

        # --- Assertions ---
        self.assertEqual(result, {"x": 120, "y": 450, "width": 80, "height": 40})
        mock_driver_instance.get.assert_called_once_with(url)
        self.assertIn(description, mock_model_instance.generate_content.call_args[0][0][1])

    @patch('agent.vision_agent.webdriver.Chrome')
    def test_analysis_fails_on_browser_error(self, mock_webdriver):
        """
        Vérifie que les méthodes retournent None si le navigateur
        lève une exception (ex: page inaccessible).
        """
        # --- Configuration des Mocks ---
        mock_driver_instance = MagicMock()
        mock_driver_instance.get.side_effect = Exception("Timeout loading page")
        mock_webdriver.return_value.__enter__.return_value = mock_driver_instance

        # --- Appel et Assertions ---
        result_extract = self.agent.extract_visual_data("https://example.com", "un prompt")
        result_find = self.agent.find_element_coordinates("https://example.com", "un élément")

        self.assertIsNone(result_extract)
        self.assertIsNone(result_find)

if __name__ == '__main__':
    unittest.main()
